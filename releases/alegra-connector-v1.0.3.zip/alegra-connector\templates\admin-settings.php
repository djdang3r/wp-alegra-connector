<?php if(!defined('ABSPATH'))exit;$page_title=__('Configuracion','alegra-connector');$page_subtitle=__('Ajusta la conexion y el comportamiento del plugin','alegra-connector');include __DIR__.'/header.php';?>
<div class="alegra-connector-wrap">
<form method="post" action="options.php"><?php settings_fields('alegra_connector_settings');?>
<div class="ac-settings-tabs">
<button type="button" class="ac-settings-tab active" data-tab="connection"><?php esc_html_e('Conexion','alegra-connector');?></button>
<button type="button" class="ac-settings-tab" data-tab="sync"><?php esc_html_e('Sincronizacion','alegra-connector');?></button>
<button type="button" class="ac-settings-tab" data-tab="currency"><?php esc_html_e('Moneda','alegra-connector');?></button>
<button type="button" class="ac-settings-tab" data-tab="warehouse"><?php esc_html_e('Bodegas','alegra-connector');?></button>
<button type="button" class="ac-settings-tab" data-tab="advanced"><?php esc_html_e('Avanzado','alegra-connector');?></button>
</div>
<div class="ac-settings-content">

<!-- ==================== CONEXION ==================== -->
<div class="ac-tab-content active" id="tab-connection">
<h2><?php esc_html_e('Conexion con Alegra','alegra-connector');?></h2>
<div class="ac-notice info" style="margin-bottom:16px;"><?php esc_html_e('Para conectar necesitas el email de tu cuenta Alegra y un token API. Obten tu token en: app.alegra.com > Configuracion > API - Integraciones con otros sistemas.','alegra-connector');?></div>
<table class="form-table">
<tr><th><label for="alegra_connector_email"><?php esc_html_e('Email de la cuenta:','alegra-connector');?></label></th><td><input type="email" id="alegra_connector_email" name="alegra_connector_email" value="<?php echo esc_attr(get_option('alegra_connector_email',''));?>" class="regular-text" placeholder="tu@email.com"><p class="description"><?php esc_html_e('El mismo email con el que inicias sesion en Alegra.','alegra-connector');?></p></td></tr>
<tr><th><label for="alegra_connector_token"><?php esc_html_e('Token API:','alegra-connector');?></label></th>
<td>
    <input type="password" id="alegra_connector_token" name="alegra_connector_token" value="<?php echo esc_attr(get_option('alegra_connector_token',''));?>" class="regular-text" placeholder="<?php esc_attr_e('Token generado en Alegra','alegra-connector');?>">
    <button type="button" class="ac-btn ac-btn-sm" id="toggle-token-visibility" style="margin-left:8px;"><?php esc_html_e('Mostrar','alegra-connector');?></button>
    <p class="description"><?php esc_html_e('El token se almacena en la base de datos de WordPress.','alegra-connector');?></p>
</td></tr>
<tr><th><label for="alegra_connector_api_url"><?php esc_html_e('URL de la API:','alegra-connector');?></label></th><td><input type="text" id="alegra_connector_api_url" name="alegra_connector_api_url" value="<?php echo esc_attr(get_option('alegra_connector_api_url','https://api.alegra.com/api/v1'));?>" class="regular-text" placeholder="https://api.alegra.com/api/v1"><p class="description"><?php esc_html_e('URL base de la API de Alegra. No cambiar a menos que Alegra te indique otra URL.','alegra-connector');?></p></td></tr>
<tr><th></th><td><button type="button" class="ac-btn ac-btn-primary" id="alegra-test-connection"><?php esc_html_e('Probar Conexion','alegra-connector');?></button> <span id="alegra-connection-status" style="margin-left:8px;font-size:13px;"></span><p class="description"><?php esc_html_e('Verifica que las credenciales sean correctas antes de guardar.','alegra-connector');?></p></td></tr></table>
<div id="alegra-connection-result" style="display:none;margin-top:12px;padding:12px;border-radius:8px;"></div>

<?php $connected=(bool)get_option('alegra_connector_connection_tested');if($connected):?>
<div id="alegra-connection-info" class="ac-card" style="margin-top:16px;border-left:4px solid var(--ac-success);">
    <div class="ac-card-header"><h2><?php esc_html_e('Informacion de la Conexion','alegra-connector');?></h2><span class="ac-badge success"><?php esc_html_e('Conectado','alegra-connector');?></span></div>
    <table class="ac-detail-table" style="margin-top:8px;">
        <tr><th style="width:100px;"><?php esc_html_e('Empresa','alegra-connector');?></th><td><strong><?php echo esc_html(get_option('alegra_connector_company_name','--'));?></strong></td></tr>
        <tr><th><?php esc_html_e('Email','alegra-connector');?></th><td><?php echo esc_html(get_option('alegra_connector_company_email','--'));?></td></tr>
        <tr><th><?php esc_html_e('Pais','alegra-connector');?></th><td><?php echo esc_html(get_option('alegra_connector_company_country','--'));?></td></tr>
        <tr><th><?php esc_html_e('URL API','alegra-connector');?></th><td><code><?php echo esc_html(get_option('alegra_connector_api_url','https://api.alegra.com/api/v1'));?></code></td></tr>
        <?php $diag = get_option('alegra_connector_diagnostics',[]); if(!empty($diag)):?>
        <tr><th><?php esc_html_e('Diagnostico','alegra-connector');?></th><td><?php foreach($diag as $d):?><span class="ac-badge <?php echo strpos($d,'OK')!==false?'success':(strpos($d,'vacio')!==false?'warning':'danger');?>" style="margin:2px;"><?php echo esc_html($d);?></span><?php endforeach;?></td></tr>
        <?php endif;?>
    </table>
    <div style="margin-top:12px;display:flex;gap:8px;">
        <button type="button" class="ac-btn" id="alegra-disconnect" style="color:var(--ac-danger);border-color:var(--ac-danger);"><span class="dashicons dashicons-no" style="font-size:16px;width:16px;height:16px;"></span> <?php esc_html_e('Desconectar','alegra-connector');?></button>
        <button type="button" class="ac-btn" id="alegra-check-endpoints"><span class="dashicons dashicons-saved" style="font-size:16px;width:16px;height:16px;"></span> <?php esc_html_e('Verificar Endpoints','alegra-connector');?></button>
        <span id="alegra-endpoints-status" style="font-size:12px;align-self:center;"></span>
    </div>
</div>
<?php endif;?>
</div>

<!-- ==================== SINCRONIZACION ==================== -->
<div class="ac-tab-content" id="tab-sync" style="display:none;">
<h2><?php esc_html_e('Configuracion de Sincronizacion','alegra-connector');?></h2>
<table class="form-table">
<tr><th><?php esc_html_e('Metodo de sincronizacion:','alegra-connector');?></th><td><fieldset>
<label><input type="radio" name="alegra_connector_sync_method" value="real-time" <?php checked(get_option('alegra_connector_sync_method'),'real-time');?>> <strong><?php esc_html_e('Tiempo real','alegra-connector');?></strong></label>
<p class="description" style="margin:2px 0 8px 24px;"><?php esc_html_e('Sincroniza al instante cuando creas o editas productos, clientes o pedidos en WooCommerce.','alegra-connector');?></p>
<label><input type="radio" name="alegra_connector_sync_method" value="cron" <?php checked(get_option('alegra_connector_sync_method'),'cron');?>> <strong><?php esc_html_e('Periodica (cron)','alegra-connector');?></strong></label>
<p class="description" style="margin:2px 0 8px 24px;"><?php esc_html_e('Se ejecuta automaticamente cada X minutos. El polling verifica facturas pagadas en Alegra y actualiza los pedidos.','alegra-connector');?></p>
<label><input type="radio" name="alegra_connector_sync_method" value="both" <?php checked(get_option('alegra_connector_sync_method','both'),'both');?>> <strong><?php esc_html_e('Ambos (recomendado)','alegra-connector');?></strong></label>
<p class="description" style="margin:2px 0 0 24px;"><?php esc_html_e('Combina tiempo real + periodica. Maxima cobertura de sincronizacion.','alegra-connector');?></p>
</fieldset></td></tr>
<tr><th><label for="alegra_connector_sync_frequency"><?php esc_html_e('Frecuencia periodica:','alegra-connector');?></label></th><td><select id="alegra_connector_sync_frequency" name="alegra_connector_sync_frequency"><option value="5" <?php selected(get_option('alegra_connector_sync_frequency'),5);?>>5 min</option><option value="15" <?php selected(get_option('alegra_connector_sync_frequency',15),15);?>>15 min</option><option value="30" <?php selected(get_option('alegra_connector_sync_frequency'),30);?>>30 min</option><option value="60" <?php selected(get_option('alegra_connector_sync_frequency'),60);?>>1 hora</option></select><p class="description"><?php esc_html_e('Cada cuanto tiempo se ejecuta la sincronizacion automatica. Solo aplica si usas modo Periodica o Ambos.','alegra-connector');?></p></td></tr>
<tr><th><?php esc_html_e('Entidades a sincronizar:','alegra-connector');?></th><td><fieldset>
<label><input type="checkbox" name="alegra_connector_sync_products" value="1" <?php checked(get_option('alegra_connector_sync_products',true));?>> <?php esc_html_e('Productos','alegra-connector');?></label><p class="description" style="margin:0 0 6px 24px;"><?php esc_html_e('Sincroniza productos simples, variables y sus variaciones con Alegra.','alegra-connector');?></p>
<label><input type="checkbox" name="alegra_connector_sync_customers" value="1" <?php checked(get_option('alegra_connector_sync_customers',true));?>> <?php esc_html_e('Clientes','alegra-connector');?></label><p class="description" style="margin:0 0 6px 24px;"><?php esc_html_e('Mantiene actualizados los datos de clientes entre WooCommerce y Alegra.','alegra-connector');?></p>
<label><input type="checkbox" name="alegra_connector_sync_orders" value="1" <?php checked(get_option('alegra_connector_sync_orders',true));?>> <?php esc_html_e('Pedidos','alegra-connector');?></label><p class="description" style="margin:0 0 6px 24px;"><?php esc_html_e('Al completar un pedido, crea automaticamente la factura en Alegra. Tambien gestiona reembolsos como notas credito.','alegra-connector');?></p>
<label><input type="checkbox" name="alegra_connector_sync_categories" value="1" <?php checked(get_option('alegra_connector_sync_categories',true));?>> <?php esc_html_e('Categorias','alegra-connector');?></label><p class="description" style="margin:0 0 6px 24px;"><?php esc_html_e('Sincroniza las categorias de productos entre WooCommerce y Alegra.','alegra-connector');?></p>
<label><input type="checkbox" name="alegra_connector_sync_images" value="1" <?php checked(get_option('alegra_connector_sync_images',true));?>> <?php esc_html_e('Imagenes de productos','alegra-connector');?></label><p class="description" style="margin:0 0 6px 24px;"><?php esc_html_e('Activa la sincronizacion bidireccional de imagenes de productos. Al desactivar, no se descargan ni se suben imagenes.','alegra-connector');?></p>

<div style="margin:0 0 12px 24px;">
    <label style="font-size:12px;font-weight:600;color:var(--ac-text-secondary);display:block;margin-bottom:4px;"><?php esc_html_e('Al traer desde Alegra:','alegra-connector');?></label>
    <select name="alegra_connector_sync_images_mode" style="padding:4px 8px;border-radius:6px;border:1px solid var(--ac-border);font-size:12px;max-width:280px;">
        <option value="favorite" <?php selected(get_option('alegra_connector_sync_images_mode','favorite'),'favorite');?>><?php esc_html_e('Solo la imagen favorita (favorite: true) — recomendado','alegra-connector');?></option>
        <option value="all" <?php selected(get_option('alegra_connector_sync_images_mode','favorite'),'all');?>><?php esc_html_e('Todas las imagenes (la favorita como principal, el resto en galeria)','alegra-connector');?></option>
        <option value="except_favorite" <?php selected(get_option('alegra_connector_sync_images_mode','favorite'),'except_favorite');?>><?php esc_html_e('Todas excepto la favorita (solo galeria, sin imagen principal)','alegra-connector');?></option>
    </select>
    <p class="description" style="margin-top:2px;"><?php esc_html_e('La API de Alegra devuelve un array images[] donde cada objeto tiene: id, name, url y favorite (booleano). La imagen con favorite:true es la predeterminada en Alegra.','alegra-connector');?></p>
</div>

<label><input type="checkbox" name="alegra_connector_sync_inactive_products" value="1" <?php checked(get_option('alegra_connector_sync_inactive_products',false));?>> <?php esc_html_e('Productos inactivos','alegra-connector');?></label><p class="description" style="margin:0 0 6px 24px;"><?php esc_html_e('Al activar, tambien se sincronizan los productos inactivos de Alegra. Se importaran como Borrador en WooCommerce. Al desactivar (por defecto), solo se sincronizan productos activos (status=active en Alegra). La API de Alegra permite filtrar por status: active, inactive.','alegra-connector');?></p>
</fieldset></td></tr>
<tr><th><?php esc_html_e('Fuente de inventario:','alegra-connector');?></th><td><select name="alegra_connector_inventory_source"><option value="alegra" <?php selected(get_option('alegra_connector_inventory_source','alegra'),'alegra');?>><?php esc_html_e('Alegra (recomendado)','alegra-connector');?></option><option value="woocommerce" <?php selected(get_option('alegra_connector_inventory_source'),'woocommerce');?>><?php esc_html_e('WooCommerce','alegra-connector');?></option></select><p class="description"><?php esc_html_e('Define que sistema es la fuente principal del inventario. Si hay conflicto, gana la fuente seleccionada.','alegra-connector');?></p></td></tr></table>
</div>

<!-- ==================== MONEDA ==================== -->
<div class="ac-tab-content" id="tab-currency" style="display:none;">
<h2><?php esc_html_e('Configuracion de Moneda','alegra-connector');?></h2>
<div class="ac-notice info" style="margin-bottom:16px;"><?php esc_html_e('La moneda seleccionada se usara al crear facturas en Alegra. Debe coincidir con una moneda configurada en tu cuenta Alegra. Si no estas conectado, se muestran las monedas basicas.','alegra-connector');?></div>
<table class="form-table">
<tr><th><?php esc_html_e('Moneda por defecto:','alegra-connector');?></th><td>
<?php if(!empty($alegra_currencies)):?>
<select name="alegra_connector_currency">
    <?php foreach($alegra_currencies as $cur): $code=esc_attr($cur['code']??'');$name=esc_html(($cur['name']??'').' ('.$code.')');?>
    <option value="<?php echo $code;?>" <?php selected(get_option('alegra_connector_currency','COP'),$code);?>><?php echo $name;?></option>
    <?php endforeach;?>
</select>
<p class="description"><?php esc_html_e('Estas monedas vienen directamente de tu cuenta Alegra. La factura se creara en la moneda aqui seleccionada.','alegra-connector');?></p>
<?php else:?>
<select name="alegra_connector_currency">
    <option value="COP" <?php selected(get_option('alegra_connector_currency','COP'),'COP');?>>COP - Peso Colombiano</option>
    <option value="USD" <?php selected(get_option('alegra_connector_currency'),'USD');?>>USD - Dolar</option>
    <option value="MXN" <?php selected(get_option('alegra_connector_currency'),'MXN');?>>MXN - Peso Mexicano</option>
    <option value="EUR" <?php selected(get_option('alegra_connector_currency'),'EUR');?>>EUR - Euro</option>
    <option value="ARS" <?php selected(get_option('alegra_connector_currency'),'ARS');?>>ARS - Peso Argentino</option>
</select>
<p class="description"><?php esc_html_e('Conecta con Alegra para ver tus monedas configuradas. Estas son las monedas basicas.','alegra-connector');?></p>
<?php endif;?>
</td></tr></table>
</div>

<!-- ==================== BODEGAS ==================== -->
<div class="ac-tab-content" id="tab-warehouse" style="display:none;">
<h2><?php esc_html_e('Configuracion de Bodegas','alegra-connector');?></h2>
<div class="ac-notice info" style="margin-bottom:16px;"><?php esc_html_e('Las bodegas permiten gestionar inventario en diferentes ubicaciones. Si no manejas multiples bodegas, puedes dejar esta seccion desactivada y se usara la bodega Principal de Alegra.','alegra-connector');?></div>
<table class="form-table">
<tr><th><?php esc_html_e('Activar gestion de bodegas:','alegra-connector');?></th><td><label><input type="checkbox" name="alegra_connector_warehouse_enabled" value="1" <?php checked(get_option('alegra_connector_warehouse_enabled'),true);?>> <?php esc_html_e('Si','alegra-connector');?></label><p class="description"><?php esc_html_e('Al activarlo, los productos y facturas se asociaran a la bodega seleccionada abajo.','alegra-connector');?></p></td></tr>
<?php if(!empty($alegra_warehouses)):?>
<tr><th><?php esc_html_e('Bodega por defecto:','alegra-connector');?></th><td>
<select name="alegra_connector_warehouse_id">
    <option value="0"><?php esc_html_e('-- Principal (ID: 1) --','alegra-connector');?></option>
    <?php foreach($alegra_warehouses as $wh): $id=(int)($wh['id']??0);?>
    <option value="<?php echo esc_attr($id);?>" <?php selected((int)get_option('alegra_connector_warehouse_id',0),$id);?>><?php echo esc_html(($wh['name']??'').' (ID: '.$id.')');?></option>
    <?php endforeach;?>
</select>
<p class="description"><?php esc_html_e('Bodegas sincronizadas desde Alegra. Al crear productos y facturas se usara esta bodega.','alegra-connector');?></p></td></tr>
<?php else:?>
<tr><th><?php esc_html_e('Bodega por defecto:','alegra-connector');?></th><td><input type="number" name="alegra_connector_warehouse_id" value="<?php echo esc_attr(get_option('alegra_connector_warehouse_id',''));?>" class="small-text" min="0" placeholder="ID"><p class="description"><?php esc_html_e('Conecta con Alegra para ver tus bodegas o ingresa el ID manualmente.','alegra-connector');?></p></td></tr>
<?php endif;?>
</table>
</div>

<!-- ==================== AVANZADO ==================== -->
<div class="ac-tab-content" id="tab-advanced" style="display:none;">
<h2><?php esc_html_e('Configuracion Avanzada','alegra-connector');?></h2>

<table class="form-table">
<!-- Conflict Resolution -->
<tr><th><?php esc_html_e('Resolucion de conflictos:','alegra-connector');?></th><td>
<select name="alegra_connector_conflict_resolution">
    <option value="alegra_wins" <?php selected(get_option('alegra_connector_conflict_resolution','alegra_wins'),'alegra_wins');?>><?php esc_html_e('Alegra gana (recomendado)','alegra-connector');?></option>
    <option value="woocommerce_wins" <?php selected(get_option('alegra_connector_conflict_resolution'),'woocommerce_wins');?>><?php esc_html_e('WooCommerce gana','alegra-connector');?></option>
</select>
<p class="description"><?php esc_html_e('Si un producto o cliente se edita en AMBAS plataformas entre sincronizaciones, este ajuste define cual version prevalece. Con "Alegra gana", el sistema contable tiene prioridad.','alegra-connector');?></p></td></tr>

<!-- Log Retention -->
<tr><th><?php esc_html_e('Retencion de logs:','alegra-connector');?></th><td>
<input type="number" name="alegra_connector_log_retention_days" value="<?php echo esc_attr(get_option('alegra_connector_log_retention_days',30));?>" class="small-text" min="1" max="365"> <?php esc_html_e('dias','alegra-connector');?>
<p class="description"><?php esc_html_e('Los logs anteriores a este numero de dias se eliminan automaticamente. Los logs se guardan en wp-content/uploads/alegra-logs/.','alegra-connector');?></p></td></tr>

<!-- Bank Account -->
<tr><th><?php esc_html_e('Cuenta bancaria para pagos:','alegra-connector');?></th><td>
<?php if(!empty($alegra_bank_accounts)):?>
<select name="alegra_connector_payment_account_id">
    <option value="0"><?php esc_html_e('-- Sin cuenta (no se registraran pagos) --','alegra-connector');?></option>
    <?php foreach($alegra_bank_accounts as $ba): $id=(int)($ba['id']??0);?>
    <option value="<?php echo esc_attr($id);?>" <?php selected((int)get_option('alegra_connector_payment_account_id',0),$id);?>><?php echo esc_html(($ba['name']??'Banco').' (ID: '.$id.')');?></option>
    <?php endforeach;?>
</select>
<p class="description"><?php esc_html_e('Sincronizado desde Alegra. Sin una cuenta seleccionada NO se registraran pagos automaticos en Alegra al completar pedidos.','alegra-connector');?></p>
<?php else:?>
<input type="number" name="alegra_connector_payment_account_id" value="<?php echo esc_attr(get_option('alegra_connector_payment_account_id',''));?>" class="small-text" min="1" placeholder="ID en Alegra">
<p class="description"><?php esc_html_e('ID de la cuenta bancaria en Alegra donde se registraran los pagos. Conecta con Alegra para ver tus cuentas o ingresa el ID manualmente.','alegra-connector');?></p>
<?php endif;?>
</td></tr>

<!-- Payment Term -->
<tr><th><?php esc_html_e('Termino de pago:','alegra-connector');?></th><td>
<?php if(!empty($alegra_terms)):?>
<select name="alegra_connector_payment_term_id">
    <option value="0"><?php esc_html_e('-- Sin termino (15 dias por defecto) --','alegra-connector');?></option>
    <?php foreach($alegra_terms as $tm): $id=(int)($tm['id']??0);?>
    <option value="<?php echo esc_attr($id);?>" <?php selected((int)get_option('alegra_connector_payment_term_id',0),$id);?>><?php echo esc_html(($tm['name']??'Termino').' - '.($tm['days']??0).' '.__('dias','alegra-connector'));?></option>
    <?php endforeach;?>
</select>
<p class="description"><?php esc_html_e('Define cuantos dias despues de la fecha de factura vence el pago. Sincronizado desde Alegra.','alegra-connector');?></p>
<?php else:?>
<input type="number" name="alegra_connector_payment_term_id" value="<?php echo esc_attr(get_option('alegra_connector_payment_term_id',''));?>" class="small-text" min="1" placeholder="ID en Alegra">
<p class="description"><?php esc_html_e('ID del termino de pago en Alegra. Conecta con Alegra para ver tus terminos.','alegra-connector');?></p>
<?php endif;?>
</td></tr>
</table>

<!-- ==================== WEBHOOKS ==================== -->
<div class="ac-card" style="margin-top:20px;border-left:4px solid var(--ac-primary);">
<div class="ac-card-header"><h2><?php esc_html_e('Sincronizacion desde Alegra hacia WooCommerce','alegra-connector');?></h2></div>
<div class="ac-notice info" style="margin-bottom:16px;"><?php esc_html_e('Cuando Alegra detecta un cambio (producto creado, cliente actualizado, factura pagada), el plugin puede actualizar WooCommerce mediante la sincronizacion periodica (cron). Configura la frecuencia en la pestana Sincronizacion.','alegra-connector');?></div>

<table class="form-table">
<tr><th><?php esc_html_e('Auto-completar pedidos:','alegra-connector');?></th><td>
<label><input type="checkbox" name="alegra_connector_auto_complete_order" value="1" <?php checked(get_option('alegra_connector_auto_complete_order',true));?>> <?php esc_html_e('Marcar pedido como Completado cuando la factura se paga en Alegra','alegra-connector');?></label>
<p class="description"><?php esc_html_e('Durante la sincronizacion periodica, si se detecta que una factura fue pagada en Alegra, el pedido WooCommerce se marcara automaticamente como "Completado".','alegra-connector');?></p></td></tr>
</table>
</div>
</div>

</div>
<?php submit_button(esc_html__('Guardar Cambios','alegra-connector'));?></form>
<?php include __DIR__ . '/footer.php'; ?></div>