/**
 * Alegra Connector Admin JavaScript
 */
(function($) {
    'use strict';

    function showNotice(msg, type) {
        type = type || 'info';
        var $n = $('<div class="ac-notice '+type+'" style="display:none;margin:8px 0 14px 0;">'+msg+'</div>');
        $('.alegra-connector-wrap').first().prepend($n);
        $n.slideDown(200);
        setTimeout(function(){ $n.slideUp(300, function(){ $(this).remove(); }); }, 6000);
    }

    function safeMsg(response, fallback) {
        return (response && response.data && response.data.message) || fallback || 'Error desconocido';
    }

    var AlegraConnector = {
        init: function() {
            this.initTabs();
            this.initConnectionTest();
            this.initSyncNow();
            this.initLogManagement();
            this.initTokenVisibility();
            this.initSingleSync();
            this.initRecordPayment();
        },

        initTabs: function() {
            $('.ac-settings-tab').on('click', function() {
                var tab = $(this).data('tab');
                $('.ac-settings-tab').removeClass('active');
                $(this).addClass('active');
                $('.ac-tab-content').hide();
                $('#tab-' + tab).show();
            });
        },

        initConnectionTest: function() {
            $('#alegra-test-connection').on('click', function() {
                var $btn = $(this);
                var $status = $('#alegra-connection-status');
                var $result = $('#alegra-connection-result');
                var email = $('#alegra_connector_email').val();
                var token = $('#alegra_connector_token').val();
                if (!email || !token) { showNotice('Email y token son requeridos', 'warning'); return; }
                $btn.prop('disabled', true).text(alegraConnector.strings.testing);
                $status.html('');
                $result.hide();
                $.ajax({
                    url: alegraConnector.ajaxUrl, type: 'POST', timeout: 15000,
                    data: { action: 'alegra_test_connection', _ajax_nonce: alegraConnector.nonce, email: email, token: token },
                    success: function(r) {
                        $btn.prop('disabled', false).text('Probar Conexion');
                        if (r.success) {
                            var diag = r.data.diagnostics ? r.data.diagnostics.join(', ') : '';
                            $status.html('<span style="color:var(--ac-success);font-weight:500;">&#10003; Conectado - ' + (r.data.company || 'OK') + '</span>');
                            $result.show().removeClass('error').addClass('success').html(
                                '<p style="margin:0;color:var(--ac-success);"><strong>Empresa:</strong> ' + (r.data.company || 'N/A') + ' | <strong>Pais:</strong> ' + (r.data.country || 'N/A') + '</p>' +
                                '<p style="margin:4px 0 0 0;font-size:11px;color:var(--ac-text-secondary);">Endpoints: ' + diag + '</p>'
                            );
                            showNotice('Conectado a ' + (r.data.company || 'Alegra') + (diag ? ' - ' + diag : ''), 'success');
                            setTimeout(function(){ location.reload(); }, 2000);
                        } else {
                            var msg = r.data.message || 'Error';
                            var http = r.data.http_code ? ' (HTTP ' + r.data.http_code + ')' : '';
                            $status.html('<span style="color:var(--ac-danger);font-weight:500;">&#10007; ' + msg + http + '</span>');
                            showNotice('Error: ' + msg + http, 'error');
                            $result.show().removeClass('success').addClass('error').html('<p style="margin:0;color:var(--ac-danger);">' + msg + http + '</p>');
                        }
                    },
                    error: function(xhr, status) {
                        $btn.prop('disabled', false).text('Probar Conexion');
                        var msg = status === 'timeout' ? 'Timeout: el servidor de Alegra no responde' : 'Error de red (' + status + ')';
                        $status.html('<span style="color:var(--ac-danger);">&#10007; ' + msg + '</span>');
                        showNotice(msg + '. Verifica la URL base y tu conexion.', 'error');
                    }
                });
            });
        },

        initSyncNow: function() {
            $('#alegra-sync-now-btn, .alegra-quick-sync').on('click', function() {
                var types = $(this).data('type') || 'all';
                var $btn = $(this).prop('disabled', true);

                // For products sync, show image choice before starting
                if (types === 'products') {
                    var $modal = $('#alegra-sync-progress-modal');
                    var syncImages = true;

                    // Show choice buttons, hide progress elements
                    $modal.find('.sync-progress-label').text('Selecciona una opcion');
                    $modal.find('.sync-progress-fill').css('width','0%');
                    $modal.find('.sync-counters').text('');
                    $modal.find('#sync-elapsed').text('');
                    $modal.find('.sync-cancel-btn').show();
                    $modal.find('.sync-image-choice').show();
                    $modal.show();
                    $('body').addClass('ac-modal-open');

                    // Wire choice buttons (remove old handlers first)
                    $modal.find('.sync-with-images-btn').off('click').on('click', function() {
                        syncImages = true;
                        startSync();
                    });
                    $modal.find('.sync-without-images-btn').off('click').on('click', function() {
                        syncImages = false;
                        startSync();
                    });

                    var startSync = function() {
                        $modal.find('.sync-image-choice').hide();
                        doSync(syncImages);
                    };

                    // Cancel closes the modal
                    $modal.find('.sync-cancel-btn').off('click').on('click', function() {
                        $modal.hide();
                        $('body').removeClass('ac-modal-open');
                        $btn.prop('disabled', false);
                    });
                } else {
                    doSync(true);
                }

                function doSync(syncImages) {
                var $modal = $('#alegra-sync-progress-modal');
                var $label = $modal.find('.sync-progress-label');
                var $fill = $modal.find('.sync-progress-fill');
                var $counters = $modal.find('.sync-counters');
                var $elapsed = $('#sync-elapsed');
                var startTime = Date.now();
                var cancelled = false;
                
                var imgLabel = types === 'products' ? (syncImages ? ' (con imagenes)' : ' (sin imagenes)') : '';
                $label.text(types === 'all' ? 'Sincronizando...' : 'Obteniendo conteo de Alegra...' + imgLabel);
                $fill.css('width', '2%');
                $counters.text('');
                $elapsed.text('');
                cancelled = false;
                $modal.show();
                $('body').addClass('ac-modal-open');
                
                // Cancel button
                $modal.find('.sync-cancel-btn').off('click').on('click', function() {
                    cancelled = true;
                    cleanup();
                    $btn.prop('disabled', false).text('Sincronizar Todo');
                    showNotice('Sincronizacion cancelada', 'warning');
                });
                
                // Timer
                var timerInterval = setInterval(function() {
                    var elapsed = Math.floor((Date.now() - startTime) / 1000);
                    var m = Math.floor(elapsed / 60), s = elapsed % 60;
                    $elapsed.text('Tiempo: ' + m + 'm ' + s + 's');
                }, 1000);
                
                var cleanup = function() {
                    clearInterval(timerInterval);
                    $modal.hide();
                    $('body').removeClass('ac-modal-open');
                };
                
                var processNext = function() { return; }; // Placeholder
                
                var doAllSync = function() {
                    $.ajax({
                        url: alegraConnector.ajaxUrl, type: 'POST',
                        data: { action: 'alegra_sync_now', _ajax_nonce: alegraConnector.nonce, sync_type: 'all' },
                        success: function(r) {
                            cleanup();
                            if(r.success) { showNotice(r.data.message || 'Completado','success'); setTimeout(function(){location.reload();},1500); }
                            else { showNotice(safeMsg(r,'Error'),'error'); $btn.prop('disabled',false).text('Reintentar'); }
                        },
                        error: function() { cleanup(); showNotice('Error','error'); $btn.prop('disabled',false).text('Reintentar'); }
                    });
                };
                
                if (types === 'all') { doAllSync(); return; }
                
                // Chunked sync for specific types
                var phase = 'init'; // init | fetching | importing | done
                var retries = 0;
                var maxRetries = 2;
                
                $.ajax({
                    url: alegraConnector.ajaxUrl, type: 'POST',
                    data: { action: 'alegra_sync_start', _ajax_nonce: alegraConnector.nonce, sync_type: types, sync_images: syncImages ? 1 : 0 },
                    success: function(r) {
                        if (!r.success || cancelled) { cleanup(); return; }
                        var d = r.data || {};
                        $label.text('[Fase 1] Total: ' + (d.total_items || '?') + ' items en ' + (d.total_pages || '?') + ' paginas — Pagina 1');
                        $counters.text('Procesando...');
                        processPage(1);
                    },
                    error: function() { cleanup(); showNotice('Error al iniciar','error'); $btn.prop('disabled',false).text('Reintentar'); }
                });
                
                var processPage = function(page) {
                    if (cancelled) { cleanup(); return; }
                    
                    $.ajax({
                        url: alegraConnector.ajaxUrl, type: 'POST',
                        data: { action: 'alegra_sync_page', _ajax_nonce: alegraConnector.nonce },
                        success: function(r) {
                            retries = 0;
                            if (!r.success || cancelled) { cleanup(); $btn.prop('disabled',false).text('Reintentar'); return; }
                            var d = r.data;
                            var pct = d.percent || Math.min(95, 5 + (page * 2));
                            $fill.css('width', pct + '%');
                            $label.text('[Fase 1] ' + d.message);
                            $counters.text(d.imported + ' importados | ' + d.updated + ' actualizados | ' + (d.skipped || 0) + ' omitidos | ' + d.errors + ' errores');
                            
                            if (d.done) {
                                $fill.css('width', '100%');
                                $label.text('[Fase 2] Completado');
                                $counters.text('Total: ' + d.processed + ' items | ' + d.imported + ' nuevos, ' + d.updated + ' actualizados');
                                setTimeout(function() {
                                    cleanup();
                                    showNotice(d.processed + ' items procesados. ' + d.imported + ' importados, ' + d.updated + ' actualizados.', 'success');
                                    setTimeout(function(){ location.reload(); }, 2000);
                                }, 1500);
                            } else {
                                processPage(page + 1);
                            }
                        },
                        error: function() {
                            retries++;
                            if (retries <= maxRetries) {
                                $counters.text('Reintentando (' + retries + '/' + maxRetries + ')...');
                                setTimeout(function() { processPage(page); }, 2000);
                            } else {
                                cleanup(); $btn.prop('disabled',false).text('Reintentar');
                            }
                        }
                    });
                };
                } // end doSync
            });
            $('#alegra-sync-start').on('click', function() {
                var syncTypes = [];
                $('input[name="sync_products"]:checked').length && syncTypes.push('products');
                $('input[name="sync_customers"]:checked').length && syncTypes.push('customers');
                $('input[name="sync_orders"]:checked').length && syncTypes.push('orders');
                $('input[name="sync_categories"]:checked').length && syncTypes.push('categories');
                if (!syncTypes.length) { showNotice('Selecciona al menos un tipo','warning'); return; }
                var $modal = $('#alegra-sync-modal');
                var $status = $modal.find('.alegra-sync-status').text(alegraConnector.strings.syncing);
                $.ajax({
                    url: alegraConnector.ajaxUrl, type: 'POST',
                    data: { action: 'alegra_sync_now', _ajax_nonce: alegraConnector.nonce, sync_type: syncTypes.join(',') },
                    success: function(r) { if(r.success){$status.text(safeMsg(r,'Completado'));setTimeout(function(){location.reload();},1500);} else {showNotice(safeMsg(r,'Error'),'error');} },
                    error: function() { showNotice('Error de conexion','error'); }
                });
            });
            $('#alegra-sync-cancel').on('click', function() { $('#alegra-sync-modal').hide(); });
        },

        initLogManagement: function() {
            $('#alegra-refresh-logs').on('click', function() { location.reload(); });
            $('#alegra-clear-logs').on('click', function() {
                if(!confirm('Eliminar logs antiguos?')) return;
                $.ajax({
                    url: alegraConnector.ajaxUrl, type: 'POST',
                    data: { action: 'alegra_clear_logs', _ajax_nonce: alegraConnector.nonce },
                    success: function(r) { if(r.success){showNotice(safeMsg(r,'Logs eliminados'),'success');setTimeout(function(){location.reload();},1000);} }
                });
            });
        },

        initTokenVisibility: function() {
            $('#toggle-token-visibility').on('click', function() {
                var $t = $('#alegra_connector_token');
                if ($t.attr('type') === 'password') { $t.attr('type', 'text'); $(this).text('Ocultar token'); }
                else { $t.attr('type', 'password'); $(this).text('Mostrar token'); }
            });
            $('#alegra-disconnect').on('click', function() {
                if (!confirm('Desconectar de Alegra? Deberas volver a probar la conexion.')) return;
                var $btn = $(this).prop('disabled', true).text('Desconectando...');
                $.ajax({
                    url: alegraConnector.ajaxUrl, type: 'POST',
                    data: { action: 'alegra_disconnect', _ajax_nonce: alegraConnector.nonce },
                    success: function() { location.reload(); },
                    error: function() { $btn.prop('disabled', false).text('Desconectar'); }
                });
            });
            $('#alegra-check-endpoints').on('click', function() {
                var $btn = $(this).prop('disabled', true).text('Verificando...');
                var $status = $('#alegra-endpoints-status');
                $status.html('');
                $.ajax({
                    url: alegraConnector.ajaxUrl, type: 'POST',
                    data: { action: 'alegra_check_endpoints', _ajax_nonce: alegraConnector.nonce },
                    success: function(r) {
                        $btn.prop('disabled', false).text('Verificar Endpoints');
                        if (r.success) {
                            var badges = '';
                            $.each(r.data.endpoints || {}, function(k, v) {
                                var cls = v.indexOf('OK') === 0 ? 'success' : (v.indexOf('vacio') !== -1 ? 'warning' : 'danger');
                                badges += '<span class="ac-badge ' + cls + '" style="margin:2px;">' + k + ': ' + v + '</span>';
                            });
                            $status.html(badges);
                        } else {
                            $status.html('<span style="color:var(--ac-danger);">Error</span>');
                        }
                    },
                    error: function() { $btn.prop('disabled', false).text('Verificar Endpoints'); $status.html('<span style="color:var(--ac-danger);">Error de red</span>'); }
                });
            });
        },

        initSingleSync: function() {
            $('.alegra-sync-single').on('click', function() {
                var $btn = $(this).prop('disabled', true).text('Sincronizando...');
                $.ajax({
                    url: alegraConnector.ajaxUrl, type: 'POST',
                    data: { action: 'alegra_sync_single', _ajax_nonce: alegraConnector.nonce, entity_type: $btn.data('type'), entity_id: $btn.data('id') },
                    success: function(r) { if(r.success) location.reload(); else { showNotice(safeMsg(r,'Error'),'error'); $btn.prop('disabled',false).text('Reintentar'); } },
                    error: function() { showNotice('Error de conexion','error'); $btn.prop('disabled',false).text('Reintentar'); }
                });
            });
        },

        initRecordPayment: function() {
            $('.alegra-record-payment').on('click', function() {
                var $btn = $(this);
                if(!confirm('Registrar pago en Alegra?')) return;
                $btn.prop('disabled', true).text('Registrando...');
                $.ajax({
                    url: alegraConnector.ajaxUrl, type: 'POST',
                    data: { action: 'alegra_record_payment', _ajax_nonce: alegraConnector.nonce, order_id: $btn.data('order-id') },
                    success: function(r) { if(r.success) location.reload(); else { showNotice(safeMsg(r,'Error'),'error'); $btn.prop('disabled',false).text('Reintentar'); } },
                    error: function() { showNotice('Error de conexion','error'); $btn.prop('disabled',false).text('Reintentar'); }
                });
            });
        },

        initBulkActions: function() {
            $('.alegra-select-all').on('click', function() { $('.alegra-bulk-check').prop('checked', this.checked); });
            
            // Push selected WC → Alegra
            $('.alegra-bulk-sync').on('click', function() {
                var type = $(this).data('type');
                var ids = $('.alegra-bulk-check:checked').map(function(){ return $(this).val(); }).get();
                if (!ids.length) { showNotice('Selecciona al menos un elemento','warning'); return; }
                var $btn = $(this).prop('disabled', true).text('Enviando...');
                $.ajax({
                    url: alegraConnector.ajaxUrl, type: 'POST',
                    data: { action: 'alegra_bulk_sync', _ajax_nonce: alegraConnector.nonce, entity_type: type, ids: ids },
                    success: function(r) { if(r.success) location.reload(); else { showNotice(safeMsg(r,'Error'),'error'); $btn.prop('disabled',false).text('Reintentar'); } },
                    error: function() { showNotice('Error de conexion','error'); $btn.prop('disabled',false).text('Reintentar'); }
                });
            });

            // Pull selected Alegra → WC
            $('.alegra-bulk-import').on('click', function() {
                var type = $(this).data('type');
                var ids = $('.alegra-bulk-check:checked').map(function(){ return $(this).val(); }).get();
                if (!ids.length) { showNotice('Selecciona al menos un elemento','warning'); return; }
                var $btn = $(this).prop('disabled', true).text('Trayendo...');
                $.ajax({
                    url: alegraConnector.ajaxUrl, type: 'POST',
                    data: { action: 'alegra_bulk_import', _ajax_nonce: alegraConnector.nonce, entity_type: type, ids: ids },
                    success: function(r) { if(r.success){showNotice(safeMsg(r,'Completado'),'success');setTimeout(function(){location.reload();},1500);} else {showNotice(safeMsg(r,'Error'),'error');$btn.prop('disabled',false).text('Reintentar');} },
                    error: function() { showNotice('Error de conexion','error'); $btn.prop('disabled',false).text('Reintentar'); }
                });
            });

            // Per-item pull Alegra → WC
            $('.alegra-import-single').on('click', function() {
                var $btn = $(this).prop('disabled', true).text('Trayendo...');
                $.ajax({
                    url: alegraConnector.ajaxUrl, type: 'POST',
                    data: { action: 'alegra_import_single', _ajax_nonce: alegraConnector.nonce, entity_type: $btn.data('type'), entity_id: $btn.data('id') },
                    success: function(r) { if(r.success){showNotice(safeMsg(r,'Actualizado'),'success');setTimeout(function(){location.reload();},1000);} else {showNotice(safeMsg(r,'Error'),'error');$btn.prop('disabled',false).text('Reintentar');} },
                    error: function() { showNotice('Error de conexion','error'); $btn.prop('disabled',false).text('Reintentar'); }
                });
            });

            // Import from Alegra buttons (also used on Products/Customers list pages)
            $('.alegra-import-from-api').on('click', function() {
                var $btn = $(this), type = $btn.data('type');
                if (!confirm('Traer ' + type + ' desde Alegra? Esto puede crear o actualizar registros en WooCommerce.')) return;
                $btn.prop('disabled', true).text('Descargando...');
                $.ajax({
                    url: alegraConnector.ajaxUrl, type: 'POST',
                    data: { action: 'alegra_import_from_api', _ajax_nonce: alegraConnector.nonce, import_type: type },
                    success: function(r) { if(r.success){showNotice(safeMsg(r,'Importado'),'success');setTimeout(function(){location.reload();},1500);} else {showNotice(safeMsg(r,'Error'),'error');$btn.prop('disabled',false).text('Reintentar');} },
                    error: function() { showNotice('Error de conexion','error'); $btn.prop('disabled',false).text('Reintentar'); }
                });
            });

            // Cleanup placeholder email users from previous buggy version
            $('.alegra-cleanup-placeholders').on('click', function() {
                var $btn = $(this);
                if (!confirm('Esto eliminara permanentemente los usuarios creados con emails placeholder (@placeholder.local). Estos usuarios no tienen email real y no funcionan como clientes de WooCommerce. Los usuarios con email real NO se veran afectados. Continuar?')) return;
                $btn.prop('disabled', true).text('Limpiando...');
                $.ajax({
                    url: alegraConnector.ajaxUrl, type: 'POST',
                    data: { action: 'alegra_cleanup_placeholders', _ajax_nonce: alegraConnector.nonce },
                    success: function(r) {
                        if (r.success) {
                            showNotice(safeMsg(r, 'Completado'), 'success');
                            setTimeout(function(){ location.reload(); }, 1500);
                        } else {
                            showNotice(safeMsg(r, 'Error'), 'error');
                            $btn.prop('disabled', false).text('Reintentar');
                        }
                    },
                    error: function() { showNotice('Error de conexion','error'); $btn.prop('disabled',false).text('Reintentar'); }
                });
            });

            // Batch-sync pending WC orders to Alegra invoices
            $('.alegra-sync-pending-orders').on('click', function() {
                var $btn = $(this).prop('disabled', true).text('Facturando...');
                $.ajax({
                    url: alegraConnector.ajaxUrl, type: 'POST',
                    data: { action: 'alegra_sync_pending_orders', _ajax_nonce: alegraConnector.nonce },
                    success: function(r) {
                        $btn.prop('disabled', false).text('Facturar pendientes');
                        if (r.success) {
                            showNotice(safeMsg(r, 'Completado'), 'success');
                            setTimeout(function(){ location.reload(); }, 1500);
                        } else {
                            showNotice(safeMsg(r, 'Error'), 'error');
                        }
                    },
                    error: function() { showNotice('Error de conexion','error'); $btn.prop('disabled',false).text('Reintentar'); }
                });
            });
        }
    };

    $(document).ready(function() {
        AlegraConnector.init();
        AlegraConnector.initBulkActions();
    });
})(jQuery);