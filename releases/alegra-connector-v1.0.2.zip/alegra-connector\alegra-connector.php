<?php
/**
 * Plugin Name: Alegra Connector
 * Plugin URI: https://github.com/example/alegra-connector
 * Description: WooCommerce - Alegra integration plugin for bidirectional synchronization of products, customers, orders, and categories.
 * Version: 1.0.2
 * Author: Script Develop
 * Author URI: https://scriptdevelop.com.co
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: alegra-connector
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * WC requires at least: 6.0
 * WC tested up to: 10.8
 */

declare(strict_types=1);

namespace Alegra\Connector;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Plugin constants
define('ALEGRA_CONNECTOR_VERSION', '1.0.0');
define('ALEGRA_CONNECTOR_PATH', plugin_dir_path(__FILE__));
define('ALEGRA_CONNECTOR_URL', plugin_dir_url(__FILE__));
define('ALEGRA_CONNECTOR_BASENAME', plugin_basename(__FILE__));
define('ALEGRA_CONNECTOR_API_URL', 'https://api.alegra.com/api/v1');
define('ALEGRA_CONNECTOR_FILE', __FILE__);

/**
 * Declare WooCommerce compatibility with modern features.
 *
 * This must happen before_woocommerce_init to prevent
 * the "incompatible with WooCommerce features" warning.
 */
add_action('before_woocommerce_init', function (): void {
    if (!class_exists(\Automattic\WooCommerce\Utilities\FeaturesUtil::class)) {
        return;
    }
    \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
    \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('product_block_editor', __FILE__, true);
    \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, true);
});

/**
 * PSR-4 Autoloader for Alegra\Connector\* classes
 */
spl_autoload_register(function (string $class): void {
    $prefix = 'Alegra\\Connector\\';
    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }

    $relative_class = substr($class, $len);
    $relative_path = str_replace('\\', '/', $relative_class) . '.php';

    $candidates = [
        __DIR__ . '/includes/' . $relative_path,
        __DIR__ . '/admin/' . $relative_path,
        __DIR__ . '/public/' . $relative_path,
        __DIR__ . '/logger/' . $relative_path,
    ];

    foreach ($candidates as $file) {
        if (file_exists($file)) {
            require $file;
            return;
        }
    }
});

/**
 * Main Plugin Class
 */
final class Alegra_Connector
{
    /**
     * Single instance
     */
    private static ?Alegra_Connector $instance = null;

    /**
     * Plugin components
     */
    private ?Admin\Admin_Dashboard $admin = null;
    private ?Public\Public_ $public = null;
    private ?Logger\Logger $logger = null;
    private ?API\Client $api = null;
    private ?Sync\Controller $sync_controller = null;

    /**
     * Get singleton instance
     */
    public static function get_instance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Private constructor for singleton
     */
    private function __construct()
    {
        $this->init_hooks();
    }

    /**
     * Initialize hooks
     */
    private function init_hooks(): void
    {
        add_action('plugins_loaded', [$this, 'on_plugins_loaded'], 1);
        add_action('init', [$this, 'load_textdomain']);
        add_filter('cron_schedules', [$this, 'register_cron_schedules']);
        register_activation_hook(__FILE__, [$this, 'activate']);
        register_deactivation_hook(__FILE__, [$this, 'deactivate']);
    }

    /**
     * Register custom cron schedules
     */
    public function register_cron_schedules(array $schedules): array
    {
        $intervals = [5, 15, 30, 60];
        foreach ($intervals as $minutes) {
            $key = 'alegra_connector_' . $minutes . 'min';
            if (!isset($schedules[$key])) {
                $schedules[$key] = [
                    'interval' => $minutes * MINUTE_IN_SECONDS,
                    'display' => sprintf(
                        /* translators: %d: number of minutes */
                        esc_html__('Every %d minutes (Alegra Connector)', 'alegra-connector'),
                        $minutes
                    ),
                ];
            }
        }
        return $schedules;
    }

    /**
     * Plugins loaded hook
     */
    public function on_plugins_loaded(): void
    {
        // Logger first - everyone depends on it
        $this->init_logger();

        // API client next
        $this->init_api();

        // Sync controller
        $this->init_sync();

        // Public facing (for webhooks/API) - needed for all requests
        $this->init_public();

        // Admin only when in admin context
        if (is_admin()) {
            $this->init_admin();
        }
    }

    /**
     * Load plugin textdomain for internationalization
     */
    public function load_textdomain(): void
    {
        load_plugin_textdomain(
            'alegra-connector',
            false,
            dirname(ALEGRA_CONNECTOR_BASENAME) . '/languages/'
        );
    }

    /**
     * Initialize admin components
     */
    private function init_admin(): void
    {
        $this->admin = new Admin\Admin_Dashboard($this->api, $this->logger);
    }

    /**
     * Initialize public facing components
     */
    private function init_public(): void
    {
        $this->public = new Public\Public_($this->api, $this->logger);
    }

    /**
     * Initialize logger
     */
    private function init_logger(): void
    {
        $this->logger = new Logger\Logger();
    }

    /**
     * Initialize API client
     */
    private function init_api(): void
    {
        $this->api = new API\Client($this->logger);
    }

    /**
     * Initialize sync controller
     */
    private function init_sync(): void
    {
        $this->sync_controller = new Sync\Controller($this->api, $this->logger);
        $this->sync_controller->register_cron_hook();
    }

    /**
     * Plugin activation
     */
    public function activate(): void
    {
        // Check WooCommerce is active
        if (!class_exists('WooCommerce')) {
            deactivate_plugins(ALEGRA_CONNECTOR_BASENAME);
            wp_die(
                esc_html__('Alegra Connector requiere WooCommerce instalado y activo.', 'alegra-connector'),
                esc_html__('Error de Activacion', 'alegra-connector'),
                ['back_link' => true]
            );
        }

        // Set default options
        $defaults = [
            'alegra_connector_version' => ALEGRA_CONNECTOR_VERSION,
            'alegra_connector_sync_frequency' => 15,
            'alegra_connector_sync_method' => 'both',
            'alegra_connector_currency' => 'COP',
            'alegra_connector_log_retention_days' => 30,
            'alegra_connector_conflict_resolution' => 'alegra_wins',
        ];

        foreach ($defaults as $key => $value) {
            if (get_option($key) === false) {
                add_option($key, $value);
            }
        }

        // Schedule cron on activation
        $this->schedule_cron();

        // Log activation
        if ($this->logger) {
            $this->logger->info('Plugin activated successfully');
        }

        flush_rewrite_rules();
    }

    /**
     * Plugin deactivation
     */
    public function deactivate(): void
    {
        // Clear scheduled cron
        wp_clear_scheduled_hook('alegra_connector_cron_sync');

        // Clear transients
        delete_transient('alegra_connector_rate_limit');
        delete_transient('alegra_connector_sync_queue');

        // Log deactivation
        if ($this->logger) {
            $this->logger->info('Plugin deactivated');
        }

        flush_rewrite_rules();
    }

    /**
     * Schedule cron for periodic sync
     */
    private function schedule_cron(): void
    {
        $frequency = (int) get_option('alegra_connector_sync_frequency', 15);
        $allowed = [5, 15, 30, 60];
        if (!in_array($frequency, $allowed, true)) {
            $frequency = 15;
        }
        $hook = 'alegra_connector_cron_sync';
        $schedule = 'alegra_connector_' . $frequency . 'min';

        // Clear any previously-scheduled events to avoid stale schedules
        wp_clear_scheduled_hook($hook);

        if (!wp_next_scheduled($hook)) {
            wp_schedule_event(time() + 60, $schedule, $hook);
        }
    }

    /**
     * Get API client instance
     */
    public function get_api(): API\Client
    {
        return $this->api;
    }

    /**
     * Get logger instance
     */
    public function get_logger(): Logger\Logger
    {
        return $this->logger;
    }

    /**
     * Get sync controller instance
     */
    public function get_sync_controller(): Sync\Controller
    {
        return $this->sync_controller;
    }

    /**
     * Get admin dashboard instance
     */
    public function get_admin(): Admin\Admin_Dashboard
    {
        return $this->admin;
    }
}

// Initialize plugin
function alegra_connector(): Alegra_Connector
{
    return Alegra_Connector::get_instance();
}

// Start the plugin
alegra_connector();