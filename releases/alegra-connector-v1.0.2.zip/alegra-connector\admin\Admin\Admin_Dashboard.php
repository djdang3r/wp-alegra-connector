<?php
/**
 * Admin Dashboard
 *
 * @package Alegra\Connector\Admin
 */

declare(strict_types=1);

namespace Alegra\Connector\Admin;

use Alegra\Connector\API;
use Alegra\Connector\Logger;
use Alegra\Connector\Sync;

if (!defined('ABSPATH')) {
    exit;
}

class Admin_Dashboard
{
    private ?API\Client $api;
    private ?Logger\Logger $logger;

    public function __construct(?API\Client $api, ?Logger\Logger $logger)
    {
        $this->api = $api;
        $this->logger = $logger;

        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);

        add_action('wp_ajax_alegra_test_connection', [$this, 'ajax_test_connection']);
        add_action('wp_ajax_alegra_sync_now', [$this, 'ajax_sync_now']);
        add_action('wp_ajax_alegra_import_csv', [$this, 'ajax_import_csv']);
        add_action('wp_ajax_alegra_clear_logs', [$this, 'ajax_clear_logs']);
        add_action('wp_ajax_alegra_download_logs', [$this, 'ajax_download_logs']);
        add_action('wp_ajax_alegra_save_mapping', [$this, 'ajax_save_mapping']);
        add_action('wp_ajax_alegra_sync_single', [$this, 'ajax_sync_single']);
        add_action('wp_ajax_alegra_record_payment', [$this, 'ajax_record_payment']);
        add_action('wp_ajax_alegra_import_from_api', [$this, 'ajax_import_from_api']);
        add_action('wp_ajax_alegra_export_csv', [$this, 'ajax_export_csv']);
        add_action('wp_ajax_alegra_bulk_sync', [$this, 'ajax_bulk_sync']);
        add_action('wp_ajax_alegra_get_invoice_pdf', [$this, 'ajax_get_invoice_pdf']);
        add_action('wp_ajax_alegra_disconnect', [$this, 'ajax_disconnect']);
        add_action('wp_ajax_alegra_check_endpoints', [$this, 'ajax_check_endpoints']);
        add_action('wp_ajax_alegra_sync_progress', [$this, 'ajax_sync_progress']);
        add_action('wp_ajax_alegra_sync_start', [$this, 'ajax_sync_start']);
        add_action('wp_ajax_alegra_sync_page', [$this, 'ajax_sync_page']);
    }

    /**
     * Null-safe logger
     */
    private function log(string $level, string $message, array $context = []): void
    {
        if ($this->logger === null) return;
        switch ($level) {
            case 'info': $this->logger->info($message, $context); break;
            case 'warning': $this->logger->warning($message, $context); break;
            case 'error': $this->logger->error($message, $context); break;
        }
    }

    private function get_product_by_alegra_id(int $alegra_id): ?int
    {
        global $wpdb;
        $pid = $wpdb->get_var($wpdb->prepare("SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key='_alegra_item_id' AND meta_value=%d LIMIT 1", $alegra_id));
        return $pid ? (int)$pid : null;
    }

    /**
     * Download and attach image from Alegra to WooCommerce product
     */
    private function import_product_image(int $product_id, string $image_url): void
    {
        if (empty($image_url)) return;

        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $tmp = download_url($image_url, 15);
        if (is_wp_error($tmp)) {
            error_log('[Alegra] Image download failed for product ' . $product_id . ': ' . $tmp->get_error_message());
            return;
        }

        $file_array = [
            'name' => 'alegra-' . $product_id . '.jpg',
            'tmp_name' => $tmp,
        ];

        $attachment_id = media_handle_sideload($file_array, $product_id);
        if (!is_wp_error($attachment_id)) {
            set_post_thumbnail($product_id, $attachment_id);
        } else {
            error_log('[Alegra] Image sideload failed: ' . $attachment_id->get_error_message());
        }

        @unlink($tmp);
    }

    public function add_admin_menu(): void
    {
        add_menu_page(
            __('Alegra Connector', 'alegra-connector'),
            __('Alegra Connector', 'alegra-connector'),
            'manage_woocommerce',
            'alegra-connector',
            [$this, 'render_dashboard'],
            'dashicons-update',
            30
        );

        add_submenu_page(
            'alegra-connector',
            __('Dashboard', 'alegra-connector'),
            __('Dashboard', 'alegra-connector'),
            'manage_woocommerce',
            'alegra-connector',
            [$this, 'render_dashboard']
        );

        add_submenu_page(
            'alegra-connector',
            __('EstadÃ­sticas', 'alegra-connector'),
            __('EstadÃ­sticas', 'alegra-connector'),
            'manage_woocommerce',
            'alegra-connector-stats',
            [$this, 'render_statistics_page']
        );

        add_submenu_page(
            'alegra-connector',
            __('Productos', 'alegra-connector'),
            __('Productos', 'alegra-connector'),
            'manage_woocommerce',
            'alegra-connector-products',
            [$this, 'render_products_page']
        );

        add_submenu_page(
            'alegra-connector',
            __('Clientes', 'alegra-connector'),
            __('Clientes', 'alegra-connector'),
            'manage_woocommerce',
            'alegra-connector-customers',
            [$this, 'render_customers_page']
        );

        add_submenu_page(
            'alegra-connector',
            __('Pedidos', 'alegra-connector'),
            __('Pedidos', 'alegra-connector'),
            'manage_woocommerce',
            'alegra-connector-orders',
            [$this, 'render_orders_page']
        );

        add_submenu_page(
            'alegra-connector',
            __('Mapeo de Campos', 'alegra-connector'),
            __('Mapeo', 'alegra-connector'),
            'manage_woocommerce',
            'alegra-connector-mapping',
            [$this, 'render_mapping_page']
        );

        add_submenu_page(
            'alegra-connector',
            __('Logs', 'alegra-connector'),
            __('Logs', 'alegra-connector'),
            'manage_woocommerce',
            'alegra-connector-logs',
            [$this, 'render_logs_page']
        );

        add_submenu_page(
            'alegra-connector',
            __('Importar', 'alegra-connector'),
            __('Importar', 'alegra-connector'),
            'manage_woocommerce',
            'alegra-connector-import',
            [$this, 'render_import_page']
        );

        add_submenu_page(
            'alegra-connector',
            __('ConfiguraciÃ³n', 'alegra-connector'),
            __('ConfiguraciÃ³n', 'alegra-connector'),
            'manage_woocommerce',
            'alegra-connector-settings',
            [$this, 'render_settings_page']
        );

        add_submenu_page(
            'alegra-connector',
            __('DocumentaciÃ³n', 'alegra-connector'),
            __('DocumentaciÃ³n', 'alegra-connector'),
            'manage_woocommerce',
            'alegra-connector-docs',
            [$this, 'render_docs_page']
        );
    }

    public function register_settings(): void
    {
        register_setting('alegra_connector_settings', 'alegra_connector_email', ['sanitize_callback' => 'sanitize_email']);
        register_setting('alegra_connector_settings', 'alegra_connector_token', ['sanitize_callback' => 'sanitize_text_field']);
        register_setting('alegra_connector_settings', 'alegra_connector_api_url', [
            'sanitize_callback' => function ($value) {
                $url = sanitize_url($value);
                return $url ?: 'https://api.alegra.com/api/v1';
            },
        ]);
        register_setting('alegra_connector_settings', 'alegra_connector_sync_frequency', ['sanitize_callback' => 'intval']);
        register_setting('alegra_connector_settings', 'alegra_connector_sync_method', ['sanitize_callback' => 'sanitize_text_field']);
        register_setting('alegra_connector_settings', 'alegra_connector_currency', ['sanitize_callback' => 'sanitize_text_field']);
        register_setting('alegra_connector_settings', 'alegra_connector_log_retention_days', ['sanitize_callback' => 'intval']);
        register_setting('alegra_connector_settings', 'alegra_connector_conflict_resolution', ['sanitize_callback' => 'sanitize_text_field']);
        register_setting('alegra_connector_settings', 'alegra_connector_sync_products', ['sanitize_callback' => 'rest_sanitize_boolean']);
        register_setting('alegra_connector_settings', 'alegra_connector_sync_customers', ['sanitize_callback' => 'rest_sanitize_boolean']);
        register_setting('alegra_connector_settings', 'alegra_connector_sync_orders', ['sanitize_callback' => 'rest_sanitize_boolean']);
        register_setting('alegra_connector_settings', 'alegra_connector_sync_categories', ['sanitize_callback' => 'rest_sanitize_boolean']);
        register_setting('alegra_connector_settings', 'alegra_connector_inventory_source', ['sanitize_callback' => 'sanitize_text_field']);
        register_setting('alegra_connector_settings', 'alegra_connector_warehouse_id', ['sanitize_callback' => 'intval']);
        register_setting('alegra_connector_settings', 'alegra_connector_warehouse_enabled', ['sanitize_callback' => 'rest_sanitize_boolean']);
        register_setting('alegra_connector_settings', 'alegra_connector_webhook_enabled', ['sanitize_callback' => 'rest_sanitize_boolean']);
        register_setting('alegra_connector_settings', 'alegra_connector_payment_account_id', ['sanitize_callback' => 'intval']);
        register_setting('alegra_connector_settings', 'alegra_connector_payment_term_id', ['sanitize_callback' => 'intval']);
        register_setting('alegra_connector_settings', 'alegra_connector_webhook_secret', ['sanitize_callback' => 'sanitize_text_field']);
        register_setting('alegra_connector_settings', 'alegra_connector_auto_complete_order', ['sanitize_callback' => 'rest_sanitize_boolean']);
        register_setting('alegra_connector_settings', 'alegra_connector_sync_images', ['sanitize_callback' => 'rest_sanitize_boolean']);
        register_setting('alegra_connector_settings', 'alegra_connector_field_mapping', [
            'sanitize_callback' => function ($value) {
                return is_array($value) ? map_deep($value, 'sanitize_text_field') : [];
            },
        ]);
        register_setting('alegra_connector_settings', 'alegra_connector_tax_mapping', [
            'sanitize_callback' => function ($value) {
                return is_array($value) ? map_deep($value, 'sanitize_text_field') : [];
            },
        ]);

        // Mapping settings group
        register_setting('alegra_connector_mapping', 'alegra_connector_field_mapping');
        register_setting('alegra_connector_mapping', 'alegra_connector_tax_mapping');

        add_settings_section('alegra_connector_connection', __('ConexiÃ³n con Alegra', 'alegra-connector'), fn() => null, 'alegra_connector_settings');
        add_settings_section('alegra_connector_sync_settings', __('SincronizaciÃ³n', 'alegra-connector'), fn() => null, 'alegra_connector_settings');
        add_settings_section('alegra_connector_currency_section', __('Moneda', 'alegra-connector'), fn() => null, 'alegra_connector_settings');
        add_settings_section('alegra_connector_warehouse_section', __('Bodegas', 'alegra-connector'), fn() => null, 'alegra_connector_settings');
        add_settings_section('alegra_connector_advanced', __('Avanzado', 'alegra-connector'), fn() => null, 'alegra_connector_settings');
    }

    public function enqueue_assets(string $hook): void
    {
        if (strpos($hook, 'alegra-connector') === false) {
            return;
        }

        wp_enqueue_style('alegra-connector-admin', ALEGRA_CONNECTOR_URL . 'admin/assets/css/admin.css', [], ALEGRA_CONNECTOR_VERSION);
        wp_enqueue_script('alegra-connector-admin', ALEGRA_CONNECTOR_URL . 'admin/assets/js/admin.js', ['jquery'], ALEGRA_CONNECTOR_VERSION, true);

        wp_localize_script('alegra-connector-admin', 'alegraConnector', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('alegra_connector_nonce'),
            'strings' => [
                'testing' => __('Probando conexiÃ³n...', 'alegra-connector'),
                'success' => __('ConexiÃ³n exitosa', 'alegra-connector'),
                'error' => __('Error de conexiÃ³n', 'alegra-connector'),
                'syncing' => __('Sincronizando...', 'alegra-connector'),
                'importing' => __('Importando...', 'alegra-connector'),
            ],
        ]);
    }

    public function render_dashboard(): void
    {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('No tienes permisos para acceder a esta pÃ¡gina.', 'alegra-connector'));
        }

        $is_connected = (bool) get_option('alegra_connector_connection_tested');
        $company_name = esc_html(get_option('alegra_connector_company_name', ''));
        $last_sync = get_transient('alegra_connector_last_sync');
        $stats = $this->get_sync_stats();
        $header_color = 'indigo';

        include ALEGRA_CONNECTOR_PATH . 'templates/admin-dashboard.php';
    }

    public function render_settings_page(): void
    {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('No tienes permisos para acceder a esta pÃ¡gina.', 'alegra-connector'));
        }

        $connected = (bool) get_option('alegra_connector_connection_tested');
        $alegra_currencies = [];
        $alegra_warehouses = [];
        $alegra_bank_accounts = [];
        $alegra_terms = [];

        if ($connected && $this->api) {
            $cr = $this->api->get_currencies();
            if (!is_wp_error($cr)) $alegra_currencies = $cr;
            $wr = $this->api->get_warehouses();
            if (!is_wp_error($wr)) $alegra_warehouses = $wr;
            $ba = $this->api->get_bank_accounts();
            if (!is_wp_error($ba)) $alegra_bank_accounts = $ba;
            $tm = $this->api->get_terms();
            if (!is_wp_error($tm)) $alegra_terms = $tm;
        }

        include ALEGRA_CONNECTOR_PATH . 'templates/admin-settings.php';
    }

    public function render_docs_page(): void
    {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('No tienes permisos.', 'alegra-connector'));
        }

        $doc_file = ALEGRA_CONNECTOR_PATH . 'docs/DOCUMENTACION.md';
        $content = '';
        if (file_exists($doc_file)) {
            $content = file_get_contents($doc_file);
        }

        $header_color = 'indigo';
        include ALEGRA_CONNECTOR_PATH . 'templates/admin-docs.php';
    }

    public function render_logs_page(): void
    {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('No tienes permisos para acceder a esta pÃ¡gina.', 'alegra-connector'));
        }

        $log_files = $this->logger ? $this->logger->get_log_files() : [];
        $log_entries = $this->logger ? $this->logger->get_logs(200) : [];
        $system_logs = $this->logger ? $this->logger->get_system_logs(50) : [];

        // Log Statistics
        $log_stats = ['total' => 0, 'info' => 0, 'warning' => 0, 'error' => 0, 'critical' => 0, 'today' => 0, 'system' => count($system_logs)];
        foreach ($log_entries as $entry) {
            $log_stats['total']++;
            $lv = strtolower($entry['level'] ?? '');
            if (isset($log_stats[$lv])) $log_stats[$lv]++;
            if (strpos($entry['timestamp'] ?? '', date('Y-m-d')) === 0) $log_stats['today']++;
        }

        $header_color = 'purple';

        include ALEGRA_CONNECTOR_PATH . 'templates/admin-logs.php';
    }

    public function render_import_page(): void
    {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('No tienes permisos para acceder a esta pÃ¡gina.', 'alegra-connector'));
        }

        $header_color = 'green';

        include ALEGRA_CONNECTOR_PATH . 'templates/admin-import.php';
    }

    public function render_mapping_page(): void
    {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('No tienes permisos para acceder a esta pÃ¡gina.', 'alegra-connector'));
        }

        $field_mapping = get_option('alegra_connector_field_mapping', []);
        $tax_mapping = get_option('alegra_connector_tax_mapping', []);
        $connected = (bool) get_option('alegra_connector_connection_tested');

        $alegra_taxes = [];
        $alegra_price_lists = [];
        $alegra_categories = [];

        if ($connected && $this->api) {
            $t = $this->api->get_taxes();
            if (!is_wp_error($t)) { $alegra_taxes = $t; }
            $p = $this->api->get_price_lists();
            if (!is_wp_error($p)) { $alegra_price_lists = $p; }
            $c = $this->api->get_item_categories();
            if (!is_wp_error($c)) { $alegra_categories = $c; }
        }

        $header_color = 'indigo';

        include ALEGRA_CONNECTOR_PATH . 'templates/admin-mapping.php';
    }

    public function render_statistics_page(): void
    {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('No tienes permisos.', 'alegra-connector'));
        }

        // Default period: last 30 days
        $end = isset($_GET['end']) ? sanitize_text_field($_GET['end']) : date('Y-m-d');
        $start = isset($_GET['start']) ? sanitize_text_field($_GET['start']) : date('Y-m-d', strtotime('-30 days'));
        $period = isset($_GET['period']) ? sanitize_text_field($_GET['period']) : '30d';

        $stats = $this->get_statistics_data($start, $end, $period);
        $header_color = 'blue';

        include ALEGRA_CONNECTOR_PATH . 'templates/admin-statistics.php';
    }

    private function get_statistics_data(string $start, string $end, string $period = '30d'): array
    {
        $max_orders = 500;
        $currency_symbol = function_exists('get_woocommerce_currency_symbol') ? get_woocommerce_currency_symbol() : '$';

        // Orders in period
        $orders = wc_get_orders([
            'limit' => $max_orders,
            'return' => 'ids',
            'date_after' => $start,
            'date_before' => $end . ' 23:59:59',
            'orderby' => 'date',
            'order' => 'DESC',
        ]);

        // Previous period for comparison
        $interval = strtotime($end) - strtotime($start) + 86400;
        $prev_start = date('Y-m-d', strtotime($start) - $interval);
        $prev_end = date('Y-m-d', strtotime($start) - 86400);
        $prev_orders = wc_get_orders([
            'limit' => $max_orders,
            'return' => 'ids',
            'date_after' => $prev_start,
            'date_before' => $prev_end . ' 23:59:59',
        ]);

        // Revenue by status
        $revenue = ['completed' => 0, 'processing' => 0, 'pending' => 0, 'cancelled' => 0, 'refunded' => 0, 'total' => 0];
        $order_counts = ['completed' => 0, 'processing' => 0, 'pending' => 0, 'cancelled' => 0, 'refunded' => 0, 'total' => 0];
        $payment_methods = [];
        $daily_sales = [];
        $top_products = [];
        $recent_orders = [];

        foreach ($orders as $order_id) {
            $order = wc_get_order($order_id);
            if (!$order) continue;

            $status = $order->get_status();
            $total = (float) $order->get_total();
            $revenue['total'] += $total;
            $order_counts['total']++;

            if ($status === 'completed') { $revenue['completed'] += $total; $order_counts['completed']++; }
            elseif ($status === 'processing') { $revenue['processing'] += $total; $order_counts['processing']++; }
            elseif ($status === 'pending') { $revenue['pending'] += $total; $order_counts['pending']++; }
            elseif ($status === 'cancelled') { $revenue['cancelled'] += $total; $order_counts['cancelled']++; }
            elseif ($status === 'refunded') { $revenue['refunded'] += $total; $order_counts['refunded']++; }

            // Payment methods
            $pm = $order->get_payment_method_title() ?: 'Unknown';
            if (!isset($payment_methods[$pm])) { $payment_methods[$pm] = ['count' => 0, 'total' => 0]; }
            $payment_methods[$pm]['count']++;
            $payment_methods[$pm]['total'] += $total;

            // Daily sales
            $date = $order->get_date_created() ? $order->get_date_created()->date('Y-m-d') : '';
            if ($date) {
                if (!isset($daily_sales[$date])) { $daily_sales[$date] = ['count' => 0, 'total' => 0]; }
                $daily_sales[$date]['count']++;
                $daily_sales[$date]['total'] += $total;
            }

            // Recent orders (last 5)
            if (count($recent_orders) < 5) {
                $recent_orders[] = [
                    'id' => $order_id,
                    'date' => $date,
                    'customer' => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
                    'total' => $total,
                    'status' => $status,
                ];
            }

            // Top products
            foreach ($order->get_items() as $item) {
                $name = $item->get_name();
                $qty = (int) $item->get_quantity();
                if (!isset($top_products[$name])) { $top_products[$name] = ['qty' => 0, 'total' => 0, 'orders' => 0]; }
                $top_products[$name]['qty'] += $qty;
                $top_products[$name]['total'] += (float) $item->get_total();
                $top_products[$name]['orders']++;
            }
        }

        // Previous period revenue for comparison
        $prev_revenue = 0;
        foreach ($prev_orders as $oid) {
            $o = wc_get_order($oid);
            if ($o) $prev_revenue += (float) $o->get_total();
        }

        // Growth calculation
        $growth = 0;
        if ($prev_revenue > 0 && $revenue['total'] > 0) {
            $growth = round((($revenue['total'] - $prev_revenue) / $prev_revenue) * 100, 1);
        }

        // Abandoned carts - pending + cancelled orders
        $abandoned_count = $order_counts['pending'] + $order_counts['cancelled'];
        $abandoned_value = $revenue['pending'] + $revenue['cancelled'];
        $abandoned_rate = $order_counts['total'] > 0 ? round(($abandoned_count / $order_counts['total']) * 100, 1) : 0;

        // Conversion rate (completed / total)
        $conversion_rate = $order_counts['total'] > 0 ? round(($order_counts['completed'] / $order_counts['total']) * 100, 1) : 0;

        // Average order value
        $avg_order = $order_counts['completed'] > 0 ? $revenue['completed'] / $order_counts['completed'] : 0;

        // Sort
        uasort($top_products, fn($a, $b) => $b['qty'] <=> $a['qty']);
        $top_products = array_slice($top_products, 0, 10);
        ksort($daily_sales);

        // Customers
        $customers = count_users();
        $total_customers = $customers['avail_roles']['customer'] ?? 0;
        $new_customers = 0;
        $recent_users = get_users([
            'role' => 'customer', 'fields' => 'ID', 'number' => 500,
            'date_query' => [['after' => $start, 'before' => $end . ' 23:59:59', 'inclusive' => true]],
        ]);
        $new_customers = count($recent_users);

        // Sync status
        $sync_stats = [
            'products_synced' => 0, 'products_total' => 0,
            'orders_synced' => 0, 'orders_total' => 0,
            'customers_synced' => 0, 'customers_total' => $total_customers,
        ];
        $all_products = wc_get_products(['limit' => 500, 'return' => 'ids', 'status' => 'publish']);
        $sync_stats['products_total'] = count($all_products);
        foreach ($all_products as $pid) {
            if ((int) get_post_meta($pid, '_alegra_item_id', true) > 0) $sync_stats['products_synced']++;
        }
        $all_orders = wc_get_orders(['limit' => 500, 'return' => 'ids']);
        $sync_stats['orders_total'] = count($all_orders);
        foreach ($all_orders as $oid) {
            if ((int) get_post_meta($oid, '_alegra_invoice_id', true) > 0) $sync_stats['orders_synced']++;
        }
        $customers_synced = 0;
        if ($total_customers > 0) {
            $sample = get_users(['role' => 'customer', 'fields' => 'ID', 'number' => 200]);
            foreach ($sample as $cid) {
                if ((int) get_user_meta($cid, 'alegra_contact_id', true) > 0) $customers_synced++;
            }
        }
        $sync_stats['customers_synced'] = $customers_synced;

        return compact(
            'revenue', 'order_counts', 'payment_methods', 'daily_sales',
            'top_products', 'sync_stats', 'new_customers', 'start', 'end', 'period',
            'currency_symbol', 'growth', 'prev_revenue', 'abandoned_count', 'abandoned_value',
            'abandoned_rate', 'conversion_rate', 'avg_order', 'recent_orders'
        );
    }

    public function render_products_page(): void
    {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('No tienes permisos.', 'alegra-connector'));
        }

        $page = isset($_GET['paged']) ? max(1, (int) $_GET['paged']) : 1;
        $per_page = 20;

        // Check for single product detail view
        $product_id = isset($_GET['product_id']) ? (int) $_GET['product_id'] : 0;
        if ($product_id > 0) {
            $this->render_product_detail($product_id);
            return;
        }

        global $wpdb;

        // Direct SQL for reliable count
        $total = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type='product' AND post_status='publish'");
        $total_pages = (int) ceil($total / $per_page);
        $offset = ($page - 1) * $per_page;

        // Get product IDs via direct SQL, then load WC_Product objects
        $ids = $wpdb->get_col($wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts} WHERE post_type='product' AND post_status='publish' ORDER BY ID DESC LIMIT %d OFFSET %d",
            $per_page, $offset
        ));

        $products = [];
        foreach ($ids as $id) {
            $p = wc_get_product((int)$id);
            if ($p) $products[] = $p;
        }

        // Sync stats - also via SQL for reliability
        $synced_count = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key='_alegra_item_id'");
        $variable_count = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->posts} p 
             INNER JOIN {$wpdb->term_relationships} tr ON p.ID=tr.object_id 
             INNER JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id=tt.term_taxonomy_id 
             INNER JOIN {$wpdb->terms} t ON tt.term_id=t.term_id 
             WHERE p.post_type='product' AND p.post_status='publish' AND tt.taxonomy='product_type' AND t.slug='variable'"
        );

        $header_color = 'green';

        include ALEGRA_CONNECTOR_PATH . 'templates/admin-products.php';
    }

    private function render_product_detail(int $product_id): void
    {
        $product = wc_get_product($product_id);
        if (!$product) {
            wp_die(esc_html__('Producto no encontrado.', 'alegra-connector'));
        }

        $alegra_id = (int) get_post_meta($product_id, '_alegra_item_id', true);
        $alegra_data = null;
        $alegra_error = null;

        if ($alegra_id > 0 && get_option('alegra_connector_connection_tested') && $this->api) {
            $result = $this->api->get_item($alegra_id);
            if (is_wp_error($result)) {
                $alegra_error = sprintf(__('Error de Alegra: %s', 'alegra-connector'), $result->get_error_message());
            } else {
                $alegra_data = $result;
            }
        }

        include ALEGRA_CONNECTOR_PATH . 'templates/admin-product-detail.php';
    }

    public function render_customers_page(): void
    {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('No tienes permisos.', 'alegra-connector'));
        }

        $page = isset($_GET['paged']) ? max(1, (int) $_GET['paged']) : 1;
        $per_page = 20;

        // Single customer detail
        $customer_id = isset($_GET['customer_id']) ? (int) $_GET['customer_id'] : 0;
        if ($customer_id > 0) {
            $this->render_customer_detail($customer_id);
            return;
        }

        $args = [
            'role' => 'customer',
            'number' => $per_page,
            'paged' => $page,
            'orderby' => 'ID',
            'order' => 'DESC',
        ];

        $customers = get_users($args);
        $total_users = count(get_users(['role' => 'customer', 'fields' => 'ID']));
        $total_pages = (int) ceil($total_users / $per_page);

        // Sync stats
        $synced_customers = 0;
        $all_cust = get_users(['role' => 'customer', 'fields' => 'ID', 'number' => 200]);
        foreach ($all_cust as $cid) {
            if ((int) get_user_meta($cid, 'alegra_contact_id', true) > 0) $synced_customers++;
        }

        $header_color = 'teal';

        include ALEGRA_CONNECTOR_PATH . 'templates/admin-customers.php';
    }

    private function render_customer_detail(int $customer_id): void
    {
        $customer = get_userdata($customer_id);
        if (!$customer) {
            wp_die(esc_html__('Cliente no encontrado.', 'alegra-connector'));
        }

        $alegra_id = (int) get_user_meta($customer_id, 'alegra_contact_id', true);
        $alegra_data = null;
        $alegra_error = null;

        if ($alegra_id > 0 && get_option('alegra_connector_connection_tested') && $this->api) {
            $result = $this->api->get_contact($alegra_id);
            if (is_wp_error($result)) {
                $alegra_error = sprintf(__('Error de Alegra: %s', 'alegra-connector'), $result->get_error_message());
            } else {
                $alegra_data = $result;
            }
        }

        include ALEGRA_CONNECTOR_PATH . 'templates/admin-customer-detail.php';
    }

    public function render_orders_page(): void
    {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('No tienes permisos.', 'alegra-connector'));
        }

        $page = isset($_GET['paged']) ? max(1, (int) $_GET['paged']) : 1;
        $per_page = 20;

        // Single order detail
        $order_id = isset($_GET['order_id']) ? (int) $_GET['order_id'] : 0;
        if ($order_id > 0) {
            $this->render_order_detail($order_id);
            return;
        }

        $args = [
            'limit' => $per_page,
            'page' => $page,
            'orderby' => 'date',
            'order' => 'DESC',
        ];

        $orders = wc_get_orders($args);
        $total_orders = count(wc_get_orders(['limit' => -1, 'return' => 'ids']));
        $total_pages = (int) ceil($total_orders / $per_page);

        // Sync stats
        $synced_orders = 0;
        $all_oids = wc_get_orders(['limit' => 500, 'return' => 'ids']);
        foreach ($all_oids as $oid) {
            if ((int) get_post_meta($oid, '_alegra_invoice_id', true) > 0) $synced_orders++;
        }

        $header_color = 'amber';

        include ALEGRA_CONNECTOR_PATH . 'templates/admin-orders.php';
    }

    private function render_order_detail(int $order_id): void
    {
        $order = wc_get_order($order_id);
        if (!$order) {
            wp_die(esc_html__('Pedido no encontrado.', 'alegra-connector'));
        }

        $alegra_invoice_id = (int) get_post_meta($order_id, '_alegra_invoice_id', true);
        $alegra_invoice_number = get_post_meta($order_id, '_alegra_invoice_number', true);
        $alegra_payment_id = (int) get_post_meta($order_id, '_alegra_payment_id', true);
        $alegra_data = null;
        $alegra_error = null;

        // Make API available for templates
        $GLOBALS['alegra_api'] = $this->api;

        if ($alegra_invoice_id > 0 && get_option('alegra_connector_connection_tested') && $this->api) {
            $result = $this->api->get_invoice($alegra_invoice_id);
            if (is_wp_error($result)) {
                $alegra_error = sprintf(__('Error de Alegra: %s', 'alegra-connector'), $result->get_error_message());
            } else {
                $alegra_data = $result;
            }
        }

        include ALEGRA_CONNECTOR_PATH . 'templates/admin-order-detail.php';
    }

    public function ajax_test_connection(): void
    {
        check_ajax_referer('alegra_connector_nonce');

        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(['message' => __('No tienes permisos.', 'alegra-connector')]);
        }

        $email = sanitize_email($_POST['email'] ?? '');
        $token = sanitize_text_field($_POST['token'] ?? '');

        if (empty($email) || empty($token)) {
            wp_send_json_error(['message' => __('Email y token son requeridos.', 'alegra-connector')]);
        }

        $this->log('info', 'Connection test started', ['email' => $email]);

        // Save credentials
        update_option('alegra_connector_email', $email);
        update_option('alegra_connector_token', $token);

        // Quick pre-flight: verify the API URL is reachable
        $base_url = rtrim((string) get_option('alegra_connector_api_url', 'https://api.alegra.com/api/v1'), '/');
        $preflight = wp_remote_head($base_url . '/company', [
            'timeout' => 5,
            'headers' => [
                'Authorization' => 'Basic ' . base64_encode($email . ':' . $token),
            ],
        ]);

        if (is_wp_error($preflight)) {
            update_option('alegra_connector_connection_tested', false);
            $this->log('error', 'Connection test: network unreachable', ['error' => $preflight->get_error_message()]);
            wp_send_json_error([
                'message' => __('No se pudo contactar el servidor de Alegra.', 'alegra-connector'),
                'code' => 'network_error',
                'http_code' => 0,
            ]);
        }

        if (!is_wp_error($preflight)) {
            $result = $this->api->test_connection($email, $token);
        } else {
            $result = $preflight;
        }

        if (is_wp_error($result)) {
            update_option('alegra_connector_connection_tested', false);
            $code = $result->get_error_code();
            $msg = $result->get_error_message();
            $data = $result->get_error_data();
            $http_code = is_array($data) ? ($data['code'] ?? 0) : 0;

            $this->log('error', 'Connection test failed', [
                'error_code' => $code, 'http_code' => $http_code, 'message' => $msg,
            ]);

            wp_send_json_error([
                'message' => $msg,
                'code' => $code,
                'http_code' => $http_code,
            ]);
        }

        // Save connection info
        if (isset($result['company'])) {
            update_option('alegra_connector_company_name', sanitize_text_field($result['company']));
        }
        if (isset($result['country'])) {
            update_option('alegra_connector_company_country', sanitize_text_field($result['country']));
        }
        if (isset($result['email'])) {
            update_option('alegra_connector_company_email', sanitize_text_field($result['email']));
        }
        if (isset($result['items_count'])) {
            update_option('alegra_connector_items_count', (int) $result['items_count']);
        }
        if (isset($result['contacts_count'])) {
            update_option('alegra_connector_contacts_count', (int) $result['contacts_count']);
        }
        update_option('alegra_connector_connection_tested', true);

        $diagnostics = $result['diagnostics'] ?? [];
        update_option('alegra_connector_diagnostics', $diagnostics);

        $this->log('info', 'Connection test successful', ['company' => $result['company'] ?? 'Unknown', 'diagnostics' => $diagnostics]);

        wp_send_json_success([
            'message' => __('Conexion exitosa', 'alegra-connector'),
            'company' => $result['company'] ?? '',
            'country' => $result['country'] ?? '',
            'email' => $result['email'] ?? '',
            'items_count' => $result['items_count'] ?? 0,
            'contacts_count' => $result['contacts_count'] ?? 0,
            'diagnostics' => $diagnostics,
        ]);
    }

    public function ajax_sync_now(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) wp_send_json_error(['message' => __('No tienes permisos.', 'alegra-connector')]);

        $sync_type = sanitize_text_field($_POST['sync_type'] ?? 'all');
        $sync_controller = new Sync\Controller($this->api, $this->logger);

        if ($sync_type === 'all') {
            $sync_controller->run_cron_sync();
            wp_send_json_success(['message' => __('Sincronizacion completa.', 'alegra-connector')]);
        }
        // For specific types, redirect to chunked sync via JS (handled by ajax_sync_start + ajax_sync_page)
        wp_send_json_success(['message' => 'ok', 'use_chunked' => true, 'type' => $sync_type]);
    }

    /**
     * AJAX: Start chunked sync - get EXACT total via metadata=true
     */
    public function ajax_sync_start(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) wp_send_json_error();

        $type = sanitize_text_field($_POST['sync_type'] ?? 'products');
        $this->api->reload_credentials();

        // Get exact total via metadata=true (single API call!)
        $total = 0;
        $resp = $this->api->get('/items', ['metadata' => 'true', 'limit' => 1]);
        if (!is_wp_error($resp) && isset($resp['metadata']['total'])) {
            $total = (int) $resp['metadata']['total'];
        }

        $per_page = 30;
        $total_pages = $total > 0 ? (int) ceil($total / $per_page) : 1;

        $state = [
            'type' => $type, 'page' => 0, 'per_page' => $per_page,
            'total_pages' => $total_pages, 'total_items' => $total,
            'imported' => 0, 'updated' => 0, 'errors' => 0,
        ];
        set_transient('alegra_batch_state', $state, 600);

        wp_send_json_success([
            'total_pages' => $total_pages, 'total_items' => $total, 'per_page' => $per_page,
        ]);
    }

    /**
     * Process one page of chunked sync
     */
    public function ajax_sync_page(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) wp_send_json_error();

        $state = get_transient('alegra_batch_state');
        if (!$state) wp_send_json_error(['message' => 'No batch in progress']);

        $page = ((int) ($state['page'] ?? 0)) + 1;
        $type = $state['type'];
        $per_page = 30; // Max allowed by Alegra API
        $this->api->reload_credentials();
        @set_time_limit(60);

        if ($type === 'products') {
            $start = ($page - 1) * $per_page;
            // Use mode=advanced to get images and attachments
            $items = $this->api->get('/items', ['start' => $start, 'limit' => $per_page, 'mode' => 'advanced']);
            if (is_wp_error($items)) { wp_send_json_error(['message' => $items->get_error_message()]); }
            foreach ($items as $item) {
                $alegra_id = (int) ($item['id'] ?? 0);
                // Skip duplicates
                if ($alegra_id > 0 && $this->get_product_by_alegra_id($alegra_id)) { $state['updated']++; continue; }
                $sku = sanitize_text_field($item['reference'] ?? '');
                if (!empty($sku)) {
                    $existing_sku_id = wc_get_product_id_by_sku($sku);
                    if ($existing_sku_id) {
                        update_post_meta($existing_sku_id, '_alegra_item_id', $alegra_id);
                        $state['updated']++;
                        continue;
                    }
                }

                $product_id = wp_insert_post([
                    'post_title' => $item['name'] ?? 'Producto',
                    'post_type' => 'product',
                    'post_status' => 'publish',
                ]);
                if (!is_wp_error($product_id) && $product_id) {
                    update_post_meta($product_id, '_alegra_item_id', $alegra_id);
                    update_post_meta($product_id, '_sku', $item['reference'] ?? '');
                    if (!empty($item['price'])) {
                        $price = 0;
                        if (is_array($item['price'])) {
                            foreach ($item['price'] as $pe) {
                                if (isset($pe['idPriceList']) && (int)$pe['idPriceList'] === 1) { $price = (float)($pe['price'] ?? 0); break; }
                            }
                            if ($price === 0 && isset($item['price'][0]['price'])) $price = (float)$item['price'][0]['price'];
                        } else { $price = (float)$item['price']; }
                        update_post_meta($product_id, '_regular_price', $price);
                        update_post_meta($product_id, '_price', $price);
                    }
                    // Download image from Alegra (mode=advanced returns images array)
                    if (get_option('alegra_connector_sync_images', true)) {
                        $img_url = '';
                        if (!empty($item['images']) && is_array($item['images'])) {
                            $first = $item['images'][0];
                            $img_url = is_array($first) ? ($first['url'] ?? '') : '';
                        }
                        if (!empty($img_url)) {
                            $this->import_product_image($product_id, $img_url);
                        }
                    }
                    $state['imported']++;
                } else {
                    $state['errors']++;
                }
            }
            $is_last = count($items) < $per_page;
        } elseif ($type === 'customers') {
            $start = ($page - 1) * $per_page;
            $items = $this->api->get('/contacts', ['start' => $start, 'limit' => $per_page, 'type' => 'client']);
            if (is_wp_error($items)) { wp_send_json_error(['message' => $items->get_error_message()]); }
            foreach ($items as $item) {
                $email = $item['email'] ?? '';
                if (empty($email)) { $state['errors']++; continue; }
                $uid = email_exists($email);
                if ($uid) {
                    update_user_meta($uid, 'alegra_contact_id', (int)($item['id'] ?? 0));
                    $state['updated']++;
                } else {
                    $np = explode(' ', ($item['name'] ?? ''), 2);
                    $uid = wp_insert_user([
                        'user_email' => $email, 'user_login' => $email,
                        'first_name' => $np[0] ?? '', 'last_name' => $np[1] ?? '',
                        'role' => 'customer',
                    ]);
                    if (!is_wp_error($uid)) {
                        update_user_meta($uid, 'alegra_contact_id', (int)($item['id'] ?? 0));
                        $state['imported']++;
                    } else { $state['errors']++; }
                }
            }
            $is_last = count($items) < $per_page;
        } else {
            $items = $this->api->get_item_categories(['page' => $page, 'limit' => $per_page]);
            if (is_wp_error($items)) { wp_send_json_error(['message' => $items->get_error_message()]); }
            foreach ($items as $item) {
                $t = wp_insert_term($item['name'] ?? '', 'product_cat', ['description' => $item['description'] ?? '']);
                if (!is_wp_error($t)) {
                    update_term_meta($t['term_id'], 'alegra_category_id', (int)($item['id'] ?? 0));
                    $state['imported']++;
                } else { $state['errors']++; }
            }
            $is_last = count($items) < $per_page;
        }

        $state['page'] = $page;
        $item_count = is_array($items) ? count($items) : 0;
        if ($is_last) {
            $state['total_pages'] = $page;
            $state['total_items'] = (($page - 1) * $per_page) + $item_count;
        }

        set_transient('alegra_batch_state', $state, 600);

        $processed = $state['imported'] + $state['updated'] + $state['errors'];
        $tp = (int)($state['total_pages'] ?? 0);
        // Safety: stop if page exceeds total or items are empty
        $done = $is_last || ($tp > 0 && $page >= $tp) || empty($items);
        $pct = $tp > 0 ? min(100, round(($page / $tp) * 100)) : 0;
        wp_send_json_success([
            'page' => $page, 'total_pages' => $tp, 'total_items' => (int)($state['total_items'] ?? 0),
            'imported' => $state['imported'], 'updated' => $state['updated'], 'errors' => $state['errors'],
            'processed' => $processed, 'percent' => $pct, 'done' => $done,
            'message' => sprintf('%d/%d items — Pag. %d/%d', $processed, (int)($state['total_items'] ?? 0), $page, $tp),
        ]);
    }
    public function ajax_import_csv(): void
    {
        check_ajax_referer('alegra_connector_nonce');

        if (!current_user_can('upload_files')) {
            wp_send_json_error(['message' => __('No tienes permisos.', 'alegra-connector')]);
        }

        if (!isset($_FILES['csv_file'])) {
            wp_send_json_error(['message' => __('No se encontrÃ³ archivo CSV.', 'alegra-connector')]);
        }

        $file = $_FILES['csv_file'];

        if ($file['error'] !== UPLOAD_ERR_OK) {
            wp_send_json_error(['message' => __('Error al subir archivo.', 'alegra-connector')]);
        }

        $import_type = sanitize_text_field($_POST['import_type'] ?? 'products');

        $result = $this->process_csv_import($file['tmp_name'], $import_type);

        if (is_wp_error($result)) {
            wp_send_json_error(['message' => sprintf(__('Error de Alegra: %s', 'alegra-connector'), $result->get_error_message())]);
        }

        wp_send_json_success([
            'message' => sprintf(__('ImportaciÃ³n completada: %d items', 'alegra-connector'), $result['count']),
            'data' => $result,
        ]);
    }

    public function ajax_clear_logs(): void
    {
        check_ajax_referer('alegra_connector_nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('No tienes permisos.', 'alegra-connector')]);
        }

        if ($this->logger === null) {
            wp_send_json_error(['message' => __('Logger no inicializado.', 'alegra-connector')]);
        }

        $retention = (int) get_option('alegra_connector_log_retention_days', 30);
        $count = $this->logger->clear_old_logs($retention);

        wp_send_json_success(['message' => sprintf(__('%d logs eliminados.', 'alegra-connector'), $count)]);
    }

    public function ajax_download_logs(): void
    {
        check_ajax_referer('alegra_connector_nonce');

        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('No tienes permisos.', 'alegra-connector'));
        }

        $log_file = sanitize_text_field($_GET['log_file'] ?? '');
        $this->logger->download_log($log_file);
    }

    public function ajax_save_mapping(): void
    {
        check_ajax_referer('alegra_connector_nonce');

        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(['message' => __('No tienes permisos.', 'alegra-connector')]);
        }

        $field_mapping = isset($_POST['field_mapping']) ? (array) $_POST['field_mapping'] : [];
        $tax_mapping = isset($_POST['tax_mapping']) ? (array) $_POST['tax_mapping'] : [];

        update_option('alegra_connector_field_mapping', map_deep($field_mapping, 'sanitize_text_field'));
        update_option('alegra_connector_tax_mapping', map_deep($tax_mapping, 'sanitize_text_field'));

        $this->logger->info('Field mapping saved');

        wp_send_json_success(['message' => __('Mapeo guardado.', 'alegra-connector')]);
    }

    public function ajax_record_payment(): void
    {
        check_ajax_referer('alegra_connector_nonce');

        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(['message' => __('No tienes permisos.', 'alegra-connector')]);
        }

        $order_id = (int) ($_POST['order_id'] ?? 0);
        if ($order_id <= 0) {
            wp_send_json_error(['message' => __('ID de pedido invÃ¡lido.', 'alegra-connector')]);
        }

        $order = wc_get_order($order_id);
        if (!$order) {
            wp_send_json_error(['message' => __('Pedido no encontrado.', 'alegra-connector')]);
        }

        $alegra_invoice_id = (int) get_post_meta($order_id, '_alegra_invoice_id', true);
        if ($alegra_invoice_id <= 0) {
            wp_send_json_error(['message' => __('Primero crea la factura en Alegra.', 'alegra-connector')]);
        }

        // Check if payment already recorded
        $existing_payment = (int) get_post_meta($order_id, '_alegra_payment_id', true);
        if ($existing_payment > 0) {
            wp_send_json_error(['message' => __('El pago ya estÃ¡ registrado en Alegra.', 'alegra-connector')]);
        }

        $account_id = (int) get_option('alegra_connector_payment_account_id', 0);
        if ($account_id <= 0) {
            wp_send_json_error(['message' => __('Configura una cuenta bancaria en Ajustes > Avanzado.', 'alegra-connector')]);
        }

        $orders_sync = new \Alegra\Connector\Sync\Orders($this->api, $this->logger);
        $payment_data = [
            'date' => $order->get_date_paid() ? $order->get_date_paid()->date('Y-m-d') : date('Y-m-d'),
            'invoice' => ['id' => $alegra_invoice_id],
            'account' => ['id' => $account_id],
            'amount' => (float) $order->get_total(),
            'currency' => ['code' => $order->get_currency() ?: 'COP'],
            'paymentMethod' => $orders_sync->getPaymentMethodForGateway($order->get_payment_method()),
        ];

        $result = $this->api->create_payment($payment_data);

        if (is_wp_error($result)) {
            $this->logger->error('Payment recording failed', [
                'order_id' => $order_id,
                'error' => sprintf(__('Error de Alegra: %s', 'alegra-connector'), $result->get_error_message()),
            ]);
            wp_send_json_error(['message' => sprintf(__('Error de Alegra: %s', 'alegra-connector'), $result->get_error_message())]);
        }

        $payment_id = (int) ($result['id'] ?? 0);
        update_post_meta($order_id, '_alegra_payment_id', $payment_id);

        // Add order note
        $order->add_order_note(sprintf(
            __('Pago registrado en Alegra - ID: %d', 'alegra-connector'),
            $payment_id
        ));

        $this->logger->info('Payment recorded in Alegra', [
            'order_id' => $order_id,
            'payment_id' => $payment_id,
            'invoice_id' => $alegra_invoice_id,
        ]);

        wp_send_json_success([
            'message' => __('Pago registrado en Alegra.', 'alegra-connector'),
            'payment_id' => $payment_id,
        ]);
    }

    public function ajax_sync_single(): void
    {
        check_ajax_referer('alegra_connector_nonce');

        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(['message' => __('No tienes permisos.', 'alegra-connector')]);
        }

        $entity_type = sanitize_text_field($_POST['entity_type'] ?? '');
        $entity_id = (int) ($_POST['entity_id'] ?? 0);

        if ($entity_id <= 0) {
            wp_send_json_error(['message' => __('ID invalido.', 'alegra-connector')]);
        }

        $sync_controller = new \Alegra\Connector\Sync\Controller($this->api, $this->logger);

        switch ($entity_type) {
            case 'product': $result = $sync_controller->sync_entity('product', $entity_id, 'update'); break;
            case 'customer': $result = $sync_controller->sync_entity('customer', $entity_id, 'update'); break;
            case 'order': $result = $sync_controller->sync_entity('order', $entity_id, 'create'); break;
            default: wp_send_json_error(['message' => __('Tipo de entidad desconocido.', 'alegra-connector')]);
        }

        if (is_wp_error($result)) {
            wp_send_json_error(['message' => sprintf(__('Error de Alegra: %s', 'alegra-connector'), $result->get_error_message())]);
        }

        wp_send_json_success(['message' => __('Sincronizacion completada.', 'alegra-connector'), 'data' => $result]);
    }

    public function ajax_export_csv(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) wp_die();

        $type = sanitize_text_field($_GET['export_type'] ?? 'products');

        if ($type === 'products') {
            $products = wc_get_products(['limit' => 500, 'status' => 'publish']);
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="alegra-productos-' . date('Y-m-d') . '.csv"');
            $out = fopen('php://output', 'w');
            fputcsv($out, ['name', 'sku', 'price', 'stock', 'type', 'alegra_id', 'sync_status']);
            foreach ($products as $p) {
                $ai = (int) get_post_meta($p->get_id(), '_alegra_item_id', true);
                fputcsv($out, [
                    $p->get_name(), $p->get_sku(), $p->get_price(), $p->get_stock_quantity(),
                    $p->get_type(), $ai > 0 ? $ai : '', $ai > 0 ? 'Sincronizado' : 'Pendiente',
                ]);
            }
            fclose($out);
        } else {
            $customers = get_users(['role' => 'customer', 'number' => 500]);
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="alegra-clientes-' . date('Y-m-d') . '.csv"');
            $out = fopen('php://output', 'w');
            fputcsv($out, ['name', 'email', 'phone', 'alegra_id', 'sync_status']);
            foreach ($customers as $c) {
                $ai = (int) get_user_meta($c->ID, 'alegra_contact_id', true);
                fputcsv($out, [
                    $c->display_name, $c->user_email, get_user_meta($c->ID, 'billing_phone', true),
                    $ai > 0 ? $ai : '', $ai > 0 ? 'Sincronizado' : 'Pendiente',
                ]);
            }
            fclose($out);
        }
        exit;
    }

    public function ajax_bulk_sync(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) wp_send_json_error(['message' => __('No tienes permisos.', 'alegra-connector')]);

        $type = sanitize_text_field($_POST['entity_type'] ?? '');
        $ids = array_map('intval', (array) ($_POST['ids'] ?? []));
        if (empty($ids)) wp_send_json_error(['message' => __('Selecciona al menos un elemento.', 'alegra-connector')]);

        $sync_controller = new \Alegra\Connector\Sync\Controller($this->api, $this->logger);
        $synced = 0; $errors = 0;

        foreach ($ids as $id) {
            $action = $type === 'order' ? 'create' : 'update';
            $r = $sync_controller->sync_entity($type, $id, $action);
            is_wp_error($r) ? $errors++ : $synced++;
        }

        wp_send_json_success(['message' => sprintf(__('%d sincronizados, %d errores.', 'alegra-connector'), $synced, $errors)]);
    }

    public function ajax_get_invoice_pdf(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) wp_die();

        $order_id = (int) ($_GET['order_id'] ?? 0);
        if ($order_id <= 0) wp_die(__('Pedido invalido.', 'alegra-connector'));

        $alegra_invoice_id = (int) get_post_meta($order_id, '_alegra_invoice_id', true);
        if ($alegra_invoice_id <= 0) wp_die(__('Este pedido no tiene factura en Alegra.', 'alegra-connector'));

        $result = $this->api->get_invoice_pdf($alegra_invoice_id);
        if (is_wp_error($result)) wp_die(esc_html($result->get_error_message()));

        $pdf_url = $result['pdf'] ?? '';
        if (empty($pdf_url)) wp_die(__('No se pudo obtener el PDF de Alegra.', 'alegra-connector'));

        wp_redirect($pdf_url);
        exit;
    }

    public function ajax_disconnect(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) wp_send_json_error(['message' => __('No tienes permisos.', 'alegra-connector')]);

        update_option('alegra_connector_connection_tested', false);
        update_option('alegra_connector_company_name', '');
        update_option('alegra_connector_company_country', '');
        update_option('alegra_connector_company_email', '');

        $this->log('info', 'Disconnected from Alegra');

        wp_send_json_success(['message' => __('Desconectado de Alegra.', 'alegra-connector')]);
    }

    public function ajax_sync_progress(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        $progress = get_transient('alegra_sync_progress');
        if ($progress === false) {
            wp_send_json_success(['done' => true, 'message' => '']);
        }
        wp_send_json_success($progress);
    }

    public function do_async_import(string $type): void
    {
        switch ($type) {
            case 'products':
                $sync = new Sync\Products($this->api, $this->logger);
                if ($this->api) $sync->import_from_alegra();
                $sync->sync_all();
                break;
            case 'customers':
                $sync = new Sync\Customers($this->api, $this->logger);
                if ($this->api) $sync->import_from_alegra();
                $sync->sync_all();
                break;
            case 'categories':
                $sync = new Sync\Categories($this->api, $this->logger);
                if ($this->api) $sync->import_from_alegra();
                $sync->sync_all();
                break;
        }
    }

    public function do_async_sync_all(): void
    {
        $sc = new \Alegra\Connector\Sync\Controller($this->api, $this->logger);
        $sc->run_cron_sync();
        set_transient('alegra_sync_progress', ['done' => true, 'message' => __('Sincronizacion completa.', 'alegra-connector')], 60);
    }

    public function ajax_check_endpoints(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) wp_send_json_error(['message' => __('No tienes permisos.', 'alegra-connector')]);

        // Force reload credentials from DB
        $this->api->reload_credentials();

        $endpoints = [];

        $items = $this->api->get_items(['limit' => 5]);
        $endpoints['items'] = is_wp_error($items) ? $items->get_error_message() : (is_array($items) && count($items) > 0 ? 'OK: ' . count($items) . ' items' : 'vacio');

        $contacts = $this->api->get_contacts(['limit' => 5]);
        $endpoints['contacts'] = is_wp_error($contacts) ? $contacts->get_error_message() : (is_array($contacts) && count($contacts) > 0 ? 'OK: ' . count($contacts) . ' contacts' : 'vacio');

        $invoices = $this->api->get_invoices(['limit' => 5]);
        $endpoints['invoices'] = is_wp_error($invoices) ? $invoices->get_error_message() : (is_array($invoices) && count($invoices) > 0 ? 'OK: ' . count($invoices) . ' invoices' : 'vacio');

        $taxes = $this->api->get_taxes();
        $endpoints['taxes'] = is_wp_error($taxes) ? $taxes->get_error_message() : (is_array($taxes) && count($taxes) > 0 ? 'OK: ' . count($taxes) . ' taxes' : 'vacio');

        $this->log('info', 'Endpoint check completed', $endpoints);

        wp_send_json_success(['endpoints' => $endpoints]);
    }

    public function ajax_import_from_api(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) wp_send_json_error(['message' => __('No tienes permisos.', 'alegra-connector')]);

        if (!get_option('alegra_connector_connection_tested')) {
            wp_send_json_error(['message' => __('Conecta primero con Alegra.', 'alegra-connector')]);
        }

        $import_type = sanitize_text_field($_POST['import_type'] ?? '');
        if (!in_array($import_type, ['products', 'customers', 'categories'])) {
            wp_send_json_error(['message' => __('Tipo de importacion invalido.', 'alegra-connector')]);
        }

        $sync_controller = new \Alegra\Connector\Sync\Controller($this->api, $this->logger);
        $result = $sync_controller->import_from_alegra($import_type);

        if (is_wp_error($result)) {
            wp_send_json_error(['message' => sprintf(__('Error de Alegra: %s', 'alegra-connector'), $result->get_error_message())]);
        }

        $imported = (int) ($result['imported'] ?? 0);
        $updated = (int) ($result['updated'] ?? 0);

        wp_send_json_success([
            'message' => sprintf(__('Importacion completada: %d nuevos, %d actualizados.', 'alegra-connector'), $imported, $updated),
            'data' => $result,
        ]);
    }

    private function get_sync_stats(): array
    {
        // Use WooCommerce APIs (HPOS-compatible) instead of direct wp_posts queries
        $product_count = 0;
        $order_count = 0;

        if (function_exists('wc_get_products')) {
            $products = wc_get_products([
                'limit' => -1,
                'return' => 'ids',
                'status' => 'publish',
            ]);
            $product_count = is_array($products) ? count($products) : 0;
        }

        if (function_exists('wc_get_orders')) {
            $orders = wc_get_orders([
                'limit' => -1,
                'return' => 'ids',
                'status' => ['processing', 'completed', 'pending', 'on-hold'],
            ]);
            $order_count = is_array($orders) ? count($orders) : 0;
        }

        $user_count = 0;
        if (function_exists('get_users')) {
            $users = get_users([
                'role' => 'customer',
                'fields' => 'ID',
                'number' => -1,
            ]);
            $user_count = is_array($users) ? count($users) : 0;
        }

        $cat_count = 0;
        if (function_exists('get_terms')) {
            $cats = get_terms([
                'taxonomy' => 'product_cat',
                'hide_empty' => false,
                'fields' => 'ids',
            ]);
            $cat_count = is_array($cats) && !is_wp_error($cats) ? count($cats) : 0;
        }

        return [
            'products' => $product_count,
            'customers' => $user_count,
            'orders' => $order_count,
            'categories' => $cat_count,
        ];
    }

    private function process_csv_import(string $file_path, string $type): array|\WP_Error
    {
        if (!file_exists($file_path)) {
            return new \WP_Error('file_not_found', __('Archivo CSV no encontrado.', 'alegra-connector'));
        }

        $handle = fopen($file_path, 'r');
        if ($handle === false) {
            return new \WP_Error('cannot_open', __('No se pudo abrir el archivo.', 'alegra-connector'));
        }

        $count = 0;
        $errors = [];
        $headers = fgetcsv($handle);

        if ($headers === false) {
            fclose($handle);
            return new \WP_Error('invalid_csv', __('Archivo CSV invÃ¡lido.', 'alegra-connector'));
        }

        $headers = array_map('trim', $headers);
        $line = 1;

        while (($row = fgetcsv($handle)) !== false) {
            $line++;

            if (count($row) !== count($headers)) {
                $errors[] = sprintf(
                    /* translators: %d: line number */
                    __('LÃ­nea %d: nÃºmero de columnas no coincide con el encabezado.', 'alegra-connector'),
                    $line
                );
                continue;
            }

            $data = array_combine($headers, $row);
            if ($data === false) {
                $errors[] = sprintf(
                    /* translators: %d: line number */
                    __('LÃ­nea %d: error al procesar la fila.', 'alegra-connector'),
                    $line
                );
                continue;
            }

            if ($type === 'products') {
                $imported = $this->import_product_from_csv($data);
                if ($imported) {
                    $count++;
                } else {
                    $errors[] = sprintf(
                        /* translators: %d: line number */
                        __('LÃ­nea %d: no se pudo importar el producto.', 'alegra-connector'),
                        $line
                    );
                }
            }
        }

        fclose($handle);

        $this->logger->info('CSV import completed', [
            'type' => $type,
            'count' => $count,
            'errors' => count($errors),
        ]);

        return ['count' => $count, 'errors' => $errors];
    }

    private function import_product_from_csv(array $data): bool
    {
        $name = sanitize_text_field($data['name'] ?? '');
        if (empty($name)) {
            return false;
        }

        $product_id = wp_insert_post([
            'post_title' => $name,
            'post_content' => sanitize_text_field($data['description'] ?? ''),
            'post_type' => 'product',
            'post_status' => 'publish',
        ]);

        if (is_wp_error($product_id) || !$product_id) {
            return false;
        }

        $sku = sanitize_text_field($data['reference'] ?? '');
        $price = sanitize_text_field($data['price'] ?? '');

        if (!empty($sku)) {
            update_post_meta($product_id, '_sku', $sku);
        }
        if (!empty($price)) {
            update_post_meta($product_id, '_regular_price', $price);
            update_post_meta($product_id, '_price', $price);
        }

        return true;
    }
}
