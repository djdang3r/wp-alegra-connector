<?php if(!defined('ABSPATH'))exit;
$page_title=__('Productos','alegra-connector');
$synced_count=$synced_count??0;$variable_count=$variable_count??0;$total=$total??0;
$page_subtitle=sprintf(__('%d productos (%d sincronizados con Alegra)','alegra-connector'),$total,$synced_count);
$export_url=wp_nonce_url(admin_url('admin-ajax.php?action=alegra_export_csv&export_type=products'),'alegra_connector_nonce','_ajax_nonce');
include __DIR__.'/header.php';
$filter=isset($_GET['filter'])?sanitize_text_field($_GET['filter']):'all';
$search=isset($_GET['search'])?sanitize_text_field($_GET['search']):'';
?>
<div class="alegra-connector-wrap">

<!-- KPI Bar -->
<div class="ac-kpi-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:14px;">
<div class="ac-kpi-card" style="border-left:4px solid var(--ac-text-muted);padding:14px 18px;"><div class="ac-kpi-icon" style="width:38px;height:38px;background:var(--ac-surface-alt);color:var(--ac-text-secondary);"><span class="dashicons dashicons-products"></span></div><div class="ac-kpi-content"><span class="ac-kpi-label"><?php esc_html_e('Total Productos','alegra-connector');?></span><span class="ac-kpi-value" style="font-size:18px;"><?php echo esc_html($total);?></span></div></div>
<div class="ac-kpi-card" style="border-left:4px solid var(--ac-success);padding:14px 18px;"><div class="ac-kpi-icon" style="width:38px;height:38px;background:var(--ac-success-bg);color:var(--ac-success);"><span class="dashicons dashicons-yes-alt"></span></div><div class="ac-kpi-content"><span class="ac-kpi-label"><?php esc_html_e('Sincronizados','alegra-connector');?></span><span class="ac-kpi-value" style="font-size:18px;color:var(--ac-success);"><?php echo esc_html($synced_count);?></span><span class="ac-kpi-sub"><?php echo $total>0?esc_html(round(($synced_count/$total)*100,1).'%'):'0%';?></span></div></div>
<div class="ac-kpi-card" style="border-left:4px solid var(--ac-warning);padding:14px 18px;"><div class="ac-kpi-icon" style="width:38px;height:38px;background:var(--ac-warning-bg);color:var(--ac-warning);"><span class="dashicons dashicons-warning"></span></div><div class="ac-kpi-content"><span class="ac-kpi-label"><?php esc_html_e('Pendientes','alegra-connector');?></span><span class="ac-kpi-value" style="font-size:18px;color:var(--ac-warning);"><?php echo esc_html($total-$synced_count);?></span></div></div>
<div class="ac-kpi-card" style="border-left:4px solid var(--ac-primary);padding:14px 18px;"><div class="ac-kpi-icon" style="width:38px;height:38px;background:var(--ac-primary-light);color:var(--ac-primary);"><span class="dashicons dashicons-editor-ul"></span></div><div class="ac-kpi-content"><span class="ac-kpi-label"><?php esc_html_e('Variables','alegra-connector');?></span><span class="ac-kpi-value" style="font-size:18px;color:var(--ac-primary);"><?php echo esc_html($variable_count);?></span></div></div>
</div>

<!-- Actions + Filters -->
<div class="ac-card" style="margin-bottom:14px;padding:12px 20px;">
<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
    <button type="button" class="ac-btn ac-btn-primary ac-btn-sm alegra-quick-sync" data-type="products"><span class="dashicons dashicons-download" style="font-size:14px;width:14px;height:14px;"></span> <?php esc_html_e('Traer de Alegra','alegra-connector');?></button>
    <a href="<?php echo esc_url($export_url);?>" class="ac-btn ac-btn-sm"><span class="dashicons dashicons-download" style="font-size:14px;width:14px;height:14px;"></span> <?php esc_html_e('Exportar CSV','alegra-connector');?></a>
    <button type="button" class="ac-btn ac-btn-sm alegra-bulk-sync" data-type="product"><span class="dashicons dashicons-upload" style="font-size:14px;width:14px;height:14px;"></span> <?php esc_html_e('Enviar seleccionados a Alegra','alegra-connector');?></button>
    <div style="flex:1;"></div>
    <span style="font-size:12px;font-weight:600;color:var(--ac-text-secondary);"><?php esc_html_e('Filtrar:','alegra-connector');?></span>
    <a href="<?php echo esc_url(admin_url('admin.php?page=alegra-connector-products&filter=all'));?>" class="ac-btn ac-btn-xs <?php echo $filter==='all'?'ac-btn-primary':'';?>"><?php esc_html_e('Todos','alegra-connector');?></a>
    <a href="<?php echo esc_url(admin_url('admin.php?page=alegra-connector-products&filter=synced'));?>" class="ac-btn ac-btn-xs <?php echo $filter==='synced'?'ac-btn-primary':'';?>"><?php esc_html_e('Sincronizados','alegra-connector');?></a>
    <a href="<?php echo esc_url(admin_url('admin.php?page=alegra-connector-products&filter=pending'));?>" class="ac-btn ac-btn-xs <?php echo $filter==='pending'?'ac-btn-primary':'';?>"><?php esc_html_e('Pendientes','alegra-connector');?></a>
    <form method="get" action="<?php echo esc_url(admin_url('admin.php'));?>" style="display:inline-flex;gap:4px;align-items:center;">
        <input type="hidden" name="page" value="alegra-connector-products">
        <input type="text" name="search" value="<?php echo esc_attr($search);?>" placeholder="<?php esc_attr_e('Buscar producto...','alegra-connector');?>" style="padding:4px 10px;border-radius:6px;border:1px solid var(--ac-border);font-size:12px;width:180px;">
        <button type="submit" class="ac-btn ac-btn-xs"><?php esc_html_e('Buscar','alegra-connector');?></button>
    </form>
</div>
</div>

<!-- Product Table -->
<div class="ac-table-wrap"><table class="widefat fixed striped">
<thead><tr><th style="width:36px;"><input type="checkbox" class="alegra-select-all" data-type="product"></th><th style="width:60px;">ID</th><th><?php esc_html_e('Producto','alegra-connector');?></th><th>SKU</th><th><?php esc_html_e('Precio','alegra-connector');?></th><th><?php esc_html_e('Tipo','alegra-connector');?></th><th><?php esc_html_e('Alegra ID','alegra-connector');?></th><th><?php esc_html_e('Estado Sync','alegra-connector');?></th><th></th></tr></thead>
<tbody><?php if(empty($products)):?><tr><td colspan="8" style="text-align:center;padding:30px;color:var(--ac-text-muted);"><?php esc_html_e('No se encontraron productos.','alegra-connector');?></td></tr>
<?php else:foreach($products as $p):
    $ai=(int)get_post_meta($p->get_id(),'_alegra_item_id',true);$s=$ai>0;
    if($filter==='synced'&&!$s)continue;
    if($filter==='pending'&&$s)continue;
    if($search&&stripos($p->get_name(),$search)===false&&stripos($p->get_sku(),$search)===false)continue;
    $type=$p->get_type();$ti=$type==='variable'?'<span class="ac-badge neutral">variable</span>':($type==='variation'?'<span class="ac-badge neutral">variacion</span>':'<span class="ac-badge info">simple</span>');
?>
<tr><td><input type="checkbox" class="alegra-bulk-check" value="<?php echo esc_attr($p->get_id());?>"></td><td><?php echo esc_html($p->get_id());?></td><td><strong><a href="<?php echo esc_url(admin_url('admin.php?page=alegra-connector-products&product_id='.$p->get_id()));?>"><?php echo esc_html($p->get_name());?></a></strong></td><td><?php echo esc_html($p->get_sku()?:'--');?></td><td><?php echo wp_kses_post(wc_price($p->get_price()));?></td><td><?php echo $ti;?></td><td><?php echo $s?'<span class="ac-code">#'.esc_html($ai).'</span>':'<span style="color:var(--ac-text-muted);">--</span>';?></td><td><?php echo $s?'<span class="ac-badge success">'.esc_html__('Sincronizado','alegra-connector').'</span>':'<span class="ac-badge warning">'.esc_html__('Pendiente','alegra-connector').'</span>';?></td><td><a href="<?php echo esc_url(admin_url('admin.php?page=alegra-connector-products&product_id='.$p->get_id()));?>" class="ac-btn ac-btn-xs"><?php esc_html_e('Ver','alegra-connector');?></a> <?php if(!$s):?><button class="ac-btn ac-btn-xs alegra-sync-single" data-type="product" data-id="<?php echo esc_attr($p->get_id());?>"><?php esc_html_e('Sync','alegra-connector');?></button><?php endif;?></td></tr>
<?php endforeach;endif;?></tbody></table></div>
<?php if($total_pages>1): include __DIR__.'/pagination.php'; $base=admin_url('admin.php?page=alegra-connector-products&filter='.urlencode($filter).'&search='.urlencode($search)); echo alegra_pagination($page, $total_pages, $base); endif;?>

<?php include __DIR__.'/footer.php';?></div>