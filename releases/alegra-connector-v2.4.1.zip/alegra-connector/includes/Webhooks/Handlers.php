<?php

declare(strict_types=1);

namespace Alegra\Connector\Webhooks;

use Alegra\Connector\API;
use Alegra\Connector\Logger;
use Alegra\Connector\Sync;

if (!defined('ABSPATH')) {
    exit;
}

class Handlers
{
    private ?API\Client $api;
    private ?Logger\Logger $logger;

    public function __construct(?API\Client $api, ?Logger\Logger $logger)
    {
        $this->api = $api;
        $this->logger = $logger;
    }

    public function process_event(string $event, array $data): void
    {
        if ($this->logger) $this->logger->info('Processing webhook event', ['event' => $event]);

        switch ($event) {
            case 'new-item':
            case 'edit-item':
                $this->handle_item_event($data);
                break;

            case 'delete-item':
                $this->handle_delete_item($data);
                break;

            case 'new-client':
            case 'edit-client':
                $this->handle_client_event($data);
                break;

            case 'delete-client':
                $this->handle_delete_client($data);
                break;

            case 'new-invoice':
            case 'edit-invoice':
                $this->handle_invoice_event($data);
                break;

            default:
                if ($this->logger) $this->logger->info('Unhandled webhook event', ['event' => $event]);
                break;
        }
    }

    private function handle_item_event(array $data): void
    {
        $item = $data['item'] ?? $data;
        if (!is_array($item)) return;
        $alegra_id = (string) ($item['id'] ?? '');
        if ($alegra_id === '') return;

        $products = new Sync\Products($this->api, $this->logger);
        $result = $products->sync_single_item_by_alegra_id($alegra_id);

        if ($result === false) {
            if ($this->logger) $this->logger->error('Webhook: Failed to sync item', ['alegra_id' => $alegra_id]);
        } else {
            if ($this->logger) $this->logger->info('Webhook: Item synced', ['alegra_id' => $alegra_id, 'result' => $result]);
        }
    }

    private function handle_delete_item(array $data): void
    {
        $item = $data['item'] ?? $data;
        if (!is_array($item)) return;
        $alegra_id = (string) ($item['id'] ?? '');
        if ($alegra_id === '') return;

        // Write tombstone so future pulls won't recreate the product.
        // (Previously this handler deleted _alegra_item_id postmeta, but that
        // raced with concurrent sync pulls — the cron could create a new product
        // just before this delete fired, losing its Alegra linkage.)
        \Alegra\Connector\Tombstone_Manager::create([
            'alegra_type' => 'item',
            'alegra_id'   => $alegra_id,
            'reason'      => 'alegra_deleted',
            'deleted_by'  => 0,
        ]);

        // Also unlink any currently-imported product (optional cleanup; the
        // tombstone is the durable record. Safe to leave for a future job.)
        global $wpdb;
        $product_id = $wpdb->get_var($wpdb->prepare(
            "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_alegra_item_id' AND meta_value = %s LIMIT 1",
            $alegra_id
        ));
        if ($product_id && $this->logger) {
            $this->logger->info('Webhook: Item deleted in Alegra, tombstone written', [
                'alegra_id'   => $alegra_id,
                'product_id'  => (int) $product_id,
                'tombstoned'  => true,
            ]);
        } elseif ($this->logger) {
            $this->logger->info('Webhook: Item deleted in Alegra, tombstone written (no WC product)', [
                'alegra_id'  => $alegra_id,
                'tombstoned' => true,
            ]);
        }
    }

    private function handle_client_event(array $data): void
    {
        $contact = $data['client'] ?? $data;
        if (!is_array($contact)) return;
        $alegra_id = (string) ($contact['id'] ?? '');
        if ($alegra_id === '') return;

        // AC-25: an edited contact may be the Consumidor Final; drop the cached
        // id/metadata so the next resolution re-reads it from Alegra.
        if (\Alegra\Connector\Consumidor_Final::is_consumidor_final($alegra_id)) {
            \Alegra\Connector\Consumidor_Final::invalidate_cache();
        }

        $customers = new Sync\Customers($this->api, $this->logger);
        $result = $customers->sync_single_contact_by_alegra_id($alegra_id);

        if ($result === false) {
            if ($this->logger) $this->logger->error('Webhook: Failed to sync contact', ['alegra_id' => $alegra_id]);
        } else {
            if ($this->logger) $this->logger->info('Webhook: Contact synced', ['alegra_id' => $alegra_id, 'result' => $result]);
        }
    }

    private function handle_delete_client(array $data): void
    {
        $contact = $data['client'] ?? $data;
        if (!is_array($contact)) return;
        $alegra_id = (string) ($contact['id'] ?? '');
        if ($alegra_id === '') return;

        // AC-25: if the deleted contact is the cached Consumidor Final, drop the
        // option/transient cache so a dead id is not served forever.
        if (\Alegra\Connector\Consumidor_Final::is_consumidor_final($alegra_id)) {
            \Alegra\Connector\Consumidor_Final::invalidate_cache();
        }

        $user_args = [
            'meta_key' => 'alegra_contact_id',
            'meta_value' => $alegra_id,
            'number' => 1,
            'fields' => 'ID',
        ];
        $users = get_users($user_args);

        if (!empty($users)) {
            delete_user_meta((int) $users[0], 'alegra_contact_id');
            if ($this->logger) $this->logger->info('Webhook: Contact unlinked from user', ['alegra_id' => $alegra_id, 'user_id' => (int) $users[0]]);
        }
    }

    private function handle_invoice_event(array $data): void
    {
        $invoice = $data['invoice'] ?? $data;
        if (!is_array($invoice)) return;
        $alegra_invoice_id = (string) ($invoice['id'] ?? '');
        if ($alegra_invoice_id === '') return;

        // Never trust status/balance from the webhook body: Alegra does not sign
        // deliveries, so a forged payload could otherwise complete an order.
        // Re-read the invoice from the API and act on the authoritative values.
        $fresh = $this->api ? $this->api->get_invoice($alegra_invoice_id) : null;
        if (is_wp_error($fresh) || !is_array($fresh)) {
            if ($this->logger) {
                $this->logger->warning('Webhook: could not re-fetch invoice; ignoring event', [
                    'invoice_id' => $alegra_invoice_id,
                ]);
            }
            return;
        }

        $status = (string) ($fresh['status'] ?? '');
        $balance = (float) ($fresh['balance'] ?? 0);
        $should_complete = get_option('alegra_connector_auto_complete_order', true);

        // Only a settled (paid/closed) or a voided invoice changes the linked order.
        if (!\Alegra\Connector\Invoice_Status::is_paid($status) && !\Alegra\Connector\Invoice_Status::is_void($status)) {
            return;
        }

        // HPOS-safe order lookup: wc_get_orders() reads the correct storage
        // (wc_orders_meta on HPOS, postmeta on legacy) through the CRUD API.
        $found = wc_get_orders([
            'meta_key'   => '_alegra_invoice_id',
            'meta_value' => $alegra_invoice_id,
            'limit'      => 1,
            'return'     => 'ids',
        ]);
        $order_id = !empty($found) ? (int) $found[0] : 0;
        if (!$order_id) {
            return;
        }
        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }

        $orders = new Sync\Orders($this->api, $this->logger);
        $orders->persist_invoice_status($order, $fresh);

        if (\Alegra\Connector\Invoice_Status::is_void($status)) {
            // The order is deliberately NOT cancelled: an Alegra void does not
            // prove the WC order was cancelled, so the merchant decides.
            if ($orders->note_invoice_voided($order, $fresh) && $this->logger) {
                $this->logger->info('Webhook: Invoice voided, order note added', [
                    'order_id'   => $order_id,
                    'invoice_id' => $alegra_invoice_id,
                ]);
            }
            return;
        }

        if ($balance <= 0 && $should_complete && $order->get_status() !== 'completed') {
            $order->add_order_note(sprintf(
                __('[Alegra Webhook] Factura #%s pagada. Pedido completado automaticamente.', 'alegra-connector'),
                $fresh['number'] ?? $alegra_invoice_id
            ));
            $order->update_status('completed');
            if ($this->logger) $this->logger->info('Webhook: Order completed from paid invoice', [
                'order_id' => $order_id,
                'invoice_id' => $alegra_invoice_id,
            ]);
        }
    }
}
