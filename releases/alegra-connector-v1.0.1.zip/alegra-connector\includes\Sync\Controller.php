<?php
/**
 * Sync Controller
 *
 * @package Alegra\Connector\Sync
 */

declare(strict_types=1);

namespace Alegra\Connector\Sync;

use Alegra\Connector\API;
use Alegra\Connector\Logger;

if (!defined('ABSPATH')) {
    exit;
}

class Controller
{
    private ?API\Client $api;
    private ?Logger\Logger $logger;
    private Products $products;
    private Customers $customers;
    private Orders $orders;
    private Categories $categories;

    public function __construct(?API\Client $api, ?Logger\Logger $logger)
    {
        $this->api = $api;
        $this->logger = $logger;

        $this->products = new Products($api, $logger);
        $this->customers = new Customers($api, $logger);
        $this->orders = new Orders($api, $logger);
        $this->categories = new Categories($api, $logger);
    }

    /**
     * Register the cron sync hook - call this explicitly
     */
    public function register_cron_hook(): void
    {
        if (!has_action('alegra_connector_cron_sync', [$this, 'run_cron_sync'])) {
            add_action('alegra_connector_cron_sync', [$this, 'run_cron_sync']);
        }
    }

    public function run_cron_sync(): void
    {
        $this->logger->info('Starting cron synchronization');

        $result = [
            'products' => 0,
            'customers' => 0,
            'orders' => 0,
            'categories' => 0,
            'errors' => [],
        ];

        if (get_option('alegra_connector_sync_products')) {
            // Pull first: Alegra → WC
            $import_result = $this->products->import_from_alegra();
            if (!is_wp_error($import_result)) {
                $result['products'] = ($import_result['imported'] ?? 0) + ($import_result['updated'] ?? 0);
            }
            // Then push: WC → Alegra
            $products_result = $this->products->sync_all();
            if (is_wp_error($products_result)) {
                $result['errors']['products'] = $products_result->get_error_message();
            } else {
                $result['products'] = ($result['products'] ?? 0) + ($products_result['synced'] ?? 0);
            }
        }

        if (get_option('alegra_connector_sync_customers')) {
            $import_result = $this->customers->import_from_alegra();
            if (!is_wp_error($import_result)) {
                $result['customers'] = ($import_result['imported'] ?? 0) + ($import_result['updated'] ?? 0);
            }
            $customers_result = $this->customers->sync_all();
            if (is_wp_error($customers_result)) {
                $result['errors']['customers'] = $customers_result->get_error_message();
            } else {
                $result['customers'] = ($result['customers'] ?? 0) + ($customers_result['synced'] ?? 0);
            }
        }

        if (get_option('alegra_connector_sync_orders')) {
            $orders_result = $this->orders->sync_recent();
            if (is_wp_error($orders_result)) {
                $result['errors']['orders'] = $orders_result->get_error_message();
            } else {
                $result['orders'] = $orders_result['synced'] ?? 0;
            }
        }

        if (get_option('alegra_connector_sync_categories')) {
            $categories_result = $this->categories->sync_all();
            if (is_wp_error($categories_result)) {
                $result['errors']['categories'] = $categories_result->get_error_message();
            } else {
                $result['categories'] = $categories_result['synced'] ?? 0;
            }
        }

        update_transient('alegra_connector_last_sync', time());

        $this->logger->info('Cron synchronization completed', $result);
    }

    public function sync_entity(string $type, int $id, string $action): array|\WP_Error
    {
        $this->logger->info('Syncing entity', ['type' => $type, 'id' => $id, 'action' => $action]);

        switch ($type) {
            case 'product':
                return $this->sync_single_product($id, $action);
            case 'customer':
                return $this->sync_single_customer($id, $action);
            case 'order':
                return $this->sync_single_order($id, $action);
            case 'category':
                return $this->sync_single_category($id, $action);
            default:
                return new \WP_Error('unknown_type', 'Unknown entity type: ' . $type);
        }
    }

    private function sync_single_product(int $id, string $action): array|\WP_Error
    {
        $product = wc_get_product($id);
        if (!$product) {
            return new \WP_Error('not_found', 'Product not found');
        }

        switch ($action) {
            case 'create':
            case 'update':
                return $this->products->sync_to_alegra($product);
            case 'delete':
                return $this->products->delete_from_alegra($id);
            default:
                return new \WP_Error('unknown_action', 'Unknown action: ' . $action);
        }
    }

    private function sync_single_customer(int $id, string $action): array|\WP_Error
    {
        $customer = get_userdata($id);
        if (!$customer) {
            return new \WP_Error('not_found', 'Customer not found');
        }

        switch ($action) {
            case 'create':
            case 'update':
                return $this->customers->sync_to_alegra($customer);
            case 'delete':
                return $this->customers->delete_from_alegra($id);
            default:
                return new \WP_Error('unknown_action', 'Unknown action: ' . $action);
        }
    }

    private function sync_single_order(int $id, string $action): array|\WP_Error
    {
        $order = wc_get_order($id);
        if (!$order) {
            return new \WP_Error('not_found', 'Order not found');
        }

        switch ($action) {
            case 'create':
                return $this->orders->create_invoice($order);
            case 'complete':
                return $this->orders->create_invoice_with_payment($order);
            case 'refund':
                return $this->orders->create_credit_note($order);
            case 'cancel':
                return $this->orders->void_invoice($order);
            default:
                return new \WP_Error('unknown_action', 'Unknown action: ' . $action);
        }
    }

    private function sync_single_category(int $id, string $action): array|\WP_Error
    {
        $term = get_term($id, 'product_cat');
        if (!$term) {
            return new \WP_Error('not_found', 'Category not found');
        }

        switch ($action) {
            case 'create':
            case 'update':
                return $this->categories->sync_to_alegra($term);
            case 'delete':
                return $this->categories->delete_from_alegra($id);
            default:
                return new \WP_Error('unknown_action', 'Unknown action: ' . $action);
        }
    }

    public function import_from_alegra(string $type): array|\WP_Error
    {
        switch ($type) {
            case 'products':
                return $this->products->import_from_alegra();
            case 'customers':
                return $this->customers->import_from_alegra();
            case 'categories':
                return $this->categories->import_from_alegra();
            default:
                return new \WP_Error('unknown_type', 'Unknown import type: ' . $type);
        }
    }
}