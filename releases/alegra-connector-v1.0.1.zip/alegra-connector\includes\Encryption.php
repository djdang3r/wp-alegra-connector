<?php
/**
 * Encryption Helper for storing sensitive data
 *
 * @package Alegra\Connector
 */

declare(strict_types=1);

namespace Alegra\Connector;

if (!defined('ABSPATH')) {
    exit;
}

class Encryption
{
    /**
     * Encrypt a string using WordPress AUTH_KEY/SALT
     */
    public static function encrypt(string $plaintext): string
    {
        if (empty($plaintext)) {
            return '';
        }

        if (!function_exists('openssl_encrypt')) {
            return base64_encode($plaintext);
        }

        $key = self::get_key();
        $iv_length = openssl_cipher_iv_length('aes-256-cbc');
        $iv = openssl_random_pseudo_bytes($iv_length);

        if ($iv === false) {
            return base64_encode($plaintext);
        }

        $ciphertext = openssl_encrypt($plaintext, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);

        if ($ciphertext === false) {
            return base64_encode($plaintext);
        }

        return 'v2:' . base64_encode($iv . $ciphertext);
    }

    /**
     * Decrypt a string
     */
    public static function decrypt(string $encrypted): string
    {
        if (empty($encrypted)) {
            return '';
        }

        // v2 format
        if (strpos($encrypted, 'v2:') === 0) {
            $encrypted = substr($encrypted, 3);
        }

        if (!function_exists('openssl_decrypt')) {
            return base64_decode($encrypted, true) ?: '';
        }

        $data = base64_decode($encrypted, true);
        if ($data === false || strlen($data) < 17) {
            return '';
        }

        $key = self::get_key();
        $iv_length = openssl_cipher_iv_length('aes-256-cbc');
        $iv = substr($data, 0, $iv_length);
        $ciphertext = substr($data, $iv_length);

        if (empty($ciphertext)) {
            return '';
        }

        $plaintext = openssl_decrypt($ciphertext, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);

        return $plaintext === false ? '' : $plaintext;
    }

    /**
     * Derive a 32-byte key from WordPress salts
     */
    private static function get_key(): string
    {
        $salt = '';
        if (defined('LOGGED_IN_KEY')) {
            $salt .= LOGGED_IN_KEY;
        }
        if (defined('LOGGED_IN_SALT')) {
            $salt .= LOGGED_IN_SALT;
        }
        if (defined('AUTH_KEY')) {
            $salt .= AUTH_KEY;
        }
        if (defined('AUTH_SALT')) {
            $salt .= AUTH_SALT;
        }

        if (empty($salt)) {
            // Fallback: use a constant warning
            $salt = 'alegra-connector-fallback-key-please-set-wp-salts';
        }

        return hash('sha256', $salt, true);
    }
}