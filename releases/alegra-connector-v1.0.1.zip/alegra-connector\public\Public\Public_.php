<?php
/**
 * Public Hooks and REST API
 *
 * @package Alegra\Connector\Public
 */

declare(strict_types=1);

namespace Alegra\Connector\Public;

use Alegra\Connector\API;
use Alegra\Connector\Logger;
use Alegra\Connector\Sync;

if (!defined('ABSPATH')) {
    exit;
}

class Public_
{
    private ?API\Client $api;
    private ?Logger\Logger $logger;

    public function __construct(?API\Client $api, ?Logger\Logger $logger)
    {
        $this->api = $api;
        $this->logger = $logger;

        add_action('rest_api_init', [$this, 'register_rest_routes']);

        add_action('woocommerce_new_product', [$this, 'on_new_product'], 10, 1);
        add_action('woocommerce_update_product', [$this, 'on_update_product'], 10, 1);
        add_action('woocommerce_delete_product', [$this, 'on_delete_product'], 10, 1);

        add_action('woocommerce_new_order', [$this, 'on_new_order'], 10, 1);
        add_action('woocommerce_order_status_completed', [$this, 'on_order_completed'], 10, 1);
        add_action('woocommerce_order_status_refunded', [$this, 'on_order_refunded'], 10, 1);
        add_action('woocommerce_order_status_cancelled', [$this, 'on_order_cancelled'], 10, 1);

        add_action('woocommerce_new_customer', [$this, 'on_new_customer'], 10, 1);
    }

    /**
     * Permission callback for sync endpoint - requires admin capability
     */
    public function sync_permission_check(): bool
    {
        return current_user_can('manage_woocommerce');
    }

    /**
     * Permission callback for webhook endpoint - verifies HMAC signature
     */
    public function webhook_permission_check(\WP_REST_Request $request): bool
    {
        $signature = isset($_SERVER['HTTP_X_ALEGRA_SIGNATURE']) ? sanitize_text_field($_SERVER['HTTP_X_ALEGRA_SIGNATURE']) : '';
        $body = $request->get_json_params();
        return $this->verify_webhook_signature($signature, $body);
    }

    public function register_rest_routes(): void
    {
        register_rest_route('alegra-connector/v1', '/sync', [
            'methods' => 'POST',
            'callback' => [$this, 'handle_sync_request'],
            'permission_callback' => [$this, 'sync_permission_check'],
        ]);

        register_rest_route('alegra-connector/v1', '/webhook', [
            'methods' => 'POST',
            'callback' => [$this, 'handle_alegra_webhook'],
            'permission_callback' => [$this, 'webhook_permission_check'],
        ]);
    }

    public function handle_sync_request(\WP_REST_Request $request): \WP_REST_Response
    {
        $params = $request->get_json_params();

        if (!isset($params['action'])) {
            return new \WP_REST_Response(['error' => 'Missing action parameter'], 400);
        }

        $this->logger->info('REST sync request received', [
            'action' => sanitize_text_field($params['action']),
        ]);

        switch ($params['action']) {
            case 'sync_product':
                return $this->sync_product($params);
            case 'sync_customer':
                return $this->sync_customer($params);
            case 'sync_order':
                return $this->sync_order($params);
            default:
                return new \WP_REST_Response(['error' => 'Unknown action'], 400);
        }
    }

    public function handle_alegra_webhook(\WP_REST_Request $request): \WP_REST_Response
    {
        // Rate limiting for webhooks (60 req/min per IP)
        $ip = sanitize_text_field($_SERVER['REMOTE_ADDR'] ?? 'unknown');
        $key = 'alegra_webhook_rate_' . md5($ip);
        $rate = (int) get_transient($key);
        if ($rate >= 60) {
            $this->log('warning', 'Webhook rate limit exceeded', ['ip' => $ip]);
            return new \WP_REST_Response(['error' => 'Too many requests', 'retry_after' => 60], 429);
        }
        set_transient($key, $rate + 1, 60);

        $body = $request->get_json_params();

        $this->logger->info('Alegra webhook received', [
            'event_type' => isset($body['event']) ? sanitize_text_field($body['event']) : 'unknown',
        ]);

        if (isset($body['event'])) {
            $this->process_alegra_webhook($body);
        }

        return new \WP_REST_Response(['success' => true], 200);
    }

    private function verify_webhook_signature(string $signature, array $body): bool
    {
        $webhook_secret = get_option('alegra_connector_webhook_secret', '');

        // If no secret is configured, reject all webhooks (secure by default)
        if (empty($webhook_secret)) {
            $this->logger->warning('Webhook rejected: no secret configured');
            return false;
        }

        if (empty($signature)) {
            return false;
        }

        $payload = json_encode($body);
        $expected_signature = hash_hmac('sha256', $payload, $webhook_secret);

        return hash_equals($expected_signature, $signature);
    }

    /**
     * Process the queued webhook events - called from cron
     */
    public function process_webhook_queue(): void
    {
        $queue = get_transient('alegra_connector_sync_queue');
        if (!is_array($queue) || empty($queue)) {
            return;
        }

        $this->logger->info('Processing webhook queue', [
            'items' => count($queue['items'] ?? []),
            'contacts' => count($queue['contacts'] ?? []),
        ]);

        // Process items (products)
        if (!empty($queue['items'])) {
            $products_sync = new Sync\Products($this->api, $this->logger);
            foreach ($queue['items'] as $queued_item) {
                $alegra_id = (int) ($queued_item['id'] ?? 0);
                if ($alegra_id <= 0) {
                    continue;
                }
                $item = $this->api->get_item($alegra_id);
                if (!is_wp_error($item) && is_array($item)) {
                    $products_sync->import_single_item_public($item);
                }
            }
        }

        // Process contacts (customers)
        if (!empty($queue['contacts'])) {
            $customers_sync = new Sync\Customers($this->api, $this->logger);
            foreach ($queue['contacts'] as $queued_contact) {
                $alegra_id = (int) ($queued_contact['id'] ?? 0);
                if ($alegra_id <= 0) {
                    continue;
                }
                $contact = $this->api->get_contact($alegra_id);
                if (!is_wp_error($contact) && is_array($contact)) {
                    $customers_sync->import_single_contact_public($contact);
                }
            }
        }

        // Clear the queue
        delete_transient('alegra_connector_sync_queue');
    }

    /**
     * Process incoming webhook from Alegra with proper sync
     */
    private function process_alegra_webhook(array $body): void
    {
        $event = $body['event'] ?? '';
        $data = $body['data'] ?? [];

        if (empty($data['id'])) {
            $this->logger->warning('Webhook without ID', ['event' => $event]);
            return;
        }

        $entity_id = (int) $data['id'];

        switch ($event) {
            case 'item.created':
            case 'item.updated':
                $this->process_item_webhook_sync($entity_id, $event);
                break;
            case 'item.deleted':
                $this->process_item_deletion($entity_id);
                break;
            case 'contact.created':
            case 'contact.updated':
                $this->process_contact_webhook_sync($entity_id, $event);
                break;
            case 'contact.deleted':
                $this->process_contact_deletion($entity_id);
                break;
            case 'invoice.created':
            case 'invoice.updated':
                $this->process_invoice_webhook_sync($entity_id, $event);
                break;
            default:
                $this->logger->info('Unhandled webhook event', ['event' => $event]);
        }
    }

    /**
     * Sync a product from Alegra to WooCommerce via webhook
     */
    private function process_item_webhook_sync(int $alegra_id, string $event): void
    {
        $item = $this->api->get_item($alegra_id);
        if (is_wp_error($item)) {
            $this->logger->error('Webhook: failed to fetch item', [
                'alegra_id' => $alegra_id,
                'error' => $item->get_error_message(),
            ]);
            return;
        }

        $products_sync = new Sync\Products($this->api, $this->logger);
        $result = $products_sync->import_single_item_public($item);

        $this->logger->info('Webhook: item processed', [
            'event' => $event,
            'alegra_id' => $alegra_id,
            'result' => $result,
        ]);
    }

    /**
     * Handle product deletion from Alegra
     */
    private function process_item_deletion(int $alegra_id): void
    {
        global $wpdb;
        $product_id = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_alegra_item_id' AND meta_value = %d LIMIT 1",
            $alegra_id
        ));

        if ($product_id <= 0) {
            $this->logger->info('Webhook: no WC product linked to deleted Alegra item', ['alegra_id' => $alegra_id]);
            return;
        }

        // Trash the WooCommerce product (don't permanently delete)
        wp_trash_post($product_id);
        $this->logger->info('Webhook: product trashed from Alegra deletion', [
            'alegra_id' => $alegra_id,
            'product_id' => $product_id,
        ]);
    }

    /**
     * Sync a contact/customer from Alegra to WooCommerce via webhook
     */
    private function process_contact_webhook_sync(int $alegra_id, string $event): void
    {
        $contact = $this->api->get_contact($alegra_id);
        if (is_wp_error($contact)) {
            $this->logger->error('Webhook: failed to fetch contact', [
                'alegra_id' => $alegra_id,
                'error' => $contact->get_error_message(),
            ]);
            return;
        }

        $customers_sync = new Sync\Customers($this->api, $this->logger);
        $result = $customers_sync->import_single_contact_public($contact);

        $this->logger->info('Webhook: contact processed', [
            'event' => $event,
            'alegra_id' => $alegra_id,
            'result' => $result,
        ]);
    }

    /**
     * Handle contact deletion from Alegra
     */
    private function process_contact_deletion(int $alegra_id): void
    {
        $users = get_users([
            'meta_key' => 'alegra_contact_id',
            'meta_value' => $alegra_id,
            'fields' => 'ID',
            'number' => 1,
        ]);

        if (empty($users)) {
            $this->logger->info('Webhook: no WC user linked to deleted Alegra contact', ['alegra_id' => $alegra_id]);
            return;
        }

        $user_id = (int) $users[0];
        delete_user_meta($user_id, 'alegra_contact_id');
        $this->logger->info('Webhook: unlinked customer from deleted Alegra contact', [
            'alegra_id' => $alegra_id,
            'user_id' => $user_id,
        ]);
    }

    /**
     * Sync invoice status from Alegra to WooCommerce order
     */
    private function process_invoice_webhook_sync(int $alegra_id, string $event): void
    {
        $invoice = $this->api->get_invoice($alegra_id);
        if (is_wp_error($invoice)) {
            $this->logger->error('Webhook: failed to fetch invoice', [
                'alegra_id' => $alegra_id,
                'error' => $invoice->get_error_message(),
            ]);
            return;
        }

        // Find linked WooCommerce order
        global $wpdb;
        $order_id = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_alegra_invoice_id' AND meta_value = %d LIMIT 1",
            $alegra_id
        ));

        if ($order_id <= 0) {
            $this->logger->info('Webhook: no WC order linked to Alegra invoice', ['alegra_id' => $alegra_id]);
            return;
        }

        $order = wc_get_order($order_id);
        if (!$order) {
            $this->logger->warning('Webhook: linked order not found', ['order_id' => $order_id]);
            return;
        }

        // Map Alegra invoice status to WooCommerce order
        $alegra_status = $invoice['status'] ?? '';
        $alegra_balance = (float) ($invoice['balance'] ?? 0);
        $should_complete = get_option('alegra_connector_auto_complete_order', true);

        $note_prefix = __('[Alegra Webhook]', 'alegra-connector');

        switch ($alegra_status) {
            case 'paid':
                if ($alegra_balance <= 0) {
                    $order->add_order_note(sprintf('%s %s', $note_prefix, __('Factura pagada en Alegra.', 'alegra-connector')));
                    // Auto-complete the WooCommerce order if configured
                    if ($should_complete && $order->get_status() !== 'completed') {
                        $order->update_status('completed', sprintf('%s %s', $note_prefix, __('Pedido completado automaticamente porque la factura fue pagada en Alegra.', 'alegra-connector')));
                        $this->log('info', 'Order completed from Alegra webhook', ['order_id' => $order_id, 'alegra_id' => $alegra_id]);
                    }
                }
                break;
            case 'void':
                $order->add_order_note(
                    sprintf('%s %s', $note_prefix, __('Factura anulada en Alegra.', 'alegra-connector'))
                );
                break;
            default:
                $order->add_order_note(
                    sprintf('%s %s: %s', $note_prefix, __('Estado de factura actualizado en Alegra', 'alegra-connector'), $alegra_status)
                );
        }

        $this->logger->info('Webhook: invoice processed', [
            'event' => $event,
            'alegra_id' => $alegra_id,
            'order_id' => $order_id,
            'alegra_status' => $alegra_status,
        ]);
    }

    private function handle_item_webhook(array $body): void
    {
        $item = $body['data'] ?? [];
        $event = $body['event'] ?? '';

        $this->logger->info('Processing item webhook', [
            'event' => $event,
            'item_id' => $item['id'] ?? 'unknown',
        ]);

        $sync_queue = get_transient('alegra_connector_sync_queue') ?: [];
        $sync_queue['items'][] = [
            'id' => $item['id'] ?? 0,
            'action' => str_replace('item.', '', $event),
            'timestamp' => time(),
        ];
        set_transient('alegra_connector_sync_queue', $sync_queue, HOUR_IN_SECONDS);
    }

    private function handle_contact_webhook(array $body): void
    {
        $contact = $body['data'] ?? [];
        $event = $body['event'] ?? '';

        $this->logger->info('Processing contact webhook', [
            'event' => $event,
            'contact_id' => $contact['id'] ?? 'unknown',
        ]);

        $sync_queue = get_transient('alegra_connector_sync_queue') ?: [];
        $sync_queue['contacts'][] = [
            'id' => $contact['id'] ?? 0,
            'action' => str_replace('contact.', '', $event),
            'timestamp' => time(),
        ];
        set_transient('alegra_connector_sync_queue', $sync_queue, HOUR_IN_SECONDS);
    }

    private function handle_invoice_webhook(array $body): void
    {
        $invoice = $body['data'] ?? [];
        $event = $body['event'] ?? '';

        $this->logger->info('Processing invoice webhook', [
            'event' => $event,
            'invoice_id' => $invoice['id'] ?? 'unknown',
        ]);
    }

    private function sync_product(array $params): \WP_REST_Response
    {
        if (!isset($params['product_id'])) {
            return new \WP_REST_Response(['error' => 'Missing product_id'], 400);
        }

        $product_id = (int) $params['product_id'];
        $product = wc_get_product($product_id);

        if (!$product) {
            return new \WP_REST_Response(['error' => 'Product not found'], 404);
        }

        $this->logger->info('Syncing product to Alegra', ['product_id' => $product_id]);

        $sync = new Sync\Products($this->api, $this->logger);
        $result = $sync->sync_to_alegra($product);

        if (is_wp_error($result)) {
            return new \WP_REST_Response(['error' => $result->get_error_message()], 500);
        }

        return new \WP_REST_Response(['success' => true, 'data' => $result], 200);
    }

    private function sync_customer(array $params): \WP_REST_Response
    {
        if (!isset($params['customer_id'])) {
            return new \WP_REST_Response(['error' => 'Missing customer_id'], 400);
        }

        $customer_id = (int) $params['customer_id'];
        $customer = get_userdata($customer_id);

        if (!$customer) {
            return new \WP_REST_Response(['error' => 'Customer not found'], 404);
        }

        $this->logger->info('Syncing customer to Alegra', ['customer_id' => $customer_id]);

        $sync = new Sync\Customers($this->api, $this->logger);
        $result = $sync->sync_to_alegra($customer);

        if (is_wp_error($result)) {
            return new \WP_REST_Response(['error' => $result->get_error_message()], 500);
        }

        return new \WP_REST_Response(['success' => true, 'data' => $result], 200);
    }

    private function sync_order(array $params): \WP_REST_Response
    {
        if (!isset($params['order_id'])) {
            return new \WP_REST_Response(['error' => 'Missing order_id'], 400);
        }

        $order_id = (int) $params['order_id'];
        $order = wc_get_order($order_id);

        if (!$order) {
            return new \WP_REST_Response(['error' => 'Order not found'], 404);
        }

        $this->logger->info('Syncing order to Alegra', ['order_id' => $order_id]);

        $sync = new Sync\Orders($this->api, $this->logger);
        $result = $sync->create_invoice($order);

        if (is_wp_error($result)) {
            return new \WP_REST_Response(['error' => $result->get_error_message()], 500);
        }

        return new \WP_REST_Response(['success' => true, 'data' => $result], 200);
    }

    public function on_new_product(int $product_id): void
    {
        $this->logger->info('WooCommerce: New product', ['product_id' => $product_id]);
        $this->trigger_sync('product', $product_id, 'create');
    }

    public function on_update_product(int $product_id): void
    {
        $this->logger->info('WooCommerce: Product updated', ['product_id' => $product_id]);
        $this->trigger_sync('product', $product_id, 'update');
    }

    public function on_delete_product(int $product_id): void
    {
        $this->logger->info('WooCommerce: Product deleted', ['product_id' => $product_id]);
        $this->trigger_sync('product', $product_id, 'delete');
    }

    public function on_new_order(int $order_id): void
    {
        $this->logger->info('WooCommerce: New order', ['order_id' => $order_id]);
        $this->trigger_sync('order', $order_id, 'create');
    }

    public function on_order_completed(int $order_id): void
    {
        $this->logger->info('WooCommerce: Order completed', ['order_id' => $order_id]);
        $this->trigger_sync('order', $order_id, 'complete');
    }

    public function on_order_refunded(int $order_id): void
    {
        $this->logger->info('WooCommerce: Order refunded', ['order_id' => $order_id]);
        $this->trigger_sync('order', $order_id, 'refund');
    }

    public function on_order_cancelled(int $order_id): void
    {
        $this->logger->info('WooCommerce: Order cancelled', ['order_id' => $order_id]);
        $this->trigger_sync('order', $order_id, 'cancel');
    }

    public function on_new_customer(int $customer_id): void
    {
        $this->logger->info('WooCommerce: New customer', ['customer_id' => $customer_id]);
        $this->trigger_sync('customer', $customer_id, 'create');
    }

    private function trigger_sync(string $type, int $id, string $action): void
    {
        $sync_method = get_option('alegra_connector_sync_method', 'both');

        if ($sync_method === 'real-time' || $sync_method === 'both') {
            $sync_controller = new Sync\Controller($this->api, $this->logger);
            $sync_controller->sync_entity($type, $id, $action);
        }
    }
}
