<?php
/**
 * Professional pagination helper
 * Shows: « First ‹ Prev  ... 4 5 [6] 7 8 ... Next › Last »
 */
function alegra_pagination(int $current, int $total, string $base_url): string {
    if ($total <= 1) return '';
    
    $html = '<div class="ac-pagination">';
    $adjacent = 2; // Pages to show around current
    
    // Previous
    if ($current > 1) {
        $html .= '<a href="' . esc_url(add_query_arg('paged', 1, $base_url)) . '" title="Primera" class="ac-pg-btn">&laquo;</a>';
        $html .= '<a href="' . esc_url(add_query_arg('paged', $current - 1, $base_url)) . '" title="Anterior" class="ac-pg-btn">&lsaquo;</a>';
    }
    
    // Page numbers
    $start = max(1, $current - $adjacent);
    $end = min($total, $current + $adjacent);
    
    if ($start > 1) {
        $html .= '<a href="' . esc_url(add_query_arg('paged', 1, $base_url)) . '" class="ac-pg-btn">1</a>';
        if ($start > 2) $html .= '<span class="ac-pg-dots">...</span>';
    }
    
    for ($i = $start; $i <= $end; $i++) {
        $cls = $i === $current ? 'ac-pg-btn current' : 'ac-pg-btn';
        $html .= '<a href="' . esc_url(add_query_arg('paged', $i, $base_url)) . '" class="' . $cls . '">' . $i . '</a>';
    }
    
    if ($end < $total) {
        if ($end < $total - 1) $html .= '<span class="ac-pg-dots">...</span>';
        $html .= '<a href="' . esc_url(add_query_arg('paged', $total, $base_url)) . '" class="ac-pg-btn">' . $total . '</a>';
    }
    
    // Next
    if ($current < $total) {
        $html .= '<a href="' . esc_url(add_query_arg('paged', $current + 1, $base_url)) . '" title="Siguiente" class="ac-pg-btn">&rsaquo;</a>';
        $html .= '<a href="' . esc_url(add_query_arg('paged', $total, $base_url)) . '" title="Ultima" class="ac-pg-btn">&raquo;</a>';
    }
    
    $html .= '<span class="ac-pg-info">' . sprintf(__('%d de %d paginas', 'alegra-connector'), $current, $total) . '</span>';
    $html .= '</div>';
    
    return $html;
}
