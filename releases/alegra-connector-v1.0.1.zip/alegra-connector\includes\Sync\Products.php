<?php
/**
 * Products Sync Handler
 *
 * Full bidirectional sync with variant support.
 * Each WooCommerce variation becomes a variant item in Alegra,
 * linked as subitems to the parent variantParent.
 */

declare(strict_types=1);

namespace Alegra\Connector\Sync;

use Alegra\Connector\API;
use Alegra\Connector\Logger;

if (!defined('ABSPATH')) {
    exit;
}

class Products
{
    private ?API\Client $api;
    private ?Logger\Logger $logger;

    public function __construct(?API\Client $api, ?Logger\Logger $logger)
    {
        $this->api = $api;
        $this->logger = $logger;
    }

    /**
     * Sync a WooCommerce product (simple or variable) to Alegra
     */
    public function sync_to_alegra(\WC_Product $product): array|\WP_Error
    {
        if ($product->is_type('variable')) {
            return $this->sync_variable_product($product);
        }

        if ($product->is_type('variation')) {
            return $this->sync_variation($product);
        }

        $result = $this->sync_simple_product($product);

        // Sync product image if enabled
        if (!is_wp_error($result) && get_option('alegra_connector_sync_images', false)) {
            $this->sync_product_image($product, (int) ($result['id'] ?? 0));
        }

        return $result;
    }

    /**
     * Upload product featured image to Alegra item attachment
     */
    private function sync_product_image(\WC_Product $product, int $alegra_id): void
    {
        if ($alegra_id <= 0) return;

        $image_id = $product->get_image_id();
        if (!$image_id) return;

        $file_path = get_attached_file($image_id);
        if (!$file_path || !file_exists($file_path)) return;

        // Check file size (max 2MB per Alegra docs)
        if (filesize($file_path) > 2 * 1024 * 1024) {
            $this->logger->warning('Product image too large for Alegra (max 2MB)', [
                'product_id' => $product->get_id(), 'size' => filesize($file_path),
            ]);
            return;
        }

        $result = $this->api->upload_item_image($alegra_id, $file_path);
        if (is_wp_error($result)) {
            $this->logger->warning('Failed to upload product image to Alegra', [
                'product_id' => $product->get_id(), 'alegra_id' => $alegra_id, 'error' => $result->get_error_message(),
            ]);
        } else {
            $this->logger->info('Product image synced to Alegra', [
                'product_id' => $product->get_id(), 'alegra_id' => $alegra_id,
            ]);
        }
    }

    /**
     * Sync simple product
     */
    private function sync_simple_product(\WC_Product $product): array|\WP_Error
    {
        $alegra_id = (int) get_post_meta($product->get_id(), '_alegra_item_id', true);
        $data = $this->prepare_simple_product_data($product);

        if ($alegra_id > 0) {
            $result = $this->api->update_item($alegra_id, $data);
            $this->logger->info('Product updated in Alegra', [
                'product_id' => $product->get_id(),
                'alegra_id' => $alegra_id,
            ]);
        } else {
            $result = $this->api->create_item($data);
            if (!is_wp_error($result) && isset($result['id'])) {
                update_post_meta($product->get_id(), '_alegra_item_id', (int) $result['id']);
                $this->logger->info('Product created in Alegra', [
                    'product_id' => $product->get_id(),
                    'alegra_id' => $result['id'],
                ]);
            }
        }

        return $result;
    }

    /**
     * Sync variable product (parent with variants as subitems)
     */
    private function sync_variable_product(\WC_Product $product): array|\WP_Error
    {
        $alegra_id = (int) get_post_meta($product->get_id(), '_alegra_item_id', true);

        // First, sync each variation individually to get their Alegra IDs
        $variation_ids = $product->get_children();
        $subitems = [];

        foreach ($variation_ids as $variation_id) {
            $variation = wc_get_product($variation_id);
            if (!$variation) {
                continue;
            }
            // Sync each variation
            $var_result = $this->sync_variation($variation);
            if (!is_wp_error($var_result) && isset($var_result['id'])) {
                $subitems[] = [
                    'id' => (int) $var_result['id'],
                    'reference' => $variation->get_sku(),
                    'price' => (float) $variation->get_regular_price(),
                    'quantity' => (int) ($variation->get_stock_quantity() ?? 0),
                ];
            }
        }

        $data = $this->prepare_variable_product_data($product, $subitems);

        if ($alegra_id > 0) {
            $result = $this->api->update_item($alegra_id, $data);
            $this->logger->info('Variable product updated in Alegra', [
                'product_id' => $product->get_id(),
                'alegra_id' => $alegra_id,
                'variations' => count($subitems),
            ]);
        } else {
            $data['type'] = 'kit';
            $result = $this->api->create_item($data);
            if (!is_wp_error($result) && isset($result['id'])) {
                update_post_meta($product->get_id(), '_alegra_item_id', (int) $result['id']);
                $this->logger->info('Variable product created in Alegra', [
                    'product_id' => $product->get_id(),
                    'alegra_id' => $result['id'],
                    'variations' => count($subitems),
                ]);
            }
        }

        return $result;
    }

    /**
     * Sync a single variation to Alegra as an individual item
     */
    private function sync_variation(\WC_Product $variation): array|\WP_Error
    {
        $alegra_id = (int) get_post_meta($variation->get_id(), '_alegra_item_id', true);
        $data = $this->prepare_variation_data($variation);

        if ($alegra_id > 0) {
            $result = $this->api->update_item($alegra_id, $data);
        } else {
            $data['type'] = 'variant';
            $result = $this->api->create_item($data);
            if (!is_wp_error($result) && isset($result['id'])) {
                update_post_meta($variation->get_id(), '_alegra_item_id', (int) $result['id']);
                $this->logger->info('Variation synced to Alegra', [
                    'variation_id' => $variation->get_id(),
                    'alegra_id' => $result['id'],
                ]);
            }
        }

        return $result;
    }

    /**
     * Prepare data for simple product
     */
    private function prepare_simple_product_data(\WC_Product $product): array
    {
        $data = [
            'name' => $product->get_name(),
            'reference' => $product->get_sku(),
            'description' => wp_strip_all_tags($product->get_description()),
            'type' => 'simple',
            'price' => [
                [
                    'idPriceList' => 1,
                    'price' => (float) $product->get_regular_price(),
                ],
            ],
            'inventory' => [
                'unit' => 'unit',
                'initialQuantity' => (int) ($product->get_stock_quantity() ?? 0),
            ],
        ];

        // Sale price as additional price list
        $sale_price = $product->get_sale_price();
        if (!empty($sale_price)) {
            $data['price'][] = [
                'idPriceList' => 1,
                'price' => (float) $sale_price,
            ];
        }

        // Tax
        $tax_id = $this->map_product_tax($product);
        if ($tax_id > 0) {
            $data['tax'] = [['id' => $tax_id]];
        }

        // Category
        $cat_name = $this->get_main_category_name($product->get_category_ids());
        if ($cat_name) {
            $data['category'] = ['name' => $cat_name];
        }

        return $data;
    }

    /**
     * Prepare data for variable product parent
     */
    private function prepare_variable_product_data(\WC_Product $product, array $subitems): array
    {
        return [
            'name' => $product->get_name(),
            'reference' => $product->get_sku(),
            'description' => wp_strip_all_tags($product->get_description()),
            'type' => 'variantParent',
            'price' => [
                [
                    'idPriceList' => 1,
                    'price' => (float) $product->get_price(),
                ],
            ],
            'subitems' => $subitems,
        ];
    }

    /**
     * Prepare data for a single variation
     */
    private function prepare_variation_data(\WC_Product $variation): array
    {
        $parent = wc_get_product($variation->get_parent_id());
        $attributes = $variation->get_attributes();
        $name_parts = [$parent ? $parent->get_name() : 'Variation'];
        foreach ($attributes as $attr => $value) {
            $name_parts[] = $value;
        }
        $variation_name = implode(' - ', $name_parts);

        return [
            'name' => $variation_name,
            'reference' => $variation->get_sku(),
            'description' => wp_strip_all_tags($variation->get_description()),
            'price' => [
                [
                    'idPriceList' => 1,
                    'price' => (float) $variation->get_regular_price(),
                ],
            ],
            'inventory' => [
                'unit' => 'unit',
                'initialQuantity' => (int) ($variation->get_stock_quantity() ?? 0),
            ],
        ];
    }

    /**
     * Map product tax class to Alegra tax ID
     */
    private function map_product_tax(\WC_Product $product): int
    {
        $tax_class = $product->get_tax_class();
        if (empty($tax_class) || $tax_class === 'zero-rate') {
            return 0;
        }

        $tax_mapping = get_option('alegra_connector_tax_mapping', []);
        return isset($tax_mapping[$tax_class]) ? (int) $tax_mapping[$tax_class] : 0;
    }

    /**
     * Sync inventory from Alegra to WooCommerce (pull)
     */
    public function sync_inventory_from_alegra(): array
    {
        $result = ['updated' => 0, 'errors' => 0];

        $items = $this->api->get_items(['limit' => 30]);
        if (is_wp_error($items)) {
            return $result;
        }

        foreach ($items as $item) {
            if (!isset($item['inventory']['availableQuantity'])) {
                continue;
            }

            $product_id = $this->get_product_by_alegra_id((int) $item['id']);
            if (!$product_id) {
                continue;
            }

            $product = wc_get_product($product_id);
            if (!$product) {
                continue;
            }

            $new_qty = (int) $item['inventory']['availableQuantity'];
            if ($product->get_manage_stock()) {
                try {
                    $old_qty = $product->get_stock_quantity();
                    $product->set_stock_quantity($new_qty);
                    $product->save();
                    $result['updated']++;

                    if ($old_qty !== $new_qty) {
                        $this->logger->info('Inventory updated from Alegra', [
                            'product_id' => $product_id,
                            'alegra_id' => $item['id'],
                            'old_qty' => $old_qty,
                            'new_qty' => $new_qty,
                        ]);
                    }
                } catch (\Exception $e) {
                    $result['errors']++;
                    $this->logger->error('Failed to update inventory', [
                        'product_id' => $product_id,
                        'error' => $e->getMessage(),
                    ]);
                }
            }
        }

        $this->logger->info('Inventory sync from Alegra completed', $result);

        return $result;
    }

    /**
     * Sync inventory to Alegra after order completion
     */
    public function sync_inventory_to_alegra(\WC_Order $order): array
    {
        $result = ['updated' => 0, 'errors' => 0];

        foreach ($order->get_items() as $item) {
            $product = $item->get_product();
            if (!$product) {
                continue;
            }

            $alegra_id = (int) get_post_meta($product->get_id(), '_alegra_item_id', true);
            if ($alegra_id <= 0) {
                continue;
            }

            $current_stock = $product->get_stock_quantity();
            if ($current_stock === null) {
                continue;
            }

            $updated_data = [
                'inventory' => [
                    'availableQuantity' => $current_stock,
                ],
            ];

            $api_result = $this->api->update_item($alegra_id, $updated_data);
            if (is_wp_error($api_result)) {
                $result['errors']++;
                $this->logger->error('Failed to sync inventory to Alegra', [
                    'product_id' => $product->get_id(),
                    'alegra_id' => $alegra_id,
                    'error' => $api_result->get_error_message(),
                ]);
            } else {
                $result['updated']++;
            }
        }

        return $result;
    }

    public function sync_all(): array|\WP_Error
    {
        $result = ['synced' => 0, 'errors' => 0];
        $args = [
            'limit' => 30,
            'status' => 'publish',
            'type' => ['simple', 'variable'],
        ];

        $products = wc_get_products($args);

        foreach ($products as $product) {
            $sync_result = $this->sync_to_alegra($product);
            if (is_wp_error($sync_result)) {
                $result['errors']++;
                $this->logger->error('Failed to sync product', [
                    'product_id' => $product->get_id(),
                    'error' => $sync_result->get_error_message(),
                ]);
            } else {
                $result['synced']++;
            }
        }

        $this->logger->info('Products sync completed', $result);

        return $result;
    }

    public function import_from_alegra(int $page = 1, int $per_page = 30): array|\WP_Error
    {
        $result = ['imported' => 0, 'updated' => 0, 'errors' => 0, 'total_pages' => 0, 'current_page' => 0];
        $current_page = $page;
        $max_pages = 200; // ~6000 items max

        // Prevent PHP timeout on large syncs
        set_time_limit(300);

        for ($p = 1; $p <= $max_pages; $p++) {
            // Update progress transient
            set_transient('alegra_sync_progress', [
                'type' => 'products',
                'current_page' => $p,
                'items_processed' => $result['imported'] + $result['updated'] + $result['errors'],
                'imported' => $result['imported'],
                'updated' => $result['updated'],
                'message' => sprintf(__('Procesando productos... Pagina %d', 'alegra-connector'), $p),
            ], 120);

            $alegra_items = $this->api->get_items([
                'page' => $current_page,
                'limit' => $per_page,
            ]);

            if (is_wp_error($alegra_items)) {
                delete_transient('alegra_sync_progress');
                if ($current_page === 1) return $alegra_items;
                break;
            }

            if (empty($alegra_items)) break;

            foreach ($alegra_items as $item) {
                $r = $this->import_single_item_from_alegra($item);
                if ($r === true) $result['imported']++;
                elseif ($r === 'updated') $result['updated']++;
                else $result['errors']++;
            }

            if (count($alegra_items) < $per_page) break;
            $current_page++;
        }

        // Final progress
        set_transient('alegra_sync_progress', [
            'type' => 'products',
            'current_page' => $current_page,
            'items_processed' => $result['imported'] + $result['updated'] + $result['errors'],
            'imported' => $result['imported'],
            'updated' => $result['updated'],
            'done' => true,
            'message' => sprintf(__('Completado: %d importados, %d actualizados', 'alegra-connector'), $result['imported'], $result['updated']),
        ], 60);

        $this->logger->info('Products import from Alegra completed', $result);
        $result['total_pages'] = $current_page;

        return $result;
    }

    /**
     * Sync a single item by Alegra ID (used by webhooks)
     */
    private function import_single_item_from_alegra(array $item): bool|string
    {
        $alegra_id = (int) ($item['id'] ?? 0);
        $sku = $item['reference'] ?? '';
        $name = $item['name'] ?? '';
        $type = $item['type'] ?? 'simple';

        // Skip variant children - they're imported with their parent
        if ($type === 'variant') {
            return 'skipped';
        }

        $existing_id = $this->get_product_by_alegra_id($alegra_id);

        if ($existing_id) {
            $product = wc_get_product($existing_id);
            if ($product) {
                $this->update_product_from_alegra($product, $item);
                return 'updated';
            }
        }

        // Check by SKU
        if (!empty($sku)) {
            $existing_by_sku = $this->get_product_by_sku($sku);
            if ($existing_by_sku) {
                update_post_meta($existing_by_sku, '_alegra_item_id', $alegra_id);
                $product = wc_get_product($existing_by_sku);
                if ($product) {
                    $this->update_product_from_alegra($product, $item);
                    return 'updated';
                }
            }
        }

        // Create new product
        $is_variable = ($type === 'variantParent' || $type === 'kit');

        $product_id = wp_insert_post([
            'post_title' => $name,
            'post_content' => $item['description'] ?? '',
            'post_type' => 'product',
            'post_status' => 'publish',
        ]);

        if (is_wp_error($product_id) || !$product_id) {
            $this->logger->error('Failed to create product from Alegra', [
                'alegra_id' => $alegra_id,
                'error' => is_wp_error($product_id) ? $product_id->get_error_message() : 'Unknown',
            ]);
            return false;
        }

        update_post_meta($product_id, '_alegra_item_id', $alegra_id);
        update_post_meta($product_id, '_sku', $sku);

        $product = wc_get_product($product_id);
        if ($product) {
            if ($is_variable) {
                // Convert to variable product
                wp_set_object_terms($product_id, 'variable', 'product_type');
                $product = wc_get_product($product_id);
            }
            $this->update_product_from_alegra($product, $item);
        }

        // Import variant children
        if ($is_variable && !empty($item['subitems'])) {
            foreach ($item['subitems'] as $subitem_data) {
                $this->import_variation_from_alegra($product_id, $subitem_data);
            }
        }

        $this->logger->info('Product imported from Alegra', [
            'alegra_id' => $alegra_id,
            'product_id' => $product_id,
        ]);

        return true;
    }

    /**
     * Import a variation from Alegra subitem
     */
    private function import_variation_from_alegra(int $parent_id, array $subitem_data): void
    {
        $alegra_id = (int) ($subitem_data['id'] ?? 0);
        if ($alegra_id <= 0) {
            return;
        }

        $item = $this->api->get_item($alegra_id);
        if (is_wp_error($item) || !is_array($item)) {
            return;
        }

        $variation_id = $this->get_product_by_alegra_id($alegra_id);
        if ($variation_id) {
            $variation = wc_get_product($variation_id);
            if ($variation) {
                $this->update_product_from_alegra($variation, $item);
                return;
            }
        }

        // Create variation
        $variation_id = wp_insert_post([
            'post_title' => $item['name'] ?? 'Variation',
            'post_type' => 'product_variation',
            'post_status' => 'publish',
            'post_parent' => $parent_id,
        ]);

        if (is_wp_error($variation_id) || !$variation_id) {
            return;
        }

        update_post_meta($variation_id, '_alegra_item_id', $alegra_id);

        $variation = wc_get_product($variation_id);
        if ($variation) {
            $this->update_product_from_alegra($variation, $item);
        }
    }

    private function update_product_from_alegra(\WC_Product $product, array $item): void
    {
        // Price extraction
        $price = 0;
        if (isset($item['price']) && is_array($item['price'])) {
            foreach ($item['price'] as $pe) {
                if (isset($pe['idPriceList']) && (int) $pe['idPriceList'] === 1) {
                    $price = (float) ($pe['price'] ?? 0);
                    break;
                }
            }
            if ($price === 0 && !empty($item['price'][0]['price'])) {
                $price = (float) $item['price'][0]['price'];
            }
        } elseif (isset($item['price']) && is_numeric($item['price'])) {
            $price = (float) $item['price'];
        }

        $product->set_regular_price($price);

        if (!empty($item['name'])) {
            $product->set_name($item['name']);
        }
        $product->set_status('publish');

        if (!empty($item['description'])) {
            $product->set_description($item['description']);
        }

        if (isset($item['inventory']['availableQuantity']) && $product->get_manage_stock()) {
            try {
                $product->set_stock_quantity((int) $item['inventory']['availableQuantity']);
            } catch (\Exception $e) {
                $this->logger->warning('Failed to update stock: ' . $e->getMessage());
            }
        }

        if (!empty($item['reference'])) {
            $product->set_sku($item['reference']);
        }

        $product->save();
    }

    public function import_single_item_public(array $item): bool|string
    {
        return $this->import_single_item_from_alegra($item);
    }

    public function sync_single_item_by_alegra_id(int $alegra_id): bool|string
    {
        $item = $this->api->get_item($alegra_id);
        if (is_wp_error($item) || !is_array($item)) {
            return false;
        }
        return $this->import_single_item_from_alegra($item);
    }

    public function delete_from_alegra(int $product_id): array|\WP_Error
    {
        $alegra_id = (int) get_post_meta($product_id, '_alegra_item_id', true);
        if ($alegra_id <= 0) {
            return new \WP_Error('not_linked', 'Product not linked to Alegra');
        }

        $result = $this->api->delete_item($alegra_id);
        if (!is_wp_error($result)) {
            delete_post_meta($product_id, '_alegra_item_id');
        }

        return $result;
    }

    private function get_product_by_alegra_id(int $alegra_id): ?int
    {
        global $wpdb;
        $id = $wpdb->get_var($wpdb->prepare(
            "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_alegra_item_id' AND meta_value = %d LIMIT 1",
            $alegra_id
        ));
        return $id ? (int) $id : null;
    }

    private function get_product_by_sku(string $sku): ?int
    {
        if (empty($sku)) {
            return null;
        }
        $id = wc_get_product_id_by_sku($sku);
        return $id ? (int) $id : null;
    }

    private function get_main_category_name(array $cat_ids): ?string
    {
        if (empty($cat_ids)) {
            return null;
        }
        $cat = get_term($cat_ids[0], 'product_cat');
        return ($cat && !is_wp_error($cat)) ? $cat->name : null;
    }
}