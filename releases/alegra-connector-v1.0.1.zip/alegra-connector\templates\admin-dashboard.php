<?php
if(!defined('ABSPATH'))exit;
$is_connected=isset($is_connected)?$is_connected:(bool)get_option('alegra_connector_connection_tested');
$company_name=isset($company_name)?$company_name:esc_html(get_option('alegra_connector_company_name',''));
$last_sync=isset($last_sync)?$last_sync:get_transient('alegra_connector_last_sync');
$stats=isset($stats)?$stats:['products'=>0,'customers'=>0,'orders'=>0,'categories'=>0];
$sync_method=get_option('alegra_connector_sync_method','both');
$sync_frequency=(int)get_option('alegra_connector_sync_frequency',15);
$page_title=__('Dashboard','alegra-connector');
include __DIR__.'/header.php';
?>
<div class="alegra-connector-wrap">

<?php if(!$is_connected):?>
<!-- Getting Started (only shown when not connected) -->
<div class="ac-card" style="margin-bottom:16px;border-left:4px solid var(--ac-primary);">
    <div class="ac-card-header"><h2><?php esc_html_e('Bienvenido a Alegra Connector','alegra-connector');?></h2></div>
    <p style="font-size:13px;color:var(--ac-text-secondary);line-height:1.7;">
        <?php esc_html_e('Este plugin conecta tu tienda WooCommerce con el sistema contable Alegra para sincronizar productos, clientes, pedidos, inventario y facturacion de forma bidireccional.','alegra-connector');?>
    </p>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-top:16px;">
        <div style="background:var(--ac-primary-light);padding:14px 16px;border-radius:8px;">
            <strong style="font-size:13px;color:var(--ac-primary);"><?php esc_html_e('1. Configurar Conexion','alegra-connector');?></strong>
            <p style="font-size:12px;color:var(--ac-text-secondary);margin:4px 0 0 0;"><?php esc_html_e('Ve a Configuracion > Conexion e ingresa tu email y token API de Alegra.','alegra-connector');?></p>
            <a href="<?php echo esc_url(admin_url('admin.php?page=alegra-connector-settings'));?>" class="ac-btn ac-btn-sm ac-btn-primary" style="margin-top:8px;"><?php esc_html_e('Configurar','alegra-connector');?></a>
        </div>
        <div style="background:var(--ac-warning-bg);padding:14px 16px;border-radius:8px;">
            <strong style="font-size:13px;color:var(--ac-warning);"><?php esc_html_e('2. Mapear Impuestos','alegra-connector');?></strong>
            <p style="font-size:12px;color:var(--ac-text-secondary);margin:4px 0 0 0;"><?php esc_html_e('Define que impuestos de WooCommerce corresponden a los de Alegra para facturar correctamente.','alegra-connector');?></p>
            <a href="<?php echo esc_url(admin_url('admin.php?page=alegra-connector-mapping'));?>" class="ac-btn ac-btn-sm" style="margin-top:8px;"><?php esc_html_e('Mapear','alegra-connector');?></a>
        </div>
        <div style="background:var(--ac-success-bg);padding:14px 16px;border-radius:8px;">
            <strong style="font-size:13px;color:var(--ac-success);"><?php esc_html_e('3. Sincronizar','alegra-connector');?></strong>
            <p style="font-size:12px;color:var(--ac-text-secondary);margin:4px 0 0 0;"><?php esc_html_e('Ejecuta la primera sincronizacion para enviar tus productos y clientes a Alegra.','alegra-connector');?></p>
            <button type="button" class="ac-btn ac-btn-sm ac-btn-primary alegra-quick-sync" data-type="all" style="margin-top:8px;"><?php esc_html_e('Sincronizar Todo','alegra-connector');?></button>
        </div>
    </div>
</div>
<?php endif;?>

<!-- Quick Actions -->
<div class="ac-card" style="margin-bottom:16px;">
    <div class="ac-card-header"><h2><?php esc_html_e('Acciones Rapidas','alegra-connector');?></h2></div>
    <div style="display:flex;gap:10px;flex-wrap:wrap;">
        <button type="button" class="ac-btn ac-btn-primary" id="alegra-sync-now-btn"><span class="dashicons dashicons-update" style="font-size:16px;width:16px;height:16px;"></span> <?php esc_html_e('Sincronizar ahora','alegra-connector');?></button>
        <a href="<?php echo esc_url(admin_url('admin.php?page=alegra-connector-settings'));?>" class="ac-btn"><span class="dashicons dashicons-admin-settings" style="font-size:16px;width:16px;height:16px;"></span> <?php esc_html_e('Configuracion','alegra-connector');?></a>
        <a href="<?php echo esc_url(admin_url('admin.php?page=alegra-connector-stats'));?>" class="ac-btn"><span class="dashicons dashicons-chart-area" style="font-size:16px;width:16px;height:16px;"></span> <?php esc_html_e('Estadisticas','alegra-connector');?></a>
        <a href="<?php echo esc_url(admin_url('admin.php?page=alegra-connector-products'));?>" class="ac-btn"><span class="dashicons dashicons-products" style="font-size:16px;width:16px;height:16px;"></span> <?php esc_html_e('Productos','alegra-connector');?></a>
        <a href="<?php echo esc_url(admin_url('admin.php?page=alegra-connector-orders'));?>" class="ac-btn"><span class="dashicons dashicons-cart" style="font-size:16px;width:16px;height:16px;"></span> <?php esc_html_e('Pedidos','alegra-connector');?></a>
        <a href="<?php echo esc_url(admin_url('admin.php?page=alegra-connector-logs'));?>" class="ac-btn"><span class="dashicons dashicons-media-text" style="font-size:16px;width:16px;height:16px;"></span> <?php esc_html_e('Logs','alegra-connector');?></a>
    </div>
</div>

<!-- Status Overview -->
<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px;">
    <!-- Sync Status -->
    <div class="ac-card">
        <div class="ac-card-header"><h2><?php esc_html_e('Estado de Sincronizacion','alegra-connector');?></h2>
            <span class="ac-badge <?php echo $is_connected?'success':'warning';?>"><?php echo $is_connected?esc_html__('Conectado','alegra-connector'):esc_html__('Desconectado','alegra-connector');?></span>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
            <div style="background:var(--ac-surface-alt);padding:12px;border-radius:8px;">
                <span style="font-size:11px;font-weight:600;color:var(--ac-text-secondary);text-transform:uppercase;"><?php esc_html_e('Metodo','alegra-connector');?></span>
                <div style="font-size:14px;font-weight:600;color:var(--ac-text);margin-top:2px;">
                    <?php echo $sync_method==='both'?esc_html__('Tiempo Real + Periodica','alegra-connector'):($sync_method==='real-time'?esc_html__('Tiempo Real','alegra-connector'):esc_html__('Periodica','alegra-connector'));?>
                </div>
            </div>
            <div style="background:var(--ac-surface-alt);padding:12px;border-radius:8px;">
                <span style="font-size:11px;font-weight:600;color:var(--ac-text-secondary);text-transform:uppercase;"><?php esc_html_e('Frecuencia','alegra-connector');?></span>
                <div style="font-size:14px;font-weight:600;color:var(--ac-text);margin-top:2px;"><?php echo esc_html($sync_frequency.' min');?></div>
            </div>
            <div style="background:var(--ac-surface-alt);padding:12px;border-radius:8px;">
                <span style="font-size:11px;font-weight:600;color:var(--ac-text-secondary);text-transform:uppercase;"><?php esc_html_e('Ultima Sincronizacion','alegra-connector');?></span>
                <div style="font-size:14px;font-weight:600;color:var(--ac-text);margin-top:2px;"><?php echo $last_sync?esc_html(human_time_diff($last_sync,time()).' '.__('atras','alegra-connector')):esc_html__('Nunca','alegra-connector');?></div>
            </div>
            <div style="background:var(--ac-surface-alt);padding:12px;border-radius:8px;">
                <span style="font-size:11px;font-weight:600;color:var(--ac-text-secondary);text-transform:uppercase;"><?php esc_html_e('Empresa','alegra-connector');?></span>
                <div style="font-size:14px;font-weight:600;color:var(--ac-text);margin-top:2px;"><?php echo $is_connected?esc_html($company_name):esc_html__('No conectado','alegra-connector');?></div>
                <?php if($is_connected):?><div style="font-size:11px;color:var(--ac-text-muted);margin-top:1px;"><?php echo esc_html(get_option('alegra_connector_company_country',''));?></div><?php endif;?>
            </div>
        </div>
    </div>

    <!-- Entity Counts -->
    <div class="ac-card">
        <div class="ac-card-header"><h2><?php esc_html_e('Entidades en WooCommerce','alegra-connector');?></h2></div>
        <div class="ac-kpi-grid" style="grid-template-columns:1fr 1fr;gap:10px;">
            <div class="ac-kpi-card accent-green" style="padding:12px 16px;">
                <div class="ac-kpi-icon" style="width:36px;height:36px;"><span class="dashicons dashicons-products"></span></div>
                <div class="ac-kpi-content"><span class="ac-kpi-label"><?php esc_html_e('Productos','alegra-connector');?></span><span class="ac-kpi-value" style="font-size:18px;"><?php echo esc_html($stats['products']);?></span></div>
            </div>
            <div class="ac-kpi-card accent-blue" style="padding:12px 16px;">
                <div class="ac-kpi-icon" style="width:36px;height:36px;"><span class="dashicons dashicons-groups"></span></div>
                <div class="ac-kpi-content"><span class="ac-kpi-label"><?php esc_html_e('Clientes','alegra-connector');?></span><span class="ac-kpi-value" style="font-size:18px;"><?php echo esc_html($stats['customers']);?></span></div>
            </div>
            <div class="ac-kpi-card accent-amber" style="padding:12px 16px;">
                <div class="ac-kpi-icon" style="width:36px;height:36px;"><span class="dashicons dashicons-cart"></span></div>
                <div class="ac-kpi-content"><span class="ac-kpi-label"><?php esc_html_e('Pedidos','alegra-connector');?></span><span class="ac-kpi-value" style="font-size:18px;"><?php echo esc_html($stats['orders']);?></span></div>
            </div>
            <div class="ac-kpi-card accent-purple" style="padding:12px 16px;">
                <div class="ac-kpi-icon" style="width:36px;height:36px;"><span class="dashicons dashicons-category"></span></div>
                <div class="ac-kpi-content"><span class="ac-kpi-label"><?php esc_html_e('Categorias','alegra-connector');?></span><span class="ac-kpi-value" style="font-size:18px;"><?php echo esc_html($stats['categories']);?></span></div>
            </div>
        </div>
    </div>
</div>

<!-- About -->
<div class="ac-card" style="border-left:4px solid var(--ac-primary);">
    <div class="ac-card-header"><h2><?php esc_html_e('Acerca de Alegra Connector','alegra-connector');?></h2></div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
        <div>
            <p style="font-size:13px;color:var(--ac-text-secondary);line-height:1.7;">
                <strong><?php esc_html_e('Version','alegra-connector');?>:</strong> <?php echo esc_html(ALEGRA_CONNECTOR_VERSION);?><br>
                <strong><?php esc_html_e('Sincronizacion bidireccional','alegra-connector');?>:</strong> <?php esc_html_e('Productos, clientes, pedidos, categorias e inventario entre WooCommerce y Alegra.','alegra-connector');?><br>
                <strong><?php esc_html_e('Facturacion automatica','alegra-connector');?>:</strong> <?php esc_html_e('Al completar un pedido se crea la factura en Alegra con numeracion y terminos de pago.','alegra-connector');?><br>
                <strong><?php esc_html_e('Webhooks','alegra-connector');?>:</strong> <?php esc_html_e('Recibe notificaciones de Alegra en tiempo real para mantener ambos sistemas sincronizados.','alegra-connector');?><br>
                <strong><?php esc_html_e('Multi-moneda','alegra-connector');?>:</strong> <?php esc_html_e('Soporte para todas las monedas configuradas en tu cuenta Alegra.','alegra-connector');?>
            </p>
        </div>
        <div>
            <p style="font-size:13px;color:var(--ac-text-secondary);line-height:1.7;">
                <strong><?php esc_html_e('Desarrollado por','alegra-connector');?>:</strong><br>
                <a href="https://scriptdevelop.com.co" target="_blank" style="display:inline-flex;align-items:center;gap:6px;text-decoration:none;">
                    <img src="<?php echo esc_url(ALEGRA_CONNECTOR_URL . 'admin/assets/images/scriptdevelop.svg'); ?>" alt="Script Develop" style="height:20px;">
                    <span style="color:var(--ac-text);">Script Develop</span>
                </a>
                <br><br>
                <strong><?php esc_html_e('Documentacion','alegra-connector');?>:</strong> <?php esc_html_e('Disponible en la carpeta docs/ del plugin.','alegra-connector');?><br>
                <strong><?php esc_html_e('Soporte','alegra-connector');?>:</strong> <a href="https://scriptdevelop.com.co" target="_blank">scriptdevelop.com.co</a><br>
                <strong><?php esc_html_e('API Alegra','alegra-connector');?>:</strong> <a href="https://developer.alegra.com" target="_blank">developer.alegra.com</a>
            </p>
        </div>
    </div>
</div>

<?php include __DIR__.'/footer.php'; ?>
</div>

<div id="alegra-sync-modal" class="ac-modal-overlay" style="display:none;">
    <div class="ac-modal">
        <h2><?php esc_html_e('Sincronizacion','alegra-connector');?></h2>
        <p style="margin-bottom:12px;"><?php esc_html_e('Selecciona que sincronizar:','alegra-connector');?></p>
        <div style="margin-bottom:16px;">
            <label style="display:block;margin:4px 0;"><input type="checkbox" name="sync_products" checked> <?php esc_html_e('Productos','alegra-connector');?></label>
            <label style="display:block;margin:4px 0;"><input type="checkbox" name="sync_customers" checked> <?php esc_html_e('Clientes','alegra-connector');?></label>
            <label style="display:block;margin:4px 0;"><input type="checkbox" name="sync_orders"> <?php esc_html_e('Pedidos','alegra-connector');?></label>
            <label style="display:block;margin:4px 0;"><input type="checkbox" name="sync_categories" checked> <?php esc_html_e('Categorias','alegra-connector');?></label>
        </div>
        <div class="ac-modal-actions">
            <button type="button" class="ac-btn" id="alegra-sync-cancel"><?php esc_html_e('Cancelar','alegra-connector');?></button>
            <button type="button" class="ac-btn ac-btn-primary" id="alegra-sync-start"><?php esc_html_e('Iniciar','alegra-connector');?></button>
        </div>
    </div>
</div>