# Changelog

All notable changes to Alegra Connector.

## [2.0.0] - 2026-09-02

### 🛡️ Critical Fixes (Sección A)

- **Fix `$country` undefined** in `Orders::prepare_invoice_data()` — `paymentForm` now correctly assigned for Colombian customers (was always `null`)
- **Anti-duplication mutex** in `Orders::create_invoice()` — prevents duplicate invoices from concurrent requests
- **Thread-safe re-entrancy guard** in `Public_::trigger_sync()` — uses transient-based mutex for PHP-FPM multi-worker
- **Anti-loop guard** in `Products::update_product_from_alegra()` — prevents recursive sync from `woocommerce_update_product` hook
- **`wp_raise_memory_limit()`** now applied to ALL heavy AJAX handlers (was only in `ajax_sync_page`)
- **`set_time_limit()`** added to `ajax_sync_pending_orders`, `ajax_sync_pending_page`, `ajax_import_from_api`, `ajax_cleanup_duplicate_images`
- **Webhooks** handled `delete-invoice`, `new-bill`, `edit-bill`, `delete-bill` (previously discarded silently)

### 🔄 Kill Switch (Sección E)

- **NEW:** `includes/Kill_Switch.php` — global plugin enable/disable control with per-request cache (<0.1ms check)
- **`ajax_disconnect()`** now exhaustive: activates kill switch, clears ALL `alegra_*` transients via SQL DELETE, clears ALL cron schedules, tries webhook cleanup in Alegra (best-effort with try/catch)
- **`deactivate()`** now exhaustive: kill switch + all transients + all cron + records deactivation summary
- **Preserves** credentials, options, mappings (per user decision)

### 🪦 Tombstones (Sección F)

- **NEW:** `includes/Tombstone_Manager.php` — records products deleted in WC to prevent recreation
- **NEW:** `includes/Schema.php` — idempotent migrations via `dbDelta()` for all plugin tables
- **Hook:** `before_delete_post` automatically creates tombstones for products with `_alegra_item_id`
- **`Products::import_single_item_from_alegra()`** now checks tombstones before creating new products
- **Tombstone blocks CREATION only** — does not block updates of existing products
- **Resurrection:** if product reappears via pull, tombstone is marked `resurrected_at`

### 🎨 UI Audit Fixes (Sección A.0)

- **HTML broken** in `admin-products.php` lines 17-18 — value was inside style attribute, now correctly inside span
- **Method bug** in `admin-dashboard.php` line 65 — `real-time` and `disabled` modes now correctly displayed
- **Default inconsistency** in `admin-settings.php` — added "Solo Tiempo Real" and "Desactivada" radio options
- **CSS `line-clamp: 2`** now opt-in via `ac-td-clamp` class instead of forced on all table cells
- **XSS in markdown** in `admin-docs.php` — `javascript:`, `data:`, `vbscript:`, `file:` URLs now blocked
- **One-liner 1500+ chars** in `admin-order-detail.php` — rewritten with proper formatting
- **`$GLOBALS['alegra_api']` anti-pattern** replaced with local `$alegra_api` variable
- **PHP 8+ undefined variables** in `admin-product-detail.php`, `admin-customer-detail.php` — now initialized with `?? null`

### 📋 Documentation

- **NEW:** `docs/UI_AUDIT.md` — comprehensive UI audit with bugs found, fixes applied, and pending issues
- **NEW:** `docs/PLAN.md` — full SDD (Software Design Document)

### 🗃️ Database

- **NEW tables** (created via dbDelta on plugins_loaded):
  - `wp_alegra_tombstones` — with UNIQUE KEY (alegra_type, alegra_id)
  - `wp_alegra_pull_queue` — for pending Alegra→WC changes
  - `wp_alegra_runs` — process monitor history
  - `wp_alegra_push_log` — push audit log
  - `wp_alegra_entity_map` — indexed Alegra↔WC mapping (table created, backfill in next release)

### 📦 Technical Details

- Plugin version: **1.0.5 → 2.0.0**
- New PHP classes: `Kill_Switch`, `Schema`, `Tombstone_Manager`
- New database tables: 5 (see above)
- All changes are backward compatible (no breaking changes to existing data)
- Existing user options preserved on deactivate/reactivate

### ⚠️ Known Limitations

- **Token encryption:** Still in plaintext in DB (deferred to v2.1.0 — analysis documented in `docs/PLAN.md`)
- **Cron disabled by default:** Sync mode defaults to manual (user must enable in settings)
- **Push to Alegra:** Disabled by default for sales/payments/clients to preserve accounting data integrity. User enables via settings after manual testing.

### 🔜 Planned for v2.1.0

- Token encryption (per `docs/PLAN.md`)
- Custom entity_map table backfill from postmeta
- Rate limiter with token bucket (Alegra: 60 req/min)
- Idempotency keys for `create_invoice` / `create_payment`
- Push queue UI with double confirmation
- Monitor UI (uses `wp_alegra_runs` table already in place)
