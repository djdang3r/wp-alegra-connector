<?php
/**
 * Admin Dashboard
 *
 * @package Alegra\Connector\Admin
 */

declare(strict_types=1);

namespace Alegra\Connector\Admin;

use Alegra\Connector\API;
use Alegra\Connector\HPOS;
use Alegra\Connector\Logger;
use Alegra\Connector\Sync;

if (!defined('ABSPATH')) {
    exit;
}

class Admin_Dashboard
{
    private ?API\Client $api;
    private ?Logger\Logger $logger;

    public function __construct(?API\Client $api, ?Logger\Logger $logger)
    {
        $this->api = $api;
        $this->logger = $logger;

        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_init', [$this, 'maybe_redirect_wizard']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
        // The webhook buffer's only write. admin-post.php (POST-redirect-GET) so
        // the clear is idempotent and cannot be replayed by a page refresh.
        add_action('admin_post_alegra_clear_webhooks', [$this, 'handle_clear_webhooks']);

        add_action('wp_ajax_alegra_test_connection', [$this, 'ajax_test_connection']);
        add_action('wp_ajax_alegra_verify_consumidor_final', [$this, 'ajax_verify_consumidor_final']);
        add_action('wp_ajax_alegra_sync_now', [$this, 'ajax_sync_now']);
        add_action('wp_ajax_alegra_import_csv', [$this, 'ajax_import_csv']);
        add_action('wp_ajax_alegra_clear_logs', [$this, 'ajax_clear_logs']);
        add_action('wp_ajax_alegra_download_logs', [$this, 'ajax_download_logs']);
        add_action('wp_ajax_alegra_save_mapping', [$this, 'ajax_save_mapping']);
        add_action('wp_ajax_alegra_sync_single', [$this, 'ajax_sync_single']);
        add_action('wp_ajax_alegra_record_payment', [$this, 'ajax_record_payment']);
        add_action('wp_ajax_alegra_emit_credit_note', [$this, 'ajax_emit_credit_note']);
        add_action('wp_ajax_alegra_open_invoice', [$this, 'ajax_open_invoice']);
        add_action('wp_ajax_alegra_import_from_api', [$this, 'ajax_import_from_api']);
        add_action('wp_ajax_alegra_sync_inventory', [$this, 'ajax_sync_inventory']);
        add_action('wp_ajax_alegra_export_csv', [$this, 'ajax_export_csv']);
        add_action('wp_ajax_alegra_bulk_sync', [$this, 'ajax_bulk_sync']);
        add_action('wp_ajax_alegra_get_invoice_pdf', [$this, 'ajax_get_invoice_pdf']);
        add_action('wp_ajax_alegra_disconnect', [$this, 'ajax_disconnect']);
        add_action('wp_ajax_alegra_check_endpoints', [$this, 'ajax_check_endpoints']);
        add_action('wp_ajax_alegra_sync_progress', [$this, 'ajax_sync_progress']);
        add_action('wp_ajax_alegra_sync_start', [$this, 'ajax_sync_start']);
        add_action('wp_ajax_alegra_sync_page', [$this, 'ajax_sync_page']);
        add_action('wp_ajax_alegra_get_item_categories', [$this, 'ajax_get_item_categories']);
        add_action('wp_ajax_alegra_import_single', [$this, 'ajax_import_single']);
        add_action('wp_ajax_alegra_bulk_import', [$this, 'ajax_bulk_import']);
        add_action('wp_ajax_alegra_cleanup_placeholders', [$this, 'ajax_cleanup_placeholders']);
        add_action('wp_ajax_alegra_sync_pending_orders', [$this, 'ajax_sync_pending_orders']);
        add_action('wp_ajax_alegra_sync_pending_start', [$this, 'ajax_sync_pending_start']);
        add_action('wp_ajax_alegra_sync_pending_page', [$this, 'ajax_sync_pending_page']);
        add_action('wp_ajax_alegra_cancel_sync', [$this, 'ajax_cancel_sync']);
        add_action('wp_ajax_alegra_register_webhooks', [$this, 'ajax_register_webhooks']);
        add_action('wp_ajax_alegra_delete_webhooks', [$this, 'ajax_delete_webhooks']);
        add_action('wp_ajax_alegra_cleanup_duplicate_images', [$this, 'ajax_cleanup_duplicate_images']);
        add_action('wp_ajax_alegra_monitor_status', [$this, 'ajax_monitor_status']);
        add_action('wp_ajax_alegra_kill_run', [$this, 'ajax_kill_run']);
        add_action('wp_ajax_alegra_kill_all', [$this, 'ajax_kill_all']);
        add_action('wp_ajax_alegra_clear_kill_switch', [$this, 'ajax_clear_kill_switch']);
        add_action('wp_ajax_alegra_rebuild_image_index', [$this, 'ajax_rebuild_image_index']);
        add_action('wp_ajax_alegra_image_index_stats', [$this, 'ajax_image_index_stats']);
        add_action('wp_ajax_alegra_wizard_advance', [$this, 'ajax_wizard_advance']);
        add_action('wp_ajax_alegra_wizard_skip', [$this, 'ajax_wizard_skip']);
        add_action('wp_ajax_alegra_run_cron_now', [$this, 'ajax_run_cron_now']);
        add_action('wp_ajax_alegra_skip_cron_next', [$this, 'ajax_skip_cron_next']);
        add_action('wp_ajax_alegra_unschedule_cron', [$this, 'ajax_unschedule_cron']);
        add_action('wp_ajax_alegra_change_cron_frequency', [$this, 'ajax_change_cron_frequency']);
    }

    /**
     * Null-safe logger
     */
    private function log(string $level, string $message, array $context = []): void
    {
        if ($this->logger === null) return;
        switch ($level) {
            case 'info': $this->logger->info($message, $context); break;
            case 'warning': $this->logger->warning($message, $context); break;
            case 'error': $this->logger->error($message, $context); break;
        }
    }

    private function get_product_by_alegra_id(string $alegra_id): ?int
    {
        global $wpdb;
        // Alegra ids are UUID strings (VARCHAR(36)); %d truncated them to 0.
        $pid = $wpdb->get_var($wpdb->prepare("SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key='_alegra_item_id' AND meta_value=%s LIMIT 1", $alegra_id));
        return $pid ? (int)$pid : null;
    }

    public function add_admin_menu(): void
    {
        add_menu_page(
            __('Alegra Connector', 'alegra-connector'),
            __('Alegra Connector', 'alegra-connector'),
            'manage_woocommerce',
            'alegra-connector',
            [$this, 'render_dashboard'],
            'dashicons-update',
            30
        );

        add_submenu_page(
            'alegra-connector',
            __('Dashboard', 'alegra-connector'),
            __('Dashboard', 'alegra-connector'),
            'manage_woocommerce',
            'alegra-connector',
            [$this, 'render_dashboard']
        );

        add_submenu_page(
            'alegra-connector',
            __('Estadísticas', 'alegra-connector'),
            __('Estadísticas', 'alegra-connector'),
            'manage_woocommerce',
            'alegra-connector-stats',
            [$this, 'render_statistics_page']
        );

        add_submenu_page(
            'alegra-connector',
            __('Productos', 'alegra-connector'),
            __('Productos', 'alegra-connector'),
            'manage_woocommerce',
            'alegra-connector-products',
            [$this, 'render_products_page']
        );

        add_submenu_page(
            'alegra-connector',
            __('Clientes', 'alegra-connector'),
            __('Clientes', 'alegra-connector'),
            'manage_woocommerce',
            'alegra-connector-customers',
            [$this, 'render_customers_page']
        );

        add_submenu_page(
            'alegra-connector',
            __('Pedidos', 'alegra-connector'),
            __('Pedidos', 'alegra-connector'),
            'manage_woocommerce',
            'alegra-connector-orders',
            [$this, 'render_orders_page']
        );

        add_submenu_page(
            'alegra-connector',
            __('Mapeo de Campos', 'alegra-connector'),
            __('Mapeo', 'alegra-connector'),
            'manage_woocommerce',
            'alegra-connector-mapping',
            [$this, 'render_mapping_page']
        );

        add_submenu_page(
            'alegra-connector',
            __('Logs', 'alegra-connector'),
            __('Logs', 'alegra-connector'),
            'manage_woocommerce',
            'alegra-connector-logs',
            [$this, 'render_logs_page']
        );

        add_submenu_page(
            'alegra-connector',
            __('Webhooks', 'alegra-connector'),
            __('Webhooks', 'alegra-connector'),
            'manage_woocommerce',
            'alegra-connector-webhooks',
            [$this, 'render_webhooks_page']
        );

        add_submenu_page(
            'alegra-connector',
            __('Importar', 'alegra-connector'),
            __('Importar', 'alegra-connector'),
            'manage_woocommerce',
            'alegra-connector-import',
            [$this, 'render_import_page']
        );

        add_submenu_page(
            'alegra-connector',
            __('Configuración', 'alegra-connector'),
            __('Configuración', 'alegra-connector'),
            'manage_woocommerce',
            'alegra-connector-settings',
            [$this, 'render_settings_page']
        );

        add_submenu_page(
            'alegra-connector',
            __('Documentación', 'alegra-connector'),
            __('Documentación', 'alegra-connector'),
            'manage_woocommerce',
            'alegra-connector-docs',
            [$this, 'render_docs_page']
        );

        add_submenu_page(
            'alegra-connector',
            __('Monitor', 'alegra-connector'),
            __('Monitor', 'alegra-connector'),
            'manage_woocommerce',
            'alegra-connector-monitor',
            [$this, 'render_monitor_page']
        );

        add_submenu_page(
            'alegra-connector',
            __('Asistente', 'alegra-connector'),
            __('Asistente', 'alegra-connector'),
            'manage_woocommerce',
            'alegra-connector-wizard',
            [$this, 'render_wizard_page']
        );
    }

    /**
     * Sanitize a masked secret field. The value is never echoed back into the
     * settings form, so an empty submission means "keep the stored value"
     * (not "clear it"). A non-empty submission replaces it.
     */
    public static function sanitize_masked_secret(string $value, string $option): string
    {
        $value = sanitize_text_field($value);
        return $value === '' ? (string) get_option($option, '') : $value;
    }

    /**
     * Neutralise CSV formula injection (AC-67). Excel/Sheets treat a cell that
     * starts with =, +, -, @, TAB or CR as a formula; prefixing a single quote
     * forces it to be read as text.
     */
    public static function csv_safe_cell(mixed $value): string
    {
        $value = (string) $value;
        if ($value === '') {
            return $value;
        }
        return preg_match('/^[=+\-@\t\r]/', $value) === 1 ? "'" . $value : $value;
    }

    /**
     * Build the <select> options for the destination payment account.
     *
     * Guarantees the stored value is ALWAYS present and selected. When the
     * stored id is absent from the fetched list (a partial/failed
     * /bank-accounts call, a renamed or deleted account), a synthetic selected
     * option is injected so the browser can never fall back to the first option
     * ("Sin cuenta", value "0") and silently clobber the saved id.
     *
     * @param array<int,array<string,mixed>> $accounts Accounts from /bank-accounts.
     * @param string                         $stored   Current option value (e.g. '5').
     * @return array<int,array{value:string,label:string,selected:bool}>
     */
    public static function bank_account_select_options(array $accounts, string $stored): array
    {
        $stored = trim($stored);
        $none_selected = in_array($stored, ['', '0'], true);

        $options = [[
            'value'    => '0',
            'label'    => __('-- Sin cuenta (no se registraran pagos) --', 'alegra-connector'),
            'selected' => $none_selected,
        ]];

        $ids = [];
        foreach ($accounts as $account) {
            $id = (string) ($account['id'] ?? '');
            if ($id === '') {
                continue;
            }
            $ids[] = $id;
            $name = (string) ($account['name'] ?? 'Cuenta');
            $options[] = [
                'value'    => $id,
                'label'    => $name . ' (ID: ' . $id . ')',
                'selected' => ($stored === $id),
            ];
        }

        // The stored id did not come back in the list: keep it selectable.
        if (!$none_selected && !in_array($stored, $ids, true)) {
            $options[] = [
                'value'    => $stored,
                'label'    => sprintf(
                    __('Cuenta guardada (no sincronizada) — ID: %s', 'alegra-connector'),
                    $stored
                ),
                'selected' => true,
            ];
        }

        return $options;
    }

    /**
     * Sanitize an Alegra id option (numeric id or legacy UUID).
     *
     * Alegra migrated all IDs to UUID (VARCHAR(36)) on 2025-01-06; intval()
     * truncates a UUID to 0 on save, silently breaking config. This accepts a
     * UUID or a legacy numeric id and, on invalid input, preserves the previous
     * value AND registers a settings error, so the admin sees why the value was
     * not saved instead of a misleading "guardado correctamente" banner.
     */
    public static function sanitize_alegra_id($value, string $option_name): string
    {
        $value = trim((string) $value);
        if ($value === '') {
            return '';
        }

        $is_uuid = (bool) preg_match(
            '/^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/',
            $value
        );
        if ($is_uuid || ctype_digit($value)) {
            return $value;
        }

        add_settings_error(
            'alegra_connector_settings',
            $option_name . '_invalid',
            sprintf(
                __('El valor de %1$s ("%2$s") no es un ID válido; se conservó el valor anterior.', 'alegra-connector'),
                $option_name,
                $value
            ),
            'error'
        );

        return (string) get_option($option_name, '');
    }

    public function register_settings(): void
    {
        register_setting('alegra_connector_settings', 'alegra_connector_email', ['sanitize_callback' => 'sanitize_email']);
        // The token is masked in the UI (never echoed). An empty submission means
        // "keep the stored token", not "clear it" — otherwise re-saving any other
        // setting would wipe the credential.
        register_setting('alegra_connector_settings', 'alegra_connector_token', [
            'sanitize_callback' => fn($value) => self::sanitize_masked_secret((string) $value, 'alegra_connector_token'),
        ]);
        register_setting('alegra_connector_settings', 'alegra_connector_api_url', [
            'sanitize_callback' => function ($value) {
                $url = sanitize_url($value);
                return $url ?: 'https://api.alegra.com/api/v1';
            },
        ]);
        register_setting('alegra_connector_settings', 'alegra_connector_sync_frequency', ['sanitize_callback' => 'intval']);
        // `sync_method` selects the INBOUND (Alegra → WooCommerce) method only.
        // Allowlist it so garbage cannot silently disable the pull, and default
        // to the UI default ('cron', periodic) for installs with no stored value.
        register_setting('alegra_connector_settings', 'alegra_connector_sync_method', [
            'sanitize_callback' => function ($value) {
                $allowed = ['cron', 'both', 'real-time', 'disabled'];
                return in_array($value, $allowed, true) ? $value : 'cron';
            },
            'default' => 'cron',
        ]);
        // Outbound order uploads. Manual (false) is the default; only an explicit
        // opt-in enables automatic invoicing.
        register_setting('alegra_connector_settings', 'alegra_connector_push_orders_enabled', [
            'sanitize_callback' => 'rest_sanitize_boolean',
            'default' => false,
        ]);
        register_setting('alegra_connector_settings', 'alegra_connector_push_products_enabled', ['sanitize_callback' => 'rest_sanitize_boolean']);
        // D2 (T3.5): WC → Alegra stock push switch (owner=adjustment).
        register_setting('alegra_connector_settings', 'alegra_connector_push_inventory_enabled', [
            'sanitize_callback' => 'rest_sanitize_boolean',
            'default' => true,
        ]);
        // D2/FIX-3 (T3.5): with owner=invoice, a paid order opens its invoice so
        // Alegra moves stock natively. Inert unless push_orders_enabled=true.
        register_setting('alegra_connector_settings', 'alegra_connector_open_invoice_on_paid', [
            'sanitize_callback' => 'rest_sanitize_boolean',
            'default' => true,
        ]);
        // Independent customer toggle (REQ-CFG-4): enabling products must never
        // enable customers on its own.
        register_setting('alegra_connector_settings', 'alegra_connector_push_customers_enabled', [
            'sanitize_callback' => 'rest_sanitize_boolean',
            'default' => false,
        ]);
        // Payment sweep controls (REQ-CFG-1): registered so the Avanzado tab can
        // actually set them; read by Orders::reconcile_missing_payments().
        register_setting('alegra_connector_settings', 'alegra_connector_payment_reconcile_enabled', [
            'sanitize_callback' => 'rest_sanitize_boolean',
            'default' => true,
        ]);
        register_setting('alegra_connector_settings', 'alegra_connector_payment_reconcile_batch', [
            'sanitize_callback' => [self::class, 'sanitize_reconcile_batch'],
            'default' => 20,
        ]);
        register_setting('alegra_connector_settings', 'alegra_connector_currency', ['sanitize_callback' => 'sanitize_text_field']);
        register_setting('alegra_connector_settings', 'alegra_connector_log_retention_days', ['sanitize_callback' => 'intval']);
        register_setting('alegra_connector_settings', 'alegra_connector_conflict_resolution', ['sanitize_callback' => 'sanitize_text_field']);
        // Colombia contact fiscal fields. Allowlisted so a bad value can never
        // be POSTed to Alegra (which would 400 the contact create).
        register_setting('alegra_connector_settings', \Alegra\Connector\Billing_Fields::OPTION_KIND_OF_PERSON, [
            'sanitize_callback' => function ($value) {
                $value = strtoupper(sanitize_text_field((string) $value));
                return in_array($value, \Alegra\Connector\Billing_Fields::KIND_OF_PERSONS, true) ? $value : '';
            },
        ]);
        register_setting('alegra_connector_settings', \Alegra\Connector\Billing_Fields::OPTION_REGIME, [
            'sanitize_callback' => function ($value) {
                $value = strtoupper(sanitize_text_field((string) $value));
                return in_array($value, \Alegra\Connector\Billing_Fields::REGIMES, true) ? $value : 'SIMPLIFIED_REGIME';
            },
        ]);
        register_setting('alegra_connector_settings', 'alegra_connector_sync_products', ['sanitize_callback' => 'rest_sanitize_boolean']);
        register_setting('alegra_connector_settings', 'alegra_connector_sync_customers', ['sanitize_callback' => 'rest_sanitize_boolean']);
        register_setting('alegra_connector_settings', 'alegra_connector_sync_orders', ['sanitize_callback' => 'rest_sanitize_boolean']);
        register_setting('alegra_connector_settings', 'alegra_connector_sync_categories', ['sanitize_callback' => 'rest_sanitize_boolean']);
        register_setting('alegra_connector_settings', 'alegra_connector_inventory_source', ['sanitize_callback' => 'sanitize_text_field']);
        register_setting('alegra_connector_settings', 'alegra_connector_inventory_sync_enabled', ['sanitize_callback' => 'rest_sanitize_boolean']);
        // D3.4 (T2.5): opt-in legacy manage_stock=no migration. Default false.
        register_setting('alegra_connector_settings', 'alegra_connector_inventory_manage_stock_enabled', [
            'type'              => 'boolean',
            'sanitize_callback' => 'rest_sanitize_boolean',
            'default'           => false,
        ]);
        register_setting('alegra_connector_settings', 'alegra_connector_warehouse_id', [
            'sanitize_callback' => fn($v) => self::sanitize_alegra_id($v, 'alegra_connector_warehouse_id'),
        ]);
        register_setting('alegra_connector_settings', 'alegra_connector_warehouse_enabled', ['sanitize_callback' => 'rest_sanitize_boolean']);
        register_setting('alegra_connector_settings', 'alegra_connector_payment_account_id', [
            'sanitize_callback' => fn($v) => self::sanitize_alegra_id($v, 'alegra_connector_payment_account_id'),
            'default' => '',
        ]);
        register_setting('alegra_connector_settings', 'alegra_connector_payment_term_id', [
            'sanitize_callback' => fn($v) => self::sanitize_alegra_id($v, 'alegra_connector_payment_term_id'),
        ]);
        register_setting('alegra_connector_settings', 'alegra_connector_auto_complete_order', ['sanitize_callback' => 'rest_sanitize_boolean']);
        register_setting('alegra_connector_settings', 'alegra_connector_sync_images', ['sanitize_callback' => 'rest_sanitize_boolean']);
        register_setting('alegra_connector_settings', 'alegra_connector_sync_inactive_products', ['sanitize_callback' => 'rest_sanitize_boolean']);
        register_setting('alegra_connector_settings', 'alegra_connector_sync_images_mode', ['sanitize_callback' => 'sanitize_text_field']);
        // Same masking rule as the API token: empty submission keeps the stored secret.
        register_setting('alegra_connector_settings', 'alegra_connector_webhook_secret', [
            'sanitize_callback' => fn($value) => self::sanitize_masked_secret((string) $value, 'alegra_connector_webhook_secret'),
        ]);
        // Which webhook events the merchant wants. Allowlisted against the
        // documented enum so an unknown slug can never be subscribed. The
        // default is ALL events: registering nothing by default would silently
        // stop the real-time sync on an install that never opened the selector.
        register_setting('alegra_connector_settings', \Alegra\Connector\Webhooks\Receiver::EVENTS_OPTION, [
            'sanitize_callback' => [self::class, 'sanitize_webhook_selected_events'],
            'default' => API\Client::get_webhook_events(),
        ]);
        // NOTE: field_mapping / tax_mapping are registered ONLY in the
        // `alegra_connector_mapping` group below. Registering them in
        // `alegra_connector_settings` too made wp-admin/options.php null them
        // when the Settings page (which does not render them) was saved
        // (REQ-CFG-3).
        register_setting('alegra_connector_settings', 'alegra_connector_customer_resolution_mode', [
            'sanitize_callback' => function ($value) {
                $allowed = ['auto', 'always_generic', 'require_data'];
                return in_array($value, $allowed, true) ? $value : 'auto';
            },
            'default' => 'auto',
        ]);
        register_setting('alegra_connector_settings', 'alegra_connector_invoice_status', [
            'sanitize_callback' => function ($value) {
                $allowed = ['draft', 'open'];
                return in_array($value, $allowed, true) ? $value : 'draft';
            },
            'default' => 'draft',
        ]);
        register_setting('alegra_connector_settings', 'alegra_connector_dry_run', [
            'sanitize_callback' => 'rest_sanitize_boolean',
            'default' => false,
        ]);

        // Product push category strategy (read by Products::resolve_alegra_category_id()).
        register_setting('alegra_connector_settings', 'alegra_connector_push_category_strategy', [
            'sanitize_callback' => function ($value) {
                $allowed = ['first', 'deepest', 'specific'];
                return in_array($value, $allowed, true) ? $value : 'deepest';
            },
            'default' => 'deepest',
        ]);
        register_setting('alegra_connector_settings', 'alegra_connector_push_category_id', ['sanitize_callback' => 'intval']);
        // Parent term for categories imported from Alegra (read by Categories/Products).
        register_setting('alegra_connector_settings', 'alegra_connector_import_category_parent', ['sanitize_callback' => 'intval']);
        // WooCommerce fields to preserve when updating existing products from
        // Alegra. Read by Products::resolve_preserve_fields(); the Products
        // modal can override it per run.
        register_setting('alegra_connector_settings', 'alegra_connector_import_preserve_fields', [
            'sanitize_callback' => [self::class, 'sanitize_preserve_fields'],
            'default' => [],
        ]);
        // AC-19/AC-18 performance knobs. These were read with hardcoded defaults
        // but never written (dead config); register them so the Avanzado tab can
        // actually set them. Clamped so a bad value cannot break an import.
        register_setting('alegra_connector_settings', 'alegra_connector_import_time_budget', [
            'sanitize_callback' => fn($v) => max(30, min(600, (int) $v)),
            'default' => 240,
        ]);
        // T3.1.a: wall-clock budget for one chunked page ("Traer desde Alegra").
        // Distinct from the 240s import budget: the chunked page pauses and
        // resumes by start+offset instead of relying on set_time_limit.
        register_setting('alegra_connector_settings', 'alegra_connector_chunked_page_budget', [
            'sanitize_callback' => fn($v) => max(10, min(40, (int) $v)),
            'default' => 20,
        ]);
        register_setting('alegra_connector_settings', 'alegra_connector_import_max_pages', [
            'sanitize_callback' => fn($v) => max(0, (int) $v),
            'default' => 0,
        ]);
        // D7 §8.3: presupuesto global de una corrida del cron. Debe quedar por
        // debajo del TTL 600 del lock global (alegra_cron_global).
        register_setting('alegra_connector_settings', 'alegra_connector_cron_run_budget', [
            'sanitize_callback' => fn($v) => max(60, min(590, (int) $v)),
            'default' => 540,
        ]);
        // D5/T5.3a: extra image hosts the merchant allowlists by hand. Sanitized
        // (no wildcard/path/port) and merged with the built-in ['alegra.com'].
        register_setting('alegra_connector_settings', 'alegra_connector_allowed_image_hosts_extra', [
            'sanitize_callback' => [self::class, 'sanitize_image_hosts'],
            'default' => [],
        ]);
        // 2.5.1: image downloads are permissive by default (any public host over
        // http/https). Turning this on enforces `allowed_image_hosts()`.
        register_setting('alegra_connector_settings', 'alegra_connector_restrict_image_hosts', [
            'sanitize_callback' => 'rest_sanitize_boolean',
            'default' => false,
        ]);
        register_setting('alegra_connector_settings', 'alegra_connector_orders_poll_batch', [
            'sanitize_callback' => fn($v) => max(1, min(100, (int) $v)),
            'default' => 20,
        ]);
        // Manual Consumidor Final override (read by Consumidor_Final::peek_id()).
        register_setting('alegra_connector_settings', 'alegra_connector_consumidor_final_manual_override', [
            'sanitize_callback' => 'rest_sanitize_boolean',
            'default' => false,
        ]);
        register_setting('alegra_connector_settings', 'alegra_connector_consumidor_final_manual_id', [
            'sanitize_callback' => fn($v) => self::sanitize_alegra_id($v, 'alegra_connector_consumidor_final_manual_id'),
        ]);

        // Per-field billing toggles. Group A (identification) is force-enabled
        // here so the identification is always collected.
        register_setting('alegra_connector_settings', \Alegra\Connector\Billing_Fields::OPTION_ENABLED, [
            'sanitize_callback' => function ($value) {
                $enabled = [];
                if (is_array($value)) {
                    foreach ($value as $key => $on) {
                        if ($on && isset(\Alegra\Connector\Billing_Fields::CATALOG[$key])) {
                            $enabled[$key] = 1;
                        }
                    }
                }
                foreach (\Alegra\Connector\Billing_Fields::CATALOG as $key => $field) {
                    if (($field['group'] ?? '') === 'A') {
                        $enabled[$key] = 1;
                    }
                }
                return $enabled;
            },
            'default' => [],
        ]);

        // Seed the required (Group A) fields whenever the catalog is empty so
        // the identification is collected out of the box instead of silently
        // rendering no fields at checkout. Once saved, the sanitizer always
        // keeps Group A, so this only ever writes on an unconfigured install.
        $current_billing_fields = get_option(\Alegra\Connector\Billing_Fields::OPTION_ENABLED, []);
        if (!is_array($current_billing_fields) || empty($current_billing_fields)) {
            $seed = [];
            foreach (\Alegra\Connector\Billing_Fields::CATALOG as $key => $field) {
                if (($field['group'] ?? '') === 'A') {
                    $seed[$key] = 1;
                }
            }
            update_option(\Alegra\Connector\Billing_Fields::OPTION_ENABLED, $seed);
        }

        // Mapping settings group. The callbacks treat null / a non-array as
        // "no change" (keep the stored mapping) instead of wiping it, so any
        // option_page that includes the option without posting every field is
        // harmless (REQ-CFG-3, double defence).
        register_setting('alegra_connector_mapping', 'alegra_connector_field_mapping', [
            'sanitize_callback' => [self::class, 'sanitize_field_mapping'],
        ]);
        register_setting('alegra_connector_mapping', 'alegra_connector_tax_mapping', [
            'sanitize_callback' => [self::class, 'sanitize_tax_mapping'],
        ]);

        // The six settings sections were removed: the sections API is never
        // invoked and the templates render their own tables, so the sections
        // were pure dead code (REQ-HYG-2).
    }

    public function enqueue_assets(string $hook): void
    {
        if (strpos($hook, 'alegra-connector') === false) {
            return;
        }

        wp_enqueue_style('alegra-connector-admin', ALEGRA_CONNECTOR_URL . 'admin/assets/css/admin.css', [], ALEGRA_CONNECTOR_VERSION);
        wp_enqueue_script('alegra-connector-admin', ALEGRA_CONNECTOR_URL . 'admin/assets/js/admin.js', ['jquery'], ALEGRA_CONNECTOR_VERSION, true);

        // AC-55: Chart.js is vendored locally and enqueued ONLY on the
        // statistics page. It used to be a raw <script src> to cdn.jsdelivr.net
        // (third-party request from the admin, no SRI, no local fallback).
        if (strpos($hook, 'alegra-connector-stats') !== false) {
            wp_enqueue_script(
                'alegra-connector-chartjs',
                ALEGRA_CONNECTOR_URL . 'admin/assets/js/vendor/chart.min.js',
                [],
                ALEGRA_CONNECTOR_VERSION,
                true
            );
        }

        wp_localize_script('alegra-connector-admin', 'alegraConnector', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('alegra_connector_nonce'),
            'strings' => self::get_script_strings(),
        ]);

        // AC-35d: register the script translations so any .json catalogs
        // generated from the .pot are actually loaded for admin.js.
        wp_set_script_translations('alegra-connector-admin', 'alegra-connector', ALEGRA_CONNECTOR_PATH . 'languages');
    }

    /**
     * AC-35d: every user-facing JS string, localizable from one place.
     *
     * Strings that need interpolation use printf-style placeholders and are
     * rendered by the small format() helper in admin.js.
     *
     * @return array<string, string>
     */
    private static function get_script_strings(): array
    {
        return [
            // Generic
            'unknownError'          => __('Error desconocido', 'alegra-connector'),
            'error'                 => __('Error', 'alegra-connector'),
            'ok'                    => __('OK', 'alegra-connector'),
            'testing'               => __('Probando conexión...', 'alegra-connector'),
            'success'               => __('Conexión exitosa', 'alegra-connector'),
            'connectionError'       => __('Error de conexión', 'alegra-connector'),
            'syncing'               => __('Sincronizando...', 'alegra-connector'),
            'importing'             => __('Importando...', 'alegra-connector'),
            'networkErrorLabel'     => __('Error de red', 'alegra-connector'),

            // Connection
            'emailTokenRequired'    => __('Email y token son requeridos', 'alegra-connector'),
            'testConnection'        => __('Probar Conexión', 'alegra-connector'),
            'connectedTo'           => __('Conectado a %s', 'alegra-connector'),
            'connected'             => __('Conectado', 'alegra-connector'),
            'company'               => __('Empresa:', 'alegra-connector'),
            'country'               => __('País:', 'alegra-connector'),
            'endpoints'             => __('Endpoints:', 'alegra-connector'),
            'timeout'               => __('Timeout: el servidor de Alegra no responde', 'alegra-connector'),
            'networkError'          => __('Error de red (%s)', 'alegra-connector'),
            'checkUrl'              => __('Verifica la URL base y tu conexión.', 'alegra-connector'),

            // Sync
            'fetchingData'          => __('Trayendo datos...', 'alegra-connector'),
            'gettingCount'          => __('Obteniendo conteo de Alegra...', 'alegra-connector'),
            'elapsed'               => __('Tiempo: %1$dm %2$ds', 'alegra-connector'),
            'syncAll'               => __('Sincronizar Todo', 'alegra-connector'),
            'syncInventory'         => __('Sincronizar inventario', 'alegra-connector'),
            'syncCancelled'         => __('Sincronización cancelada', 'alegra-connector'),
            'completed'             => __('Completado', 'alegra-connector'),
            'retry'                 => __('Reintentar', 'alegra-connector'),
            'startError'            => __('Error al iniciar', 'alegra-connector'),
            'phase1Total'           => __('[Fase 1] Total: %1$s items en %2$s páginas — Página 1', 'alegra-connector'),
            'processing'            => __('Procesando...', 'alegra-connector'),
            'phase1'                => __('[Fase 1] %s', 'alegra-connector'),
            'importedLabel'         => __('importados', 'alegra-connector'),
            'updatedLabel'          => __('actualizados', 'alegra-connector'),
            'skippedLabel'          => __('omitidos', 'alegra-connector'),
            'errorsLabel'           => __('errores', 'alegra-connector'),
            'phase2CompletedErrors' => __('[Fase 2] Completado con errores', 'alegra-connector'),
            'phase2Completed'       => __('[Fase 2] Completado', 'alegra-connector'),
            'syncSummary'           => __('Total: %1$s items | %2$s nuevos, %3$s actualizados, %4$s omitidos', 'alegra-connector'),
            'syncSummaryErrors'     => __(', %s errores', 'alegra-connector'),
            'syncDoneErrors'        => __('Importación completada con errores: %1$s items procesados. %2$s importados, %3$s actualizados, %4$s errores. Revisa el log para más detalle.', 'alegra-connector'),
            'syncDone'              => __('%1$s items procesados. %2$s importados, %3$s actualizados.', 'alegra-connector'),
            'retrying'              => __('Reintentando (%1$s/%2$s)...', 'alegra-connector'),
            'selectOneType'         => __('Selecciona al menos un tipo', 'alegra-connector'),

            // Logs / token / connection management
            'confirmClearLogs'      => __('Esto borrará TODOS los logs, incluido el de hoy. No se puede deshacer. ¿Continuar?', 'alegra-connector'),
            'logsDeleted'           => __('Logs eliminados', 'alegra-connector'),
            'hideToken'             => __('Ocultar token', 'alegra-connector'),
            'showToken'             => __('Mostrar token', 'alegra-connector'),
            'hide'                  => __('Ocultar', 'alegra-connector'),
            'show'                  => __('Mostrar', 'alegra-connector'),
            'confirmDisconnect'     => __('¿Desconectar de Alegra? Deberás volver a probar la conexión.', 'alegra-connector'),
            'disconnecting'         => __('Desconectando...', 'alegra-connector'),
            'disconnect'            => __('Desconectar', 'alegra-connector'),
            'verifying'             => __('Verificando...', 'alegra-connector'),
            'verifyEndpoints'       => __('Verificar Endpoints', 'alegra-connector'),

            // Webhooks
            'registering'           => __('Registrando...', 'alegra-connector'),
            'webhookSecretRequired' => __('Debes configurar un Webhook Secret primero', 'alegra-connector'),
            'registerWebhooks'      => __('Registrar webhooks en Alegra', 'alegra-connector'),
            'webhooksRegistered'    => __('Webhooks registrados', 'alegra-connector'),
            'confirmDeleteWebhooks' => __('¿Eliminar todas las suscripciones de webhooks en Alegra?', 'alegra-connector'),
            'deleting'              => __('Eliminando...', 'alegra-connector'),
            'deleteWebhooks'        => __('Eliminar webhooks en Alegra', 'alegra-connector'),
            'webhooksDeleted'       => __('Webhooks eliminados', 'alegra-connector'),

            // Images / bulk / single sync
            'confirmCleanupImages'  => __('Esto eliminará todos los attachments de imagen duplicados en productos, basándose en la URL normalizada. Las imágenes que quedaron únicas se conservarán. ¿Continuar?', 'alegra-connector'),
            'cleaning'              => __('Limpiando...', 'alegra-connector'),
            'cleanupImages'         => __('Limpiar imágenes duplicadas', 'alegra-connector'),
            'imagesDeleted'         => __('Imágenes duplicadas eliminadas', 'alegra-connector'),
            'confirmRecordPayment'  => __('¿Registrar pago en Alegra?', 'alegra-connector'),
            'confirmOpenInvoice'    => __('¿Abrir esta factura en Alegra? Dejará de estar en borrador y quedará contabilizada.', 'alegra-connector'),
            'invoiceOpened'         => __('Factura abierta en Alegra', 'alegra-connector'),
            'confirmEmitCreditNote' => __('¿Emitir una nota de crédito en Alegra por el reembolso de este pedido?', 'alegra-connector'),
            'emittingCreditNote'    => __('Emitiendo...', 'alegra-connector'),
            'creditNoteEmitted'     => __('Nota de crédito emitida en Alegra', 'alegra-connector'),
            'selectOneItem'         => __('Selecciona al menos un elemento', 'alegra-connector'),
            'sending'               => __('Enviando...', 'alegra-connector'),
            'fetching'              => __('Trayendo...', 'alegra-connector'),
            'updatedSingle'         => __('Actualizado', 'alegra-connector'),
            'confirmImportFromApi'  => __('¿Traer %s desde Alegra? Esto puede crear o actualizar registros en WooCommerce.', 'alegra-connector'),
            'downloading'           => __('Descargando...', 'alegra-connector'),
            'importedSingle'        => __('Importado', 'alegra-connector'),
            'selectedOne'           => __('seleccionado', 'alegra-connector'),
            'selectedMany'          => __('seleccionados', 'alegra-connector'),

            // Pending invoices batch
            'countingPending'       => __('Contando pedidos pendientes...', 'alegra-connector'),
            'invoicePending'        => __('Facturar pendientes', 'alegra-connector'),
            'cancelled'             => __('Cancelado', 'alegra-connector'),
            'noPendingOrders'       => __('No hay pedidos pendientes por facturar', 'alegra-connector'),
            'invoicingPending'      => __('Facturando %s pedidos pendientes...', 'alegra-connector'),
            'invoicedLabel'         => __('facturados', 'alegra-connector'),
            'invoicesCreated'       => __('%1$s facturas creadas. %2$s errores.', 'alegra-connector'),

            // CSV import page
            'uploadImport'          => __('Subir e Importar', 'alegra-connector'),
            'selectCsv'             => __('Selecciona un archivo CSV', 'alegra-connector'),
            'importError'           => __('Error en la importación', 'alegra-connector'),
            'importCompleted'       => __('Importación completada', 'alegra-connector'),
            'importingType'         => __('Importando %s...', 'alegra-connector'),
            'confirmImportApi'      => __('¿Estás seguro de importar desde Alegra? %s?', 'alegra-connector'),

            // Dashboard kill-switch
            'confirmReactivate'     => __('¿Reactivar el plugin ahora?', 'alegra-connector'),
            'reactivating'          => __('Reactivando...', 'alegra-connector'),
            'reactivateNow'         => __('Reactivar ahora', 'alegra-connector'),

            // Monitor page
            'statusRunning'         => __('Corriendo', 'alegra-connector'),
            'statusCompleted'       => __('Completado', 'alegra-connector'),
            'statusFailed'          => __('Fallido', 'alegra-connector'),
            'statusCancelled'       => __('Cancelado', 'alegra-connector'),
            'statusKilled'          => __('Detenido', 'alegra-connector'),
            'noActiveProcesses'     => __('No hay procesos activos.', 'alegra-connector'),
            'noCronTasks'           => __('No hay tareas cron programadas.', 'alegra-connector'),
            'noRecentHistory'       => __('Sin historial reciente.', 'alegra-connector'),
            'thHook'                => __('Hook', 'alegra-connector'),
            'thNextRun'             => __('Próxima ejecución', 'alegra-connector'),
            'thFrequency'           => __('Frecuencia', 'alegra-connector'),
            'thActions'             => __('Acciones', 'alegra-connector'),
            'thType'                => __('Tipo', 'alegra-connector'),
            'thStatus'              => __('Estado', 'alegra-connector'),
            'thStart'               => __('Inicio', 'alegra-connector'),
            'thEnd'                 => __('Fin', 'alegra-connector'),
            'thItems'               => __('Items', 'alegra-connector'),
            'thMemory'              => __('Mem.', 'alegra-connector'),
            'thError'               => __('Error', 'alegra-connector'),
            'run'                   => __('Ejecutar', 'alegra-connector'),
            'runNow'                => __('Ejecutar ahora', 'alegra-connector'),
            'skipNext'              => __('Saltar la próxima ejecución', 'alegra-connector'),
            'removeAll'             => __('Eliminar todas las programaciones', 'alegra-connector'),
            'memory'                => __('Memoria', 'alegra-connector'),
            'stopProcess'           => __('Detener este proceso', 'alegra-connector'),
            'confirmStopProcess'    => __('¿Estás seguro de detener este proceso?', 'alegra-connector'),
            'confirmEmergencyStop'  => __('Esto detendrá TODOS los procesos del plugin y lo desconectará. ¿Continuar?', 'alegra-connector'),
            'stopping'              => __('Deteniendo...', 'alegra-connector'),
            'stopAll'               => __('Detener Todos los Procesos', 'alegra-connector'),
            'confirmSkipCron'       => __('¿Saltar la próxima ejecución de esta tarea cron?', 'alegra-connector'),
            'confirmRemoveCron'     => __('¿Eliminar TODAS las programaciones de esta tarea cron?', 'alegra-connector'),
            'taskSkipped'           => __('Tarea saltada', 'alegra-connector'),
            'taskRemoved'           => __('Tarea eliminada', 'alegra-connector'),
            'hookExecuted'          => __('Hook ejecutado', 'alegra-connector'),
            // T6.4.a (dueño único): estado abandonado + origen de cada run.
            'statusAbandoned'       => __('Abandonado', 'alegra-connector'),
            'originCron'            => __('Cron', 'alegra-connector'),
            'originManual'          => __('Manual', 'alegra-connector'),
            'originChunked'         => __('Chunked', 'alegra-connector'),
            'originWebhook'         => __('Webhook', 'alegra-connector'),
            // T6.4.b (dueño único): error del poll + cron deshabilitado.
            'monitorError'          => __('No se pudo cargar el monitor. Reintentando...', 'alegra-connector'),
            'cronDisabled'          => __('La sincronización periódica está desactivada (método: %s).', 'alegra-connector'),

            // Wizard
            'wizardError'           => __('Error al guardar progreso', 'alegra-connector'),
            'confirmSkipWizard'     => __('¿Saltar el asistente? Puedes volver a iniciarlo desde Dashboard.', 'alegra-connector'),

            // Statistics charts
            'chartSales'            => __('Ventas', 'alegra-connector'),
            'chartOrders'           => __('Pedidos', 'alegra-connector'),
            'chartCompleted'        => __('Completado', 'alegra-connector'),
            'chartProcessing'       => __('Procesando', 'alegra-connector'),
            'chartPending'          => __('Pendiente', 'alegra-connector'),
            'chartCancelled'        => __('Cancelado', 'alegra-connector'),
            'chartRefunded'         => __('Reembolsado', 'alegra-connector'),

            // Product import filters (modal in the Products page). Only the
            // strings consumed by admin.js live here; the modal labels are
            // rendered server-side in templates/admin-products.php.
            'importFilterLoading'   => __('Cargando categorías...', 'alegra-connector'),
            'importFilterNoCats'    => __('No se encontraron categorías en Alegra.', 'alegra-connector'),
            'importFilterCatError'  => __('No se pudieron cargar las categorías.', 'alegra-connector'),

            // Chunked import (T3.3.e). Fase 3 es dueña de estas claves; las
            // compartidas (imagesFailed/monitorError/statusAbandoned) las declara
            // su fase dueña (T5.2b/T6.4b/T6.4a) y acá sólo se consumen.
            'pausedResuming'        => __('Pausado por tiempo; continúa con la próxima página...', 'alegra-connector'),
            'resumingFrom'          => __('Reanudando desde el ítem %s...', 'alegra-connector'),
            'confirmReimport'       => __('Esto reimporta TODO el catálogo desde cero y limpia el punto de reanudación. ¿Continuar?', 'alegra-connector'),
            'startingFromZero'      => __('Empezando de cero...', 'alegra-connector'),
            'confirmRecreateManual' => __('¿Recrear también los productos que borraste a mano?', 'alegra-connector'),
            // T5.2b (dueño único): desglose de fallos de imagen en el resumen.
            'imagesFailed'          => __('%1$s imágenes no se pudieron importar (%2$s host no permitido, %3$s fallo de descarga, %4$s fallo al adjuntar, %5$s diferidas).', 'alegra-connector'),

            // D1 / REQ-CF-03: Consumidor Final (verificar/crear). Dueño único: T6.2.
            'cfVerifying'           => __('Verificando...', 'alegra-connector'),
            'cfVerifyOk'            => __('Consumidor Final disponible.', 'alegra-connector'),
            'cfVerifyNotFound'      => __('No se encontró el Consumidor Final en Alegra. Podés crearlo.', 'alegra-connector'),
            'cfVerifyError'         => __('No se pudo verificar el Consumidor Final.', 'alegra-connector'),
            'cfCreateOk'            => __('Consumidor Final creado.', 'alegra-connector'),
        ];
    }

    /**
     * REQ-INV-07: ventas sin factura vinculada. Sólo lectura.
     *
     * @return array{count:int, orders:array<int,array{id:int,status:string,total:float,date:string}>}
     */
    public function get_unjournaled_sales(int $limit = 20): array
    {
        $ids = wc_get_orders([
            'status'     => ['processing', 'completed'],
            'limit'      => $limit,
            'return'     => 'ids',
            'orderby'    => 'date',
            'order'      => 'DESC',
            'meta_query' => [[ 'key' => '_alegra_invoice_id', 'compare' => 'NOT EXISTS' ]],
        ]);
        $orders = [];
        foreach ($ids as $id) {
            $order = wc_get_order($id);
            if (!$order) {
                continue;
            }
            $created = $order->get_date_created();
            $orders[] = [
                'id'     => (int) $id,
                'status' => (string) $order->get_status(),
                'total'  => (float) $order->get_total(),
                'date'   => $created instanceof \DateTimeInterface ? $created->format('Y-m-d H:i:s') : '',
            ];
        }
        return ['count' => count($orders), 'orders' => $orders];
    }

    public function render_dashboard(): void
    {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('No tienes permisos para acceder a esta página.', 'alegra-connector'));
        }

        $is_connected = (bool) get_option('alegra_connector_connection_tested');
        $company_name = esc_html(get_option('alegra_connector_company_name', ''));
        $last_sync = get_transient('alegra_connector_last_sync');
        $stats = $this->get_sync_stats();
        $header_color = 'indigo';

        // REQ-INV-07: honest visibility. With owner=adjustment the sales ARE
        // reflected via adjustments; only the manual-invoice mode can diverge.
        $divergence = (!get_option('alegra_connector_push_orders_enabled', false))
            ? $this->get_unjournaled_sales()
            : ['count' => 0, 'orders' => []];

        include ALEGRA_CONNECTOR_PATH . 'templates/admin-dashboard.php';
    }

    public function render_settings_page(): void
    {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('No tienes permisos para acceder a esta página.', 'alegra-connector'));
        }

        $connected = (bool) get_option('alegra_connector_connection_tested');
        $alegra_currencies = [];
        $alegra_warehouses = [];
        $alegra_bank_accounts = [];
        $alegra_terms = [];

        if ($connected && $this->api) {
            $cr = $this->api->get_currencies();
            if (!is_wp_error($cr)) $alegra_currencies = $cr;
            $wr = $this->api->get_warehouses();
            if (!is_wp_error($wr)) $alegra_warehouses = $wr;
            $ba = $this->api->get_bank_accounts();
            if (!is_wp_error($ba)) $alegra_bank_accounts = $ba;
            $tm = $this->api->get_terms();
            if (!is_wp_error($tm)) $alegra_terms = $tm;
        }

        include ALEGRA_CONNECTOR_PATH . 'templates/admin-settings.php';
    }

    public function render_docs_page(): void
    {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('No tienes permisos.', 'alegra-connector'));
        }

        $doc_file = ALEGRA_CONNECTOR_PATH . 'docs/DOCUMENTACION.md';
        $content = '';
        if (file_exists($doc_file)) {
            $content = file_get_contents($doc_file);
        }

        $header_color = 'indigo';
        include ALEGRA_CONNECTOR_PATH . 'templates/admin-docs.php';
    }

    public function render_monitor_page(): void
    {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('No tienes permisos.', 'alegra-connector'));
        }
        include ALEGRA_CONNECTOR_PATH . 'templates/admin-monitor.php';
    }

    /**
     * Redirect the wizard page before any output when it is no longer needed.
     *
     * The template used to call wp_safe_redirect() from inside the page
     * callback, which runs AFTER wp-admin/admin-header.php has already sent the
     * document — producing "headers already sent" and a broken redirect. Doing
     * it on admin_init (before output) fixes both.
     */
    public function maybe_redirect_wizard(): void
    {
        $page = isset($_GET['page']) ? sanitize_key(wp_unslash((string) $_GET['page'])) : '';
        if ($page !== 'alegra-connector-wizard') {
            return;
        }
        if (!current_user_can('manage_woocommerce')) {
            return;
        }

        $wizard_done = (bool) get_user_meta(get_current_user_id(), 'alegra_wizard_done', true);
        $is_connected = (bool) get_option('alegra_connector_connection_tested');
        if ($wizard_done || $is_connected) {
            wp_safe_redirect(admin_url('admin.php?page=alegra-connector'));
            exit;
        }
    }

    public function render_wizard_page(): void
    {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('No tienes permisos.', 'alegra-connector'));
        }
        include ALEGRA_CONNECTOR_PATH . 'templates/admin-wizard.php';
    }

    public function render_logs_page(): void
    {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('No tienes permisos para acceder a esta página.', 'alegra-connector'));
        }

        $log_files = $this->logger ? $this->logger->get_log_files() : [];
        $log_entries = $this->logger ? $this->logger->get_logs(200) : [];
        $system_logs = $this->logger ? $this->logger->get_system_logs(50) : [];
        // REQ-LOG-05: absolute real path, always rendered (even with no files).
        $logger_dir = $this->logger ? $this->logger->get_log_dir() : '';

        // Log Statistics
        $log_stats = ['total' => 0, 'info' => 0, 'warning' => 0, 'error' => 0, 'critical' => 0, 'today' => 0, 'system' => count($system_logs)];
        foreach ($log_entries as $entry) {
            $log_stats['total']++;
            $lv = strtolower($entry['level'] ?? '');
            if (isset($log_stats[$lv])) $log_stats[$lv]++;
            if (strpos($entry['timestamp'] ?? '', date('Y-m-d')) === 0) $log_stats['today']++;
        }

        $header_color = 'purple';

        include ALEGRA_CONNECTOR_PATH . 'templates/admin-logs.php';
    }

    /**
     * Admin screen for the webhook deliveries recorded by the receiver.
     *
     * Read-only except for the nonce-protected "Limpiar" action below. It
     * answers, from the raw payloads, whether Alegra emits `edit-item` — and
     * whether that payload carries `inventory.availableQuantity` — when stock
     * changes. ALL inspection logic lives in the Recorder, so this screen and
     * the CLI inspector can never drift.
     */
    public function render_webhooks_page(): void
    {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('No tienes permisos para acceder a esta página.', 'alegra-connector'));
        }

        $recorder = \Alegra\Connector\Webhooks\Recorder::class;
        $all = $recorder::all();

        // Subject filter (GET only). Unknown values simply match nothing.
        $selected_subject = isset($_GET['subject'])
            ? sanitize_text_field(wp_unslash((string) $_GET['subject']))
            : '';

        $entries = [];
        foreach ($all as $entry) {
            if ($selected_subject !== '' && (string) ($entry['subject'] ?? '') !== $selected_subject) {
                continue;
            }
            $entries[] = $entry;
        }
        $entries = array_reverse($entries); // newest first

        $subjects = [];
        foreach ($all as $entry) {
            $subject = (string) ($entry['subject'] ?? '');
            if ($subject !== '') {
                $subjects[$subject] = true;
            }
        }
        $subjects = array_keys($subjects);
        sort($subjects);

        // The verdict is always GLOBAL (every retained delivery), so a table
        // filter can never hide the answer to the inventory question.
        $verdict = $recorder::inventory_verdict($all);
        $edit_items = [];
        foreach ($all as $entry) {
            if ((string) ($entry['subject'] ?? '') === 'edit-item') {
                $edit_items[] = $entry;
            }
        }

        $total = count($all);
        $shown = count($entries);
        $retention = $recorder::MAX_ENTRIES;
        $cleared = isset($_GET['cleared']);
        $header_color = 'indigo';

        include ALEGRA_CONNECTOR_PATH . 'templates/admin-webhooks.php';
    }

    /**
     * Nonce- and capability-gated "Limpiar" action for the webhook buffer.
     */
    public function handle_clear_webhooks(): void
    {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('No tienes permisos para acceder a esta página.', 'alegra-connector'));
        }

        check_admin_referer('alegra_clear_webhooks');

        \Alegra\Connector\Webhooks\Recorder::clear();

        wp_safe_redirect(add_query_arg(
            ['page' => 'alegra-connector-webhooks', 'cleared' => '1'],
            admin_url('admin.php')
        ));
        exit;
    }

    public function render_import_page(): void
    {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('No tienes permisos para acceder a esta página.', 'alegra-connector'));
        }

        $header_color = 'green';

        include ALEGRA_CONNECTOR_PATH . 'templates/admin-import.php';
    }

    public function render_mapping_page(): void
    {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('No tienes permisos para acceder a esta página.', 'alegra-connector'));
        }

        $field_mapping = get_option('alegra_connector_field_mapping', []);
        $tax_mapping = get_option('alegra_connector_tax_mapping', []);
        $connected = (bool) get_option('alegra_connector_connection_tested');

        $alegra_taxes = [];
        $alegra_price_lists = [];
        $alegra_categories = [];

        if ($connected && $this->api) {
            $t = $this->api->get_taxes();
            if (!is_wp_error($t)) { $alegra_taxes = $t; }
            $p = $this->api->get_price_lists();
            if (!is_wp_error($p)) { $alegra_price_lists = $p; }
            $c = $this->api->get_item_categories();
            if (!is_wp_error($c)) { $alegra_categories = $c; }
        }

        $header_color = 'indigo';

        include ALEGRA_CONNECTOR_PATH . 'templates/admin-mapping.php';
    }

    public function render_statistics_page(): void
    {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('No tienes permisos.', 'alegra-connector'));
        }

        // Default period: last 30 days
        $end = isset($_GET['end']) ? sanitize_text_field($_GET['end']) : date('Y-m-d');
        $start = isset($_GET['start']) ? sanitize_text_field($_GET['start']) : date('Y-m-d', strtotime('-30 days'));
        $period = isset($_GET['period']) ? sanitize_text_field($_GET['period']) : '30d';

        $stats = $this->get_statistics_data($start, $end, $period);
        extract($stats);
        $header_color = 'blue';

        include ALEGRA_CONNECTOR_PATH . 'templates/admin-statistics.php';
    }

    private function get_statistics_data(string $start, string $end, string $period = '30d'): array
    {
        global $wpdb;
        $currency_symbol = function_exists('get_woocommerce_currency_symbol') ? get_woocommerce_currency_symbol() : '$';

        $revenue = ['completed' => 0, 'processing' => 0, 'pending' => 0, 'cancelled' => 0, 'refunded' => 0, 'total' => 0];
        $order_counts = ['completed' => 0, 'processing' => 0, 'pending' => 0, 'cancelled' => 0, 'refunded' => 0, 'total' => 0];
        $payment_methods = [];
        $daily_sales = [];
        $top_products = [];
        $recent_orders = [];

        $orders_table = HPOS::get_orders_table();
        $meta_table = HPOS::get_order_meta_table();

        // AC-58: aggregate revenue/counts in SQL. The old code materialised up
        // to 5,000 order rows into PHP just to sum them, and silently
        // under-reported on a larger store.
        $range = [$start, $end . ' 23:59:59'];
        if (HPOS::is_enabled()) {
            $status_expr = "REPLACE(o.status,'wc-','')";
            $date_expr = 'o.date_created_gmt';
            $from = "{$orders_table} o LEFT JOIN {$meta_table} om ON o.id=om.order_id AND om.meta_key='_order_total'";
            $where = "o.type='shop_order' AND o.date_created_gmt >= %s AND o.date_created_gmt <= %s";

            $status_rows = $wpdb->get_results($wpdb->prepare(
                "SELECT {$status_expr} AS status, COUNT(*) AS cnt, COALESCE(SUM(om.meta_value),0) AS total
                 FROM {$from} WHERE {$where} GROUP BY status",
                ...$range
            ));
            $daily_rows = $wpdb->get_results($wpdb->prepare(
                "SELECT DATE({$date_expr}) AS d, COUNT(*) AS cnt, COALESCE(SUM(om.meta_value),0) AS total
                 FROM {$from} WHERE {$where} GROUP BY d",
                ...$range
            ));
            $recent_ids = $wpdb->get_col($wpdb->prepare(
                "SELECT o.id FROM {$orders_table} o WHERE o.type='shop_order'
                 AND o.date_created_gmt >= %s AND o.date_created_gmt <= %s
                 ORDER BY o.date_created_gmt DESC LIMIT 5",
                ...$range
            ));
        } else {
            $status_expr = "REPLACE(p.post_status,'wc-','')";
            $from = "{$wpdb->posts} p LEFT JOIN {$wpdb->postmeta} om ON p.ID=om.post_id AND om.meta_key='_order_total'";
            $where = "p.post_type='shop_order' AND p.post_date >= %s AND p.post_date <= %s";

            $status_rows = $wpdb->get_results($wpdb->prepare(
                "SELECT {$status_expr} AS status, COUNT(*) AS cnt, COALESCE(SUM(om.meta_value),0) AS total
                 FROM {$from} WHERE {$where} GROUP BY status",
                ...$range
            ));
            $daily_rows = $wpdb->get_results($wpdb->prepare(
                "SELECT DATE(p.post_date) AS d, COUNT(*) AS cnt, COALESCE(SUM(om.meta_value),0) AS total
                 FROM {$from} WHERE {$where} GROUP BY d",
                ...$range
            ));
            $recent_ids = $wpdb->get_col($wpdb->prepare(
                "SELECT p.ID FROM {$wpdb->posts} p WHERE p.post_type='shop_order'
                 AND p.post_date >= %s AND p.post_date <= %s
                 ORDER BY p.post_date DESC LIMIT 5",
                ...$range
            ));
        }

        foreach ((array) $status_rows as $row) {
            $status = (string) ($row->status ?? '');
            $total = (float) ($row->total ?? 0);
            $count = (int) ($row->cnt ?? 0);

            $revenue['total'] += $total;
            $order_counts['total'] += $count;

            if (array_key_exists($status, $revenue)) {
                $revenue[$status] += $total;
                $order_counts[$status] += $count;
            }
        }

        foreach ((array) $daily_rows as $row) {
            $date = substr((string) ($row->d ?? ''), 0, 10);
            if ($date !== '') {
                $daily_sales[$date] = ['count' => (int) $row->cnt, 'total' => (float) $row->total];
            }
        }

        // Load recent 5 orders fully for display
        foreach ((array) $recent_ids as $oid) {
            $order = wc_get_order($oid);
            if (!$order) continue;
            $recent_orders[] = [
                'id' => $oid,
                'date' => $order->get_date_created() ? $order->get_date_created()->date('Y-m-d') : '',
                'customer' => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
                'total' => (float) $order->get_total(),
                'status' => $order->get_status(),
            ];
        }

        // Top products via SQL aggregation (orders within period)
        if (HPOS::is_enabled()) {
            $top_rows = $wpdb->get_results($wpdb->prepare(
                "SELECT oi.order_item_name, SUM(oi_meta.meta_value) as total_qty, SUM(oim_total.meta_value) as total_rev, COUNT(DISTINCT oi.order_id) as order_count
                 FROM {$wpdb->prefix}woocommerce_order_items oi
                 INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta oi_meta ON oi.order_item_id=oi_meta.order_item_id AND oi_meta.meta_key='_qty'
                 INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta oim_total ON oi.order_item_id=oim_total.order_item_id AND oim_total.meta_key='_line_total'
                 INNER JOIN {$orders_table} o ON oi.order_id=o.id AND o.type='shop_order'
                 WHERE o.date_created_gmt >= %s AND o.date_created_gmt <= %s AND oi.order_item_type='line_item'
                 GROUP BY oi.order_item_name
                 ORDER BY total_qty DESC
                 LIMIT 10",
                $start, $end . ' 23:59:59'
            ));
        } else {
            $top_rows = $wpdb->get_results($wpdb->prepare(
                "SELECT oi.order_item_name, SUM(oi_meta.meta_value) as total_qty, SUM(oim_total.meta_value) as total_rev, COUNT(DISTINCT oi.order_id) as order_count
                 FROM {$wpdb->prefix}woocommerce_order_items oi
                 INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta oi_meta ON oi.order_item_id=oi_meta.order_item_id AND oi_meta.meta_key='_qty'
                 INNER JOIN {$wpdb->prefix}woocommerce_order_itemmeta oim_total ON oi.order_item_id=oim_total.order_item_id AND oim_total.meta_key='_line_total'
                 INNER JOIN {$wpdb->posts} p ON oi.order_id=p.ID AND p.post_type='shop_order'
                 WHERE p.post_date >= %s AND p.post_date <= %s AND oi.order_item_type='line_item'
                 GROUP BY oi.order_item_name
                 ORDER BY total_qty DESC
                 LIMIT 10",
                $start, $end . ' 23:59:59'
            ));
        }

        if (is_array($top_rows)) {
            foreach ($top_rows as $tr) {
                $top_products[$tr->order_item_name] = [
                    'qty' => (int) $tr->total_qty,
                    'total' => (float) $tr->total_rev,
                    'orders' => (int) $tr->order_count,
                ];
            }
        }

        // Payment methods via SQL
        if (HPOS::is_enabled()) {
            $pm_rows = $wpdb->get_results($wpdb->prepare(
                "SELECT pm.meta_value as method, COUNT(*) as cnt, SUM(pm_total.meta_value) as total
                 FROM {$orders_table} o
                 INNER JOIN {$meta_table} pm ON o.id=pm.order_id AND pm.meta_key='_payment_method_title'
                 LEFT JOIN {$meta_table} pm_total ON o.id=pm_total.order_id AND pm_total.meta_key='_order_total'
                 WHERE o.type='shop_order' AND o.date_created_gmt >= %s AND o.date_created_gmt <= %s
                 GROUP BY pm.meta_value",
                $start, $end . ' 23:59:59'
            ));
        } else {
            $pm_rows = $wpdb->get_results($wpdb->prepare(
                "SELECT pm.meta_value as method, COUNT(*) as cnt, SUM(pm_total.meta_value) as total
                 FROM {$wpdb->posts} p
                 INNER JOIN {$wpdb->postmeta} pm ON p.ID=pm.post_id AND pm.meta_key='_payment_method_title'
                 LEFT JOIN {$wpdb->postmeta} pm_total ON p.ID=pm_total.post_id AND pm_total.meta_key='_order_total'
                 WHERE p.post_type='shop_order' AND p.post_date >= %s AND p.post_date <= %s
                 GROUP BY pm.meta_value",
                $start, $end . ' 23:59:59'
            ));
        }

        if (is_array($pm_rows)) {
            foreach ($pm_rows as $pmr) {
                $label = $pmr->method ?: 'Unknown';
                $payment_methods[$label] = ['count' => (int) $pmr->cnt, 'total' => (float) $pmr->total];
            }
        }

        // Previous period revenue (SQL)
        $interval = strtotime($end) - strtotime($start) + 86400;
        $prev_start = date('Y-m-d', strtotime($start) - $interval);
        $prev_end = date('Y-m-d', strtotime($start) - 86400);

        if (HPOS::is_enabled()) {
            $prev_revenue = (float) $wpdb->get_var($wpdb->prepare(
                "SELECT COALESCE(SUM(pm.meta_value), 0) FROM {$orders_table} o
                 INNER JOIN {$meta_table} pm ON o.id=pm.order_id AND pm.meta_key='_order_total'
                 WHERE o.type='shop_order' AND o.date_created_gmt >= %s AND o.date_created_gmt <= %s",
                $prev_start, $prev_end . ' 23:59:59'
            ));
        } else {
            $prev_revenue = (float) $wpdb->get_var($wpdb->prepare(
                "SELECT COALESCE(SUM(pm.meta_value), 0) FROM {$wpdb->posts} p
                 INNER JOIN {$wpdb->postmeta} pm ON p.ID=pm.post_id AND pm.meta_key='_order_total'
                 WHERE p.post_type='shop_order' AND p.post_date >= %s AND p.post_date <= %s",
                $prev_start, $prev_end . ' 23:59:59'
            ));
        }

        $growth = 0;
        if ($prev_revenue > 0 && $revenue['total'] > 0) {
            $growth = round((($revenue['total'] - $prev_revenue) / $prev_revenue) * 100, 1);
        }

        $abandoned_count = $order_counts['pending'] + $order_counts['cancelled'];
        $abandoned_value = $revenue['pending'] + $revenue['cancelled'];
        $abandoned_rate = $order_counts['total'] > 0 ? round(($abandoned_count / $order_counts['total']) * 100, 1) : 0;
        $conversion_rate = $order_counts['total'] > 0 ? round(($order_counts['completed'] / $order_counts['total']) * 100, 1) : 0;
        $avg_order = $order_counts['completed'] > 0 ? $revenue['completed'] / $order_counts['completed'] : 0;

        ksort($daily_sales);

        // Customers (SQL, accurate)
        $total_customers = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->users} u
             INNER JOIN {$wpdb->usermeta} um ON u.ID=um.user_id AND um.meta_key='{$wpdb->prefix}capabilities'
             WHERE um.meta_value LIKE '%\"customer\"%'"
        );
        $new_customers = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->users} WHERE user_registered >= %s AND user_registered <= %s",
            $start, $end . ' 23:59:59'
        ));

        // Sync stats (SQL, accurate and unlimited)
        $orders_total = HPOS::is_enabled()
            ? (int) $wpdb->get_var("SELECT COUNT(*) FROM {$orders_table} WHERE type='shop_order'")
            : (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type='shop_order'");

        $sync_stats = [
            'products_synced' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key='_alegra_item_id'"),
            'products_total' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type='product' AND post_status='publish'"),
            'orders_synced' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$meta_table} WHERE meta_key='_alegra_invoice_id'"),
            'orders_total' => $orders_total,
            'customers_synced' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key='alegra_contact_id' AND meta_value != ''"),
            'customers_total' => $total_customers,
        ];

        return compact(
            'revenue', 'order_counts', 'payment_methods', 'daily_sales',
            'top_products', 'sync_stats', 'new_customers', 'start', 'end', 'period',
            'currency_symbol', 'growth', 'prev_revenue', 'abandoned_count', 'abandoned_value',
            'abandoned_rate', 'conversion_rate', 'avg_order', 'recent_orders'
        );
    }

    public function render_products_page(): void
    {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('No tienes permisos.', 'alegra-connector'));
        }

        $page = isset($_GET['paged']) ? max(1, (int) $_GET['paged']) : 1;
        $per_page = 20;

        // Check for single product detail view
        $product_id = isset($_GET['product_id']) ? (int) $_GET['product_id'] : 0;
        if ($product_id > 0) {
            $this->render_product_detail($product_id);
            return;
        }

        global $wpdb;

        // Read filter and search params
        $filter = isset($_GET['filter']) ? sanitize_text_field($_GET['filter']) : 'all';
        $search = isset($_GET['search']) ? sanitize_text_field($_GET['search']) : '';
        $post_type_filter = isset($_GET['post_type_filter']) ? sanitize_text_field($_GET['post_type_filter']) : 'all';

        // Build WHERE clauses for search and filter
        $where_filter = '';
        $post_type_clause = '';
        $show_variations = false;

        // AC-58: EXISTS instead of a scalar correlated subquery. The old
        // COUNT ran a 3-join subquery once per product row just to paginate.
        if ($post_type_filter === 'variable') {
            $post_type_clause = "AND p.post_type='product' AND EXISTS (
                SELECT 1 FROM {$wpdb->term_relationships} tr
                INNER JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id=tt.term_taxonomy_id
                INNER JOIN {$wpdb->terms} t ON tt.term_id=t.term_id
                WHERE tr.object_id=p.ID AND tt.taxonomy='product_type' AND t.slug='variable')";
        } elseif ($post_type_filter === 'simple') {
            $post_type_clause = "AND p.post_type='product' AND NOT EXISTS (
                SELECT 1 FROM {$wpdb->term_relationships} tr
                INNER JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id=tt.term_taxonomy_id
                INNER JOIN {$wpdb->terms} t ON tt.term_id=t.term_id
                WHERE tr.object_id=p.ID AND tt.taxonomy='product_type' AND t.slug='variable')";
        } elseif ($post_type_filter === 'variations') {
            $post_type_clause = "AND p.post_type='product_variation'";
            $show_variations = true;
        } else {
            $post_type_clause = "AND p.post_type='product'";
        }

        if ($filter === 'synced') {
            $where_filter = "AND p.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key='_alegra_item_id')";
        } elseif ($filter === 'pending') {
            $where_filter = "AND p.ID NOT IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key='_alegra_item_id')";
        }

        $where_search = '';
        if (!empty($search)) {
            $like = '%' . $wpdb->esc_like($search) . '%';
            if ($show_variations) {
                $where_search = $wpdb->prepare(
                    "AND (p.post_title LIKE %s OR p.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key='_sku' AND meta_value LIKE %s) OR p.post_parent IN (SELECT ID FROM {$wpdb->posts} WHERE post_title LIKE %s))",
                    $like, $like, $like
                );
            } else {
                $where_search = $wpdb->prepare(
                    "AND (p.post_title LIKE %s OR p.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key='_sku' AND meta_value LIKE %s))",
                    $like, $like
                );
            }
        }

        // Direct SQL for reliable count with filters
        $total = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->posts} p WHERE 1=1 {$post_type_clause} AND p.post_status='publish' {$where_filter} {$where_search}"
        );
        $total_pages = (int) ceil($total / $per_page);
        $offset = ($page - 1) * $per_page;

        // Get products with all needed data in a single query (avoids 20+ wc_get_product calls)
        // Use DISTINCT to avoid duplicate rows from multiple postmeta entries
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT DISTINCT p.ID, p.post_title, p.post_status, p.post_parent,
                    (SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id=p.ID AND meta_key='_sku' LIMIT 1) as sku,
                    (SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id=p.ID AND meta_key='_price' LIMIT 1) as price,
                    (SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id=p.ID AND meta_key='_alegra_item_id' LIMIT 1) as alegra_id,
                    (SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id=p.ID AND meta_key='_thumbnail_id' LIMIT 1) as thumbnail_id,
                    (SELECT t.slug FROM {$wpdb->term_relationships} tr
                     INNER JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id=tt.term_taxonomy_id
                     INNER JOIN {$wpdb->terms} t ON tt.term_id=t.term_id
                     WHERE tr.object_id=p.ID AND tt.taxonomy='product_type' LIMIT 1) as product_type,
                    (SELECT post_title FROM {$wpdb->posts} WHERE ID=p.post_parent LIMIT 1) as parent_title
             FROM {$wpdb->posts} p
             WHERE 1=1 {$post_type_clause} AND p.post_status='publish' {$where_filter} {$where_search}
             ORDER BY p.ID DESC LIMIT %d OFFSET %d",
            $per_page, $offset
        ));

        $products = [];
        foreach ((array) $rows as $row) {
            $thumb_id = (int) ($row->thumbnail_id ?: 0);
            $thumb_url = '';
            $thumb_alt = '';
            if ($thumb_id > 0) {
                $thumb_src = wp_get_attachment_image_src($thumb_id, 'thumbnail');
                if ($thumb_src && is_array($thumb_src)) {
                    $thumb_url = $thumb_src[0];
                }
                $thumb_alt = get_post_meta($thumb_id, '_wp_attachment_image_alt', true);
                if (empty($thumb_alt)) {
                    $thumb_alt = $row->post_title;
                }
            }
            $products[] = [
                'id' => (int) $row->ID,
                'name' => $row->post_title,
                'sku' => $row->sku ?: '',
                'price' => (float) ($row->price ?: 0),
                'type' => $row->product_type ?: 'simple',
                'parent_id' => (int) $row->post_parent,
                'parent_title' => $row->parent_title ?: '',
                'alegra_id' => (string) ($row->alegra_id ?: ''),
                'thumbnail_id' => $thumb_id,
                'thumbnail_url' => $thumb_url,
                'thumbnail_alt' => $thumb_alt,
            ];
        }

        // Sync stats - only count main products (exclude variations)
        $synced_count = (int) $wpdb->get_var(
            "SELECT COUNT(DISTINCT pm.post_id) FROM {$wpdb->postmeta} pm
             INNER JOIN {$wpdb->posts} p ON pm.post_id = p.ID
             WHERE pm.meta_key='_alegra_item_id' AND p.post_type='product'"
        );
        $variable_count = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->posts} p 
             INNER JOIN {$wpdb->term_relationships} tr ON p.ID=tr.object_id 
             INNER JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id=tt.term_taxonomy_id 
             INNER JOIN {$wpdb->terms} t ON tt.term_id=t.term_id 
             WHERE p.post_type='product' AND p.post_status='publish' AND tt.taxonomy='product_type' AND t.slug='variable'"
        );
        $variation_count = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type='product_variation' AND post_status='publish'"
        );
        $synced_variations = (int) $wpdb->get_var(
            "SELECT COUNT(DISTINCT pm.post_id) FROM {$wpdb->postmeta} pm
             INNER JOIN {$wpdb->posts} p ON pm.post_id = p.ID
             WHERE pm.meta_key='_alegra_item_id' AND p.post_type='product_variation'"
        );

        $header_color = 'green';
        $connected = (bool) get_option('alegra_connector_connection_tested');

        include ALEGRA_CONNECTOR_PATH . 'templates/admin-products.php';
    }

    private function render_product_detail(int $product_id): void
    {
        $product = wc_get_product($product_id);
        if (!$product) {
            wp_die(esc_html__('Producto no encontrado.', 'alegra-connector'));
        }

        $alegra_id = (string) get_post_meta($product_id, '_alegra_item_id', true);
        $alegra_data = null;
        $alegra_error = null;

        if ($alegra_id !== '' && $alegra_id !== null && get_option('alegra_connector_connection_tested') && $this->api) {
            $result = $this->api->get_item($alegra_id);
            if (is_wp_error($result)) {
                $alegra_error = sprintf(__('Error de Alegra: %s', 'alegra-connector'), $result->get_error_message());
            } else {
                $alegra_data = $result;
            }
        }

        include ALEGRA_CONNECTOR_PATH . 'templates/admin-product-detail.php';
    }

    public function render_customers_page(): void
    {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('No tienes permisos.', 'alegra-connector'));
        }

        global $wpdb;

        $page = isset($_GET['paged']) ? max(1, (int) $_GET['paged']) : 1;
        $per_page = 20;

        // Single customer detail
        $customer_id = isset($_GET['customer_id']) ? (int) $_GET['customer_id'] : 0;
        if ($customer_id > 0) {
            $this->render_customer_detail($customer_id);
            return;
        }

        $args = [
            'role' => 'customer',
            'number' => $per_page,
            'paged' => $page,
            'orderby' => 'ID',
            'order' => 'DESC',
        ];

        $customers = get_users($args);
        $total_users = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->users} u
             INNER JOIN {$wpdb->usermeta} um ON u.ID=um.user_id AND um.meta_key='{$wpdb->prefix}capabilities'
             WHERE um.meta_value LIKE '%\"customer\"%'"
        );
        $total_pages = (int) ceil($total_users / $per_page);

        $synced_customers = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key='alegra_contact_id' AND meta_value != ''"
        );

        $header_color = 'teal';

        include ALEGRA_CONNECTOR_PATH . 'templates/admin-customers.php';
    }

    private function render_customer_detail(int $customer_id): void
    {
        $customer = get_userdata($customer_id);
        if (!$customer) {
            wp_die(esc_html__('Cliente no encontrado.', 'alegra-connector'));
        }

        $alegra_id = (string) get_user_meta($customer_id, 'alegra_contact_id', true);
        $alegra_data = null;
        $alegra_error = null;

        if ($alegra_id !== '' && $alegra_id !== null && get_option('alegra_connector_connection_tested') && $this->api) {
            $result = $this->api->get_contact($alegra_id);
            if (is_wp_error($result)) {
                $alegra_error = sprintf(__('Error de Alegra: %s', 'alegra-connector'), $result->get_error_message());
            } else {
                $alegra_data = $result;
            }
        }

        include ALEGRA_CONNECTOR_PATH . 'templates/admin-customer-detail.php';
    }

    public function render_orders_page(): void
    {
        global $wpdb;

        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('No tienes permisos.', 'alegra-connector'));
        }

        $page = isset($_GET['paged']) ? max(1, (int) $_GET['paged']) : 1;
        $per_page = 20;

        // Single order detail
        $order_id = isset($_GET['order_id']) ? (int) $_GET['order_id'] : 0;
        if ($order_id > 0) {
            $this->render_order_detail($order_id);
            return;
        }

        $args = [
            'limit' => $per_page,
            'page' => $page,
            'orderby' => 'date',
            'order' => 'DESC',
        ];

        $orders = wc_get_orders($args);
        $orders_table = HPOS::get_orders_table();
        $meta_table = HPOS::get_order_meta_table();
        if (HPOS::is_enabled()) {
            $total_orders = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$orders_table} WHERE type='shop_order'");
        } else {
            $total_orders = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type='shop_order'");
        }
        $total_pages = (int) ceil($total_orders / $per_page);

        $synced_orders = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$meta_table} WHERE meta_key='_alegra_invoice_id' AND meta_value != ''");
        $payment_count = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$meta_table} WHERE meta_key='_alegra_payment_id' AND meta_value != ''");

        $header_color = 'amber';

        include ALEGRA_CONNECTOR_PATH . 'templates/admin-orders.php';
    }

    private function render_order_detail(int $order_id): void
    {
        $order = wc_get_order($order_id);
        if (!$order) {
            wp_die(esc_html__('Pedido no encontrado.', 'alegra-connector'));
        }

        $alegra_invoice_id = (string) $order->get_meta('_alegra_invoice_id', true);
        $alegra_invoice_number = $order->get_meta('_alegra_invoice_number', true);
        $alegra_payment_id = (string) $order->get_meta('_alegra_payment_id', true);
        $alegra_data = null;
        $alegra_error = null;

        // Make API available for templates via local variable (cleaner than $GLOBALS)
        $alegra_api = $this->api;

        if ($alegra_invoice_id !== '' && $alegra_invoice_id !== null && get_option('alegra_connector_connection_tested') && $this->api) {
            $result = $this->api->get_invoice($alegra_invoice_id);
            if (is_wp_error($result)) {
                $alegra_error = sprintf(__('Error de Alegra: %s', 'alegra-connector'), $result->get_error_message());
            } else {
                $alegra_data = $result;
            }
        }

        include ALEGRA_CONNECTOR_PATH . 'templates/admin-order-detail.php';
    }

    public function ajax_test_connection(): void
    {
        check_ajax_referer('alegra_connector_nonce');

        // Overwriting the stored API credentials is an admin-level action, not a
        // shop-manager one (AC-33).
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('No tienes permisos.', 'alegra-connector')]);
        }

        $email = sanitize_email($_POST['email'] ?? '');
        $token = sanitize_text_field($_POST['token'] ?? '');

        // The token field is masked; fall back to the stored token when empty.
        if ($token === '') {
            $token = (string) get_option('alegra_connector_token', '');
        }

        if (empty($email) || empty($token)) {
            wp_send_json_error(['message' => __('Email y token son requeridos.', 'alegra-connector')]);
        }

        $this->log('info', 'Connection test started', ['email' => $email]);

        // Save credentials (never overwrite the token with an empty value).
        update_option('alegra_connector_email', $email);
        update_option('alegra_connector_token', $token);

        // Quick pre-flight: verify the API URL is reachable
        $base_url = rtrim((string) get_option('alegra_connector_api_url', 'https://api.alegra.com/api/v1'), '/');
        $preflight = wp_remote_head($base_url . '/company', [
            'timeout' => 5,
            'headers' => [
                'Authorization' => 'Basic ' . base64_encode($email . ':' . $token),
            ],
        ]);

        if (is_wp_error($preflight)) {
            update_option('alegra_connector_connection_tested', false);
            $this->log('error', 'Connection test: network unreachable', ['error' => $preflight->get_error_message()]);
            wp_send_json_error([
                'message' => __('No se pudo contactar el servidor de Alegra.', 'alegra-connector'),
                'code' => 'network_error',
                'http_code' => 0,
            ]);
        }

        if (!is_wp_error($preflight)) {
            $result = $this->api->test_connection($email, $token);
        } else {
            $result = $preflight;
        }

        if (is_wp_error($result)) {
            update_option('alegra_connector_connection_tested', false);
            $code = $result->get_error_code();
            $msg = $result->get_error_message();
            $data = $result->get_error_data();
            $http_code = is_array($data) ? ($data['code'] ?? 0) : 0;

            $this->log('error', 'Connection test failed', [
                'error_code' => $code, 'http_code' => $http_code, 'message' => $msg,
            ]);

            wp_send_json_error([
                'message' => $msg,
                'code' => $code,
                'http_code' => $http_code,
            ]);
        }

        // Save connection info
        if (isset($result['company'])) {
            update_option('alegra_connector_company_name', sanitize_text_field($result['company']));
        }
        if (isset($result['country'])) {
            update_option('alegra_connector_company_country', sanitize_text_field($result['country']));
        }
        if (isset($result['email'])) {
            update_option('alegra_connector_company_email', sanitize_text_field($result['email']));
        }
        // REQ-HYG-1: the `alegra_connector_items_count` / `_contacts_count`
        // options were written here and never read anywhere. Removed. The counts
        // are still returned in the JSON payload below (derived from $result).
        update_option('alegra_connector_connection_tested', true);

        // D1 / REQ-CF-01: resolver el CF bajo contexto explícito, READ-ONLY.
        // probe() nunca POSTea; run_explicit() deja el contexto listo para el
        // sub-flujo explícito "Crear Consumidor Final" (mismo AJAX, create=true).
        $cf_probe = \Alegra\Connector\Write_Gate::run_explicit(
            static fn (): array => \Alegra\Connector\Consumidor_Final::probe()
        );
        \Alegra\Connector\Consumidor_Final::persist_probe($cf_probe);

        $diagnostics = $result['diagnostics'] ?? [];
        update_option('alegra_connector_diagnostics', $diagnostics, false);

        $this->log('info', 'Connection test successful', ['company' => $result['company'] ?? 'Unknown', 'diagnostics' => $diagnostics]);

        wp_send_json_success([
            'message' => __('Conexión exitosa', 'alegra-connector'),
            'company' => $result['company'] ?? '',
            'country' => $result['country'] ?? '',
            'email' => $result['email'] ?? '',
            'items_count' => $result['items_count'] ?? 0,
            'contacts_count' => $result['contacts_count'] ?? 0,
            'diagnostics' => $diagnostics,
            'consumidor_final' => $cf_probe,
        ]);
    }

    /**
     * AJAX: verifica (y opcionalmente crea) el Consumidor Final.
     *
     * - action:  alegra_verify_consumidor_final
     * - nonce:   alegra_connector_nonce
     * - cap:     manage_options
     * - body:    create (bool, opcional)
     * - resp:    {success, data:{state, id, message}}  (message SIEMPRE, NFR-04)
     *
     * READ-ONLY salvo create=true, que corre get_or_create_id() bajo run_explicit().
     * Con el kill switch activo, la compuerta bloquea el POST y no se cachea nada.
     */
    public function ajax_verify_consumidor_final(): void
    {
        check_ajax_referer('alegra_connector_nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('No tienes permisos.', 'alegra-connector')]);
        }

        $create = !empty($_POST['create'])
            && filter_var(wp_unslash($_POST['create']), FILTER_VALIDATE_BOOLEAN);

        $probe = \Alegra\Connector\Write_Gate::run_explicit(
            static function () use ($create): array {
                if ($create) {
                    // Rama B explícita: crear SÓLO bajo acción explícita.
                    $id = \Alegra\Connector\Consumidor_Final::get_or_create_id();
                    if ($id !== false && $id !== '') {
                        return ['state' => 'available', 'id' => (string) $id, 'reason' => 'created', 'scanned' => 0];
                    }
                    // No se pudo crear (kill switch / sin datos): caer al barrido
                    // read-only para no mentir con un estado "available" falso.
                }
                return \Alegra\Connector\Consumidor_Final::probe();
            }
        );

        $probe = \Alegra\Connector\Consumidor_Final::persist_probe($probe);

        wp_send_json_success([
            'state'   => $probe['state'],
            'id'      => $probe['id'],
            'message' => self::consumidor_final_message($probe),
        ]);
    }

    /**
     * Mensaje accionable por estado (NFR-04). Siempre no vacío.
     *
     * @param array<string,mixed> $probe
     */
    private static function consumidor_final_message(array $probe): string
    {
        switch ((string) ($probe['state'] ?? '')) {
            case 'available':
                return __('Consumidor Final disponible.', 'alegra-connector');
            case 'not_found':
                return __('No se encontró el Consumidor Final en Alegra. Podés crearlo.', 'alegra-connector');
            default:
                $reason = (string) ($probe['reason'] ?? '');
                return $reason !== ''
                    ? sprintf(__('No se pudo verificar el Consumidor Final: %s', 'alegra-connector'), $reason)
                    : __('No se pudo verificar el Consumidor Final.', 'alegra-connector');
        }
    }

    public function ajax_sync_now(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) wp_send_json_error(['message' => __('No tienes permisos.', 'alegra-connector')]);

        $sync_type = sanitize_text_field($_POST['sync_type'] ?? 'all');

        // REQ-CFG-5: "Sincronizar ahora" must be honest. run_cron_sync() early
        // returns when sync_method is not cron/both, which used to look like a
        // silent success. Explain why instead.
        $blocked = $this->sync_now_blocked_payload();
        if ($blocked !== null) {
            wp_send_json_error($blocked);
        }

        $sync_controller = new Sync\Controller($this->api, $this->logger);

        if ($sync_type === 'all') {
            $sync_controller->run_cron_sync();
            wp_send_json_success(['message' => __('Sincronización completa.', 'alegra-connector')]);
        }
        // For specific types, redirect to chunked sync via JS (handled by ajax_sync_start + ajax_sync_page)
        wp_send_json_success(['message' => __('ok', 'alegra-connector'), 'use_chunked' => true, 'type' => $sync_type]);
    }

    /**
     * Why "Run now" / "Sincronizar ahora" cannot execute, or null when it can.
     *
     * Shared by ajax_sync_now() and ajax_run_cron_now() so both buttons tell the
     * same truth (REQ-CFG-5). run_cron_sync() still keeps its own early-return
     * as defence in depth.
     *
     * @return array{message:string,blocked:bool,reason:string}|null
     */
    private function sync_now_blocked_payload(): ?array
    {
        if (\Alegra\Connector\Kill_Switch::is_active()) {
            return [
                'message' => __('El plugin está desconectado (kill switch activo). Reconéctalo antes de sincronizar.', 'alegra-connector'),
                'blocked' => true,
                'reason'  => 'kill_switch',
            ];
        }

        $sync_method = (string) get_option('alegra_connector_sync_method', 'cron');
        if (!in_array($sync_method, ['cron', 'both'], true)) {
            $message = $sync_method === 'real-time'
                ? __('El método de sincronización es "Solo Tiempo Real": no hay traída periódica que ejecutar. Cambialo a "Periódica" para usar esta acción.', 'alegra-connector')
                : sprintf(
                    /* translators: %s: current sync method */
                    __('La sincronización periódica está desactivada (método actual: %s). Cambiala a "Periódica" o "Periódica + Tiempo Real" para ejecutar ahora.', 'alegra-connector'),
                    $sync_method
                );

            return [
                'message' => $message,
                'blocked' => true,
                'reason'  => 'sync_method',
            ];
        }

        return null;
    }

    /**
     * AJAX: pull inventory from Alegra (Alegra → WooCommerce stock).
     *
     * Manual counterpart of the documented `alegra_sync_inventory_from_alegra`
     * action. The pull enforces the inventory_source / kill-switch / lock /
     * cancellation gates itself.
     */
    public function ajax_sync_inventory(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(['message' => __('No tienes permisos.', 'alegra-connector')]);
        }

        // T7.2.b-2: "desde cero" borra el cursor antes de la corrida.
        if (!empty($_POST['from_zero'])) {
            delete_option('alegra_connector_inventory_pull_cursor');
            delete_option('alegra_connector_inventory_pull_total');
        }

        $result = (new Sync\Controller($this->api, $this->logger))->run_inventory_sync();

        if (!empty($result['skipped'])) {
            wp_send_json_error(['message' => __('La copia de inventario está desactivada: la fuente de inventario es WooCommerce.', 'alegra-connector')]);
        }
        if (!empty($result['locked'])) {
            wp_send_json_error(['message' => __('Ya hay una sincronización en curso. Intenta de nuevo en unos segundos.', 'alegra-connector')]);
        }

        $truncated = !empty($result['truncated']);
        $message = $truncated
            ? sprintf(
                /* translators: 1: updated count, 2: resume cursor */
                __('Inventario sincronizado parcialmente: %1$d productos actualizados. Quedó trabajo pendiente (cursor %2$d); volvé a ejecutar para continuar.', 'alegra-connector'),
                (int) ($result['updated'] ?? 0),
                (int) ($result['cursor'] ?? 0)
            )
            : sprintf(
                /* translators: %d: number of products whose stock was updated */
                __('Inventario sincronizado: %d productos actualizados.', 'alegra-connector'),
                (int) ($result['updated'] ?? 0)
            );

        wp_send_json_success([
            'message'   => $message,
            'updated'   => (int) ($result['updated'] ?? 0),
            'truncated' => $truncated,
            'completed' => !empty($result['completed']),
            'cursor'    => (int) ($result['cursor'] ?? 0),
            'pages'     => (int) ($result['pages'] ?? 0),
        ]);
    }

    /**
     * Sanitize the product-import filters posted from the Products modal.
     *
     * Invalid input degrades to "all" and never throws. Shape:
     *   [idItemCategory => string, status => default|active|inactive,
     *    inventariable => bool, query => string, type => ''|simple|kit|variantParent]
     *
     * @param array<string,mixed> $raw
     * @return array{idItemCategory:string,status:string,inventariable:bool,query:string,type:string}
     */
    private function sanitize_item_filters(array $raw): array
    {
        $status = isset($raw['status']) ? sanitize_text_field((string) $raw['status']) : 'default';
        if (!in_array($status, ['default', 'active', 'inactive'], true)) {
            $status = 'default';
        }

        $type = isset($raw['type']) ? sanitize_text_field((string) $raw['type']) : '';
        if (!in_array($type, ['', 'simple', 'kit', 'variantParent'], true)) {
            $type = '';
        }

        return [
            'idItemCategory' => isset($raw['idItemCategory']) ? sanitize_text_field((string) $raw['idItemCategory']) : '',
            'status'         => $status,
            'inventariable'  => filter_var($raw['inventariable'] ?? false, FILTER_VALIDATE_BOOLEAN),
            'query'          => isset($raw['query']) ? sanitize_text_field((string) $raw['query']) : '',
            'type'           => $type,
        ];
    }

    /**
     * Whitelist the WooCommerce fields that must NOT be overwritten on import.
     *
     * Used as the `sanitize_callback` of `alegra_connector_import_preserve_fields`
     * (Ajustes → Sincronización) and for the per-run value from the modal.
     *
     * @param mixed $value
     * @return array<int,string> Subset of description|name|price|images|inventory|sku
     */
    public static function sanitize_preserve_fields($value): array
    {
        $allowed = ['description', 'name', 'price', 'images', 'inventory', 'sku'];
        if (!is_array($value)) {
            return [];
        }

        $out = [];
        foreach ($value as $field) {
            $field = sanitize_key((string) $field);
            if (in_array($field, $allowed, true)) {
                $out[] = $field;
            }
        }

        return array_values(array_unique($out));
    }

    /**
     * Clamp the payment sweep batch size to 1..100 (REQ-CFG-1).
     *
     * Used as the `sanitize_callback` of
     * `alegra_connector_payment_reconcile_batch`.
     *
     * @param mixed $value
     */
    public static function sanitize_reconcile_batch($value): int
    {
        return max(1, min(100, (int) $value));
    }

    /**
     * Suma dos desgloses de imagen (por página) preservando las claves. D5.
     * @param array<string,int> $a @param array<string,int> $b
     * @return array<string,int>
     */
    private static function merge_image_stats(array $a, array $b): array
    {
        $out = [];
        foreach (['ok', 'blocked', 'download', 'sideload', 'deferred'] as $k) {
            $out[$k] = (int) ($a[$k] ?? 0) + (int) ($b[$k] ?? 0);
        }
        $out['failed'] = $out['blocked'] + $out['download'] + $out['sideload'];
        return $out;
    }

    /**
     * Sanitiza la lista de hosts de imagen extra. Un host por línea o por elemento.
     * Acepta solo dominios válidos; rechaza `*`, `/`, `:` (NFR-07). D5.
     * @param mixed $value
     * @return array<int,string>
     */
    public static function sanitize_image_hosts($value): array
    {
        if (is_string($value)) {
            $value = preg_split('/\r\n|\r|\n/', $value) ?: [];
        }
        if (!is_array($value)) {
            return [];
        }
        $out = [];
        foreach ($value as $line) {
            $host = strtolower(trim((string) $line));
            if ($host === '') {
                continue;
            }
            $host = (string) preg_replace('#^[a-z][a-z0-9+.-]*://#i', '', $host); // quitar esquema
            $host = rtrim($host, '/');
            if (preg_match('#[/*:]#', $host)) {
                continue; // rechaza comodín, path y puerto
            }
            if (!preg_match('/^[a-z0-9.-]+\.[a-z]{2,}$/', $host)) {
                continue; // exige dominio con TLD
            }
            $out[] = $host;
        }
        return array_values(array_unique($out));
    }

    /**
     * Sanitize the merchant's webhook event selection.
     *
     * Only slugs from the documented enum survive; anything else (typos,
     * injections, a stale slug) is dropped. A non-array value means the option
     * was not posted at all and yields an empty selection — the selector always
     * posts the array (with a hidden empty entry) so an intentional "none" is
     * representable.
     *
     * @param mixed $value
     * @return array<int,string>
     */
    public static function sanitize_webhook_selected_events($value): array
    {
        if (!is_array($value)) {
            return [];
        }

        $allowed = API\Client::get_webhook_events();
        $out = [];
        foreach ($value as $event) {
            $event = sanitize_text_field((string) $event);
            if ($event !== '' && in_array($event, $allowed, true)) {
                $out[] = $event;
            }
        }

        return array_values(array_unique($out));
    }

    /**
     * Sanitize the field mapping without ever wiping it (REQ-CFG-3).
     *
     * A null / non-array value means the option was not posted in full; return
     * the stored value so `update_option()` becomes a no-op instead of writing
     * an empty array over the merchant's mapping.
     *
     * @param mixed $value
     * @return array<string,mixed>
     */
    public static function sanitize_field_mapping($value): array
    {
        if (!is_array($value)) {
            return (array) get_option('alegra_connector_field_mapping', []);
        }
        return map_deep($value, 'sanitize_text_field');
    }

    /**
     * Sanitize the tax mapping without ever wiping it (REQ-CFG-3).
     *
     * @param mixed $value
     * @return array<string,mixed>
     */
    public static function sanitize_tax_mapping($value): array
    {
        if (!is_array($value)) {
            return (array) get_option('alegra_connector_tax_mapping', []);
        }
        return map_deep($value, 'sanitize_text_field');
    }

    /**
     * Translate sanitized filters into Alegra `GET /items` query params.
     *
     * The implicit `status=active` (driven by sync_inactive_products) is only
     * added when $include_default_status is true. The metadata call in
     * ajax_sync_start passes false so that, with no filters, the total is
     * byte-for-byte the same as before this feature.
     *
     * @param array{idItemCategory?:string,status?:string,inventariable?:bool,query?:string,type?:string} $f
     * @return array<string,string>
     */
    private function build_item_filter_params(array $f, bool $include_default_status = true): array
    {
        $p = [];

        if (($f['idItemCategory'] ?? '') !== '') {
            $p['idItemCategory'] = (string) $f['idItemCategory'];
        }

        if (in_array($f['status'] ?? 'default', ['active', 'inactive'], true)) {
            $p['status'] = (string) $f['status'];
        } elseif ($include_default_status && !get_option('alegra_connector_sync_inactive_products', false)) {
            // Preserves the pre-existing behaviour on the page loop.
            $p['status'] = 'active';
        }

        if (!empty($f['inventariable'])) {
            // The API documents a boolean; send the literal "true" (a PHP bool
            // would serialize to "1" through http_build_query()).
            $p['inventariable'] = 'true';
        }

        if (($f['query'] ?? '') !== '') {
            $p['query'] = (string) $f['query'];
        }

        // `simple` and `kit` are the documented `type` filter values.
        // `variantParent` is handled client-side in ajax_sync_page.
        if (in_array($f['type'] ?? '', ['simple', 'kit'], true)) {
            $p['type'] = (string) $f['type'];
        }

        return $p;
    }

    /**
     * AJAX: Start chunked sync - get EXACT total via metadata=true
     */
    public function ajax_sync_start(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) wp_send_json_error();

        $type = sanitize_text_field($_POST['sync_type'] ?? 'products');
        $from_zero       = !empty($_POST['from_zero']);
        $recreate_manual = !empty($_POST['recreate_manual']);

        if (!get_option('alegra_connector_connection_tested')) {
            // K1: run_type canónico, no el alias `chunked`.
            \Alegra\Connector\Run_Context::fail_early('chunked_import', 'connection_not_tested');
            wp_send_json_error(['message' => __('Conecta primero con Alegra.', 'alegra-connector')]);
        }

        // D7 (Oracle): el botón Cancelar deja `alegra_sync_cancelled` con TTL 120 s.
        // Sin limpiarlo acá, un import nuevo arrancado dentro de esa ventana es
        // cancelado al instante por la rama de cancel de `ajax_sync_page`.
        delete_transient('alegra_sync_cancelled');

        // D-D (Oracle): `ajax_sync_start` debe ser ATÓMICO. Sin lock, dos arranques
        // concurrentes (doble clic / dos pestañas) pasan AMBOS el read-check de
        // abajo y llaman `Run_Context::begin()` + `set_transient()`: el segundo
        // pisa el `run_id`/`start` del primero y deja un run `running` huérfano.
        // Se toma el MISMO lock per-type que usa `ajax_sync_page` y se mantiene
        // durante: lectura del estado + begin() + set_transient().
        $lock = \Alegra\Connector\Sync\Controller::acquire_sync_lock_public($type);
        if ($lock === false) {
            wp_send_json_error(['message' => __('Ya hay una importación en curso. Esperá a que termine o cancelala.', 'alegra-connector')]);
        }

        try {
            // D3 (Oracle): DENTRO del lock, rechazar un segundo arranque sólo si el
            // run del estado sigue VIVO (running + heartbeat vigente, mismo criterio
            // que `mark_abandoned`). Un estado huérfano (run stale/cerrado o
            // heartbeat vencido) se limpia y se permite reanudar (REQ-RES-01).
            $existing = get_transient('alegra_batch_state');
            if (is_array($existing)) {
                $existing_run   = (int) ($existing['run_id'] ?? 0);
                $existing_alive = $existing_run > 0
                    && \Alegra\Connector\Runs::status($existing_run) === 'running'
                    && \Alegra\Connector\Heartbeat::get($existing_run) !== null;
                if ($existing_alive) {
                    \Alegra\Connector\Sync\Controller::release_sync_lock_public($type, $lock);
                    wp_send_json_error(['message' => __('Ya hay una importación en curso. Esperá a que termine o cancelala.', 'alegra-connector')]);
                }
                delete_transient('alegra_batch_state');
            }

            $this->api->reload_credentials();

            // Product-import filters (empty for the other entity types / legacy calls).
            $raw_filters = $_POST['filters'] ?? '';
            if (is_string($raw_filters) && $raw_filters !== '') {
                $decoded = json_decode(wp_unslash($raw_filters), true);
            } elseif (is_array($raw_filters)) {
                $decoded = $raw_filters;
            } else {
                $decoded = [];
            }
            $filters = $this->sanitize_item_filters(is_array($decoded) ? $decoded : []);

            // D1 §2.3: la fila existe desde el arranque; ajax_sync_page la cierra.
            $run_id = \Alegra\Connector\Run_Context::begin('chunked_import');

            // Get exact total via metadata=true (single API call!)
            $total = 0;
            if ($type === 'customers') {
                $resp = $this->api->get('/contacts', ['metadata' => 'true', 'limit' => 1, 'type' => 'client']);
                if (is_wp_error($resp)) {
                    \Alegra\Connector\Run_Context::finish($run_id, 'failed', $resp->get_error_message());
                    \Alegra\Connector\Sync\Controller::release_sync_lock_public($type, $lock);
                    wp_send_json_error(['message' => sprintf(__('Error de Alegra: %s', 'alegra-connector'), $resp->get_error_message())]);
                }
                if (isset($resp['metadata']['total'])) { $total = (int) $resp['metadata']['total']; }
            } else {
                // The metadata total must reflect the explicit filters, but NOT the
                // implicit default status, to preserve the historical total.
                $params = ['metadata' => 'true', 'limit' => 1] + $this->build_item_filter_params($filters, false);
                $resp = $this->api->get('/items', $params);
                if (is_wp_error($resp)) {
                    \Alegra\Connector\Run_Context::finish($run_id, 'failed', $resp->get_error_message());
                    \Alegra\Connector\Sync\Controller::release_sync_lock_public($type, $lock);
                    wp_send_json_error(['message' => sprintf(__('Error de Alegra: %s', 'alegra-connector'), $resp->get_error_message())]);
                }
                if (isset($resp['metadata']['total'])) { $total = (int) $resp['metadata']['total']; }
            }

            $per_page = 30;
            $total_pages = $total > 0 ? (int) ceil($total / $per_page) : 1;
            $cursor_key = 'alegra_connector_products_import_cursor';

            // D4 §5.3: "desde cero" solo toca el cursor si es products. Se hace en
            // `start` (no en page 1) para que un cron concurrente no reanude el cursor viejo.
            $start = 0;
            if ($type === 'products') {
                if ($from_zero) {
                    delete_option($cursor_key);
                    delete_option('alegra_connector_products_import_total');
                    $start = 0;
                } else {
                    $start = max(0, (int) get_option($cursor_key, 0));
                }
            }
            $resuming = ($start > 0);

            $policy = 'respect';
            if ($from_zero) {
                $policy = $recreate_manual ? 'ignore_all' : 'ignore_bulk';
            }

            // K2: shape canónico de `alegra_batch_state`. Este bloque es el DUEÑO
            // único; Fases 4/5 sólo leen/mutan claves existentes (nunca lo re-listan).
            // `page` NO se escribe (sólo se lee como fallback del estado viejo, C5).
            $state = [
                'type' => $type, 'run_id' => $run_id,
                'start' => $start, 'offset' => 0, 'per_page' => $per_page,
                'total_pages' => $total_pages, 'total_items' => $total,
                'imported' => 0, 'updated' => 0, 'skipped' => 0, 'errors' => 0,
                'images' => ['ok' => 0, 'blocked' => 0, 'download' => 0, 'sideload' => 0, 'deferred' => 0],
                'from_zero' => $from_zero, 'policy' => $policy,
                'filters' => $filters,
            ];
            set_transient('alegra_batch_state', $state, 600);

            if ($type === 'products' && $total > 0) {
                update_option('alegra_connector_products_import_total', $total, false);
            }

            // D-D: liberar el lock per-type ANTES de responder (die() no corre finally).
            \Alegra\Connector\Sync\Controller::release_sync_lock_public($type, $lock);

            wp_send_json_success([
                'total_pages' => $total_pages, 'total_items' => $total, 'per_page' => $per_page,
                'run_id' => $run_id, 'start' => $start, 'resuming' => $resuming,
                'message' => $resuming
                    ? sprintf(__('Reanudando desde el ítem %1$d de %2$d.', 'alegra-connector'), $start, $total)
                    : sprintf(__('Importando %1$d ítems desde el inicio.', 'alegra-connector'), $total),
            ]);
        } finally {
            \Alegra\Connector\Sync\Controller::release_sync_lock_public($type, $lock);
        }
    }

    /**
     * Process one page of chunked sync
     */
    public function ajax_sync_page(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) wp_send_json_error();

        // D1: leer el state con default [] para poder chequear cancel/stop ANTES
        // del guard de "no_batch_state" (el botón Cancelar setea el flag).
        $state  = get_transient('alegra_batch_state');
        $state  = is_array($state) ? $state : [];
        $run_id = (int) ($state['run_id'] ?? 0);

        // REQ-MON-05 / D1: cancel (botón) o stop (Monitor) cierran el run ANTES
        // de cualquier otro guard. `should_stop` sólo se evalúa si hay run_id.
        if (get_transient('alegra_sync_cancelled') || ($run_id > 0 && \Alegra\Connector\Runs::should_stop($run_id))) {
            if ($run_id > 0) {
                \Alegra\Connector\Run_Context::finish($run_id, 'cancelled', 'Cancelado por el usuario');
            }
            delete_transient('alegra_sync_progress');
            delete_transient('alegra_batch_state');
            wp_send_json_success([
                'done' => true, 'cancelled' => true,
                'message' => __('Sincronización cancelada.', 'alegra-connector'),
            ]);
        }

        if (!$state) {
            \Alegra\Connector\Run_Context::fail_early('chunked_import', 'no_batch_state');
            wp_send_json_error(['message' => __('No hay un proceso de sincronización en curso.', 'alegra-connector')]);
        }

        // D3: el lock se toma ANTES de la lectura autoritativa del estado. El
        // `get_transient` de arriba fue sólo para conocer `type`/`run_id`.
        $type = (string) $state['type'];
        $lock = \Alegra\Connector\Sync\Controller::acquire_sync_lock_public($type);
        if ($lock === false) {
            \Alegra\Connector\Run_Context::finish($run_id, 'failed', 'Ya hay una sincronización en curso');
            delete_transient('alegra_batch_state');
            wp_send_json_error(['message' => __('Another sync is in progress. Please wait.', 'alegra-connector')]);
        }

        $state = get_transient('alegra_batch_state');
        if (!is_array($state)) {
            \Alegra\Connector\Run_Context::fail_early('chunked_import', 'no_batch_state');
            \Alegra\Connector\Sync\Controller::release_sync_lock_public($type, $lock);
            wp_send_json_error(['message' => __('No hay un proceso de sincronización en curso.', 'alegra-connector')]);
        }
        $run_id = (int) ($state['run_id'] ?? $run_id);

        // K2 + C5: el cursor se resuelve desde el estado AUTORITATIVO (re-leído
        // bajo el lock). `start` es el cursor absoluto; `offset` la reanudación
        // intra-página (sólo products). `page` es fallback de lectura, no se
        // escribe. `$page` se deriva para el payload y la API de categorías.
        $per_page = (int) ($state['per_page'] ?? 30);
        $start    = (int) ($state['start'] ?? (((int) ($state['page'] ?? 0)) * $per_page));
        $offset   = (int) ($state['offset'] ?? 0);
        $page     = (int) floor($start / $per_page) + 1;

        // El contexto de logger se fija con el run_id AUTORITATIVO.
        \Alegra\Connector\Run_Context::resume($run_id, 'chunked_import');

        // D4: la política de tombstones viaja en el estado y se aplica en cada
        // página. Cron/manual no la setean → default 'respect' del static.
        \Alegra\Connector\Run_Context::set_tombstone_policy((string) ($state['policy'] ?? 'respect'));

        try {
        $this->api->reload_credentials();
        @set_time_limit(60);        // backstop duro; el corte real es el deadline de T3.1
        wp_raise_memory_limit();

        $paused = false;
        if ($type === 'products') {
            $filters = is_array($state['filters'] ?? null) ? $state['filters'] : [];
            // C5: `$start`/`$offset`/`$per_page` ya vienen resueltos arriba desde
            // el estado. El fetch trae la página COMPLETA y el loop saltea los
            // primeros $offset (reanudación honesta).
            $api_params = ['start' => $start, 'limit' => $per_page, 'mode' => 'advanced']
                + $this->build_item_filter_params($filters, true);
            $items = $this->api->get('/items', $api_params);
            if (is_wp_error($items)) {
                \Alegra\Connector\Run_Context::finish($run_id, 'failed', $items->get_error_message());
                delete_transient('alegra_batch_state');
                \Alegra\Connector\Sync\Controller::release_sync_lock_public($type, $lock);
                wp_send_json_error(['message' => $items->get_error_message()]);
            }

            // D3 §4.1: presupuesto propio por página. NO es set_time_limit; el
            // backstop de 60 s sólo cubre el margen.
            $budget   = max(10, min(40, (int) get_option('alegra_connector_chunked_page_budget', 20)));
            $deadline = microtime(true) + $budget;
            Sync\Products::set_deadline($deadline);        // C8/T3.2.b: deadline para imágenes
            Sync\Products::reset_image_stats();            // C8/T3.2.b (dueño)

            $is_last = count($items) < $per_page;          // plenitud sobre la página completa
            $index   = -1;
            $products_sync = new Sync\Products($this->api, $this->logger);

            foreach ($items as $item) {
                $index++;
                if ($index < $offset) { continue; }        // C6: saltear sin tocar contadores
                if (microtime(true) >= $deadline) { $paused = true; break; }  // ANTES de cada ítem

                $item_type = $item['type'] ?? 'simple';
                // D4: las variantes sueltas se rutean por el handler, que resuelve
                // el variantParent (import_single_item_from_alegra). Ya no hay skip mudo.

                // Client-side `variantParent` filter: the API does not document
                // this value for the `type` query param, so the whole catalog is
                // walked and non-variantParent items are discarded here.
                if (($filters['type'] ?? '') === 'variantParent' && $item_type !== 'variantParent') {
                    $state['skipped'] = ($state['skipped'] ?? 0) + 1;
                    continue;
                }

                $r = $products_sync->import_single_item_public($item, $run_id);   // T3.2: run_id + 'stopped'
                if ($r === 'stopped') { $paused = true; break; }
                if ($r === true) { $state['imported']++; }
                elseif ($r === 'updated') { $state['updated']++; }
                elseif ($r === 'skipped') { $state['skipped'] = ($state['skipped'] ?? 0) + 1; }  // D-C: contar
                else { $state['errors']++; }
            }
            Sync\Products::clear_deadline();               // C8/T3.2

            // Reanudación: pausado ⇒ persistir offset sin avanzar start; completo ⇒
            // avanzar start, resetear offset y persistir el cursor compartido.
            if ($paused) {
                $state['offset'] = max(0, $index);         // siguiente índice no procesado
            } else {
                $state['start']  = $start + $per_page;
                $state['offset'] = 0;
                update_option('alegra_connector_products_import_cursor', $state['start'], false);
            }

            // T5.2b: acumular el desglose de imagen de esta página en el estado
            // (fuente canónica que T3.4 expone en el payload).
            $state['images'] = self::merge_image_stats(
                is_array($state['images'] ?? null) ? $state['images'] : [],
                Sync\Products::image_stats()
            );
        } elseif ($type === 'customers') {
            $items = $this->api->get('/contacts', ['start' => $start, 'limit' => $per_page, 'type' => 'client']);
            if (is_wp_error($items)) {
                \Alegra\Connector\Run_Context::finish($run_id, 'failed', $items->get_error_message());
                delete_transient('alegra_batch_state');
                \Alegra\Connector\Sync\Controller::release_sync_lock_public($type, $lock);
                wp_send_json_error(['message' => $items->get_error_message()]);
            }

            $customers_sync = new Sync\Customers($this->api, $this->logger);
            foreach ($items as $item) {
                // UUID string — never cast an Alegra id to int.
                $alegra_id = (string) ($item['id'] ?? '');
                $contact_name = $item['name'] ?? '';
                $email = $item['email'] ?? '';

                if (empty($email)) {
                    $state['skipped'] = ($state['skipped'] ?? 0) + 1;
                    continue;
                }

                $existing_user_id = email_exists($email);
                if ($existing_user_id) {
                    update_user_meta($existing_user_id, 'alegra_contact_id', $alegra_id);
                    $customers_sync->import_single_contact_public($item);
                    $state['updated']++;
                } else {
                    $name_parts = explode(' ', $contact_name, 2);
                    $uid = wp_insert_user([
                        'user_email' => $email, 'user_login' => $email,
                        'first_name' => $name_parts[0] ?? '', 'last_name' => $name_parts[1] ?? '',
                        'role' => 'customer',
                    ]);
                    if (!is_wp_error($uid)) {
                        update_user_meta($uid, 'alegra_contact_id', $alegra_id);
                        $customers_sync->import_single_contact_public($item);
                        $state['imported']++;
                    } else { $state['errors']++; }
                }
            }
            $state['start'] = $start + $per_page;   // D2: el cursor avanza
            $is_last = count($items) < $per_page;
        } else {
            // La API de categorías pagina por `page`, derivada de `start`.
            $items = $this->api->get_item_categories(['page' => $page, 'limit' => $per_page]);
            if (is_wp_error($items)) {
                \Alegra\Connector\Run_Context::finish($run_id, 'failed', $items->get_error_message());
                delete_transient('alegra_batch_state');
                \Alegra\Connector\Sync\Controller::release_sync_lock_public($type, $lock);
                wp_send_json_error(['message' => $items->get_error_message()]);
            }
            foreach ($items as $item) {
                $t = wp_insert_term($item['name'] ?? '', 'product_cat', ['description' => $item['description'] ?? '']);
                if (!is_wp_error($t)) {
                    // UUID string — an (int) cast stored 0 for every category.
                    update_term_meta($t['term_id'], 'alegra_category_id', (string) ($item['id'] ?? ''));
                    $state['imported']++;
                } else { $state['errors']++; }
            }
            $state['start'] = $start + $per_page;   // D2: el cursor avanza
            $is_last = count($items) < $per_page;
        }

        // Si la página fue la última, ajustar el total observado (compat).
        $item_count = is_array($items) ? count($items) : 0;
        if ($is_last) {
            $state['total_pages'] = $page;
            $state['total_items'] = (($page - 1) * $per_page) + $item_count;
        }

        $processed = $state['imported'] + $state['updated'] + $state['errors'] + ($state['skipped'] ?? 0);
        $tp        = (int) ($state['total_pages'] ?? 0);
        $total_items = (int) ($state['total_items'] ?? 0);
        $next_start  = (int) ($state['start'] ?? 0);
        $done = !$paused && ($is_last || ($tp > 0 && $next_start >= $tp * $per_page) || empty($items));
        // percent por ítems procesados (no por página): con offset, page/tp miente.
        $pct = $total_items > 0
            ? min(100, (int) round(($processed / $total_items) * 100))
            : ($tp > 0 ? min(100, (int) round((($next_start) / ($tp * $per_page)) * 100)) : 0);

        // D1 §2.4: heartbeat + progreso por PÁGINA (nunca por ítem, NFR-04).
        if ($run_id > 0) {
            \Alegra\Connector\Heartbeat::set($run_id, [
                'step' => $type,
                'message' => sprintf(__('Procesando... Página %d/%d', 'alegra-connector'), $page, max(1, $tp)),
                'step_num' => $page, 'total_steps' => max(1, $tp),
            ]);
            \Alegra\Connector\Runs::update_progress($run_id, $processed, $total_items);
        }

        if ($done) {
            \Alegra\Connector\Run_Context::finish($run_id, 'completed');
            // B-A (Oracle): `alegra_connector_products_import_cursor` es un
            // option GLOBAL de products. Sólo se borra cuando la entidad que
            // terminó es `products`.
            if ($type === 'products') {
                delete_option('alegra_connector_products_import_cursor');
            }
            delete_transient('alegra_batch_state');
        } else {
            set_transient('alegra_batch_state', $state, 600);
        }

        // Cierre + release ANTES del send (die() no corre finally).
        \Alegra\Connector\Sync\Controller::release_sync_lock_public($type, $lock);

        // T3.4: el payload expone `images` con `failed` siempre presente (la
        // fuente canónica del acumulado es `$state['images']`; el merge de
        // `image_stats()` es T5.2b).
        $images = is_array($state['images'] ?? null)
            ? $state['images']
            : ['ok' => 0, 'blocked' => 0, 'download' => 0, 'sideload' => 0, 'deferred' => 0];
        if (!isset($images['failed'])) {
            $images['failed'] = (int) ($images['blocked'] ?? 0) + (int) ($images['download'] ?? 0) + (int) ($images['sideload'] ?? 0);
        }

        wp_send_json_success([
            'page'        => (int) floor(($state['start'] ?? 0) / $per_page) + 1,
            'total_pages' => $tp,
            'total_items' => $total_items,
            'imported'    => (int) $state['imported'],
            'updated'     => (int) $state['updated'],
            'skipped'     => (int) ($state['skipped'] ?? 0),
            'errors'      => (int) $state['errors'],
            'processed'   => $processed,
            'percent'     => $pct,
            'paused'      => $paused,
            'offset'      => (int) ($state['offset'] ?? 0),
            'done'        => $done,
            'images'      => $images,
            'message'     => sprintf(
                __('%1$d/%2$d items — Pág. %3$d/%4$d', 'alegra-connector'),
                $processed, $total_items,
                (int) floor(($state['start'] ?? 0) / $per_page) + 1, $tp
            ),
        ]);
        } catch (\Throwable $e) {
            // Solo excepciones reales. En el harness también atrapa el throw de
            // wp_send_json_*; Run_Context::finish (T1.5) no re-finaliza si ya cerró.
            \Alegra\Connector\Run_Context::finish($run_id, 'failed', $e->getMessage());
            throw $e;
        } finally {
            // Solo para excepciones: los sends ya liberaron antes.
            \Alegra\Connector\Sync\Controller::release_sync_lock_public($type, $lock);
        }
    }

    /**
     * List Alegra item categories for the product-import filter modal.
     *
     * Paginated with `start`/`limit` (max 30 per the documented endpoint,
     * https://developer.alegra.com/reference/get_item-categories). Walks up to
     * 10 pages and reports whether more remain.
     */
    public function ajax_get_item_categories(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(['message' => __('No tienes permisos.', 'alegra-connector')]);
        }

        if (!get_option('alegra_connector_connection_tested')) {
            wp_send_json_error(['message' => __('Conecta primero con Alegra.', 'alegra-connector')]);
        }

        $this->api->reload_credentials();

        $categories = [];
        $start = 0;
        $per_page = 30;
        $has_more = false;

        for ($page = 0; $page < 10; $page++) {
            $batch = $this->api->get_item_categories(['start' => $start, 'limit' => $per_page]);
            if (is_wp_error($batch)) {
                if ($page === 0) {
                    wp_send_json_error(['message' => sprintf(__('Error de Alegra: %s', 'alegra-connector'), $batch->get_error_message())]);
                }
                break;
            }
            if (empty($batch)) {
                break;
            }
            foreach ($batch as $category) {
                if (!is_array($category) || empty($category['id'])) {
                    continue;
                }
                $categories[] = [
                    'id'   => (string) $category['id'],
                    'name' => (string) ($category['name'] ?? ''),
                ];
            }
            if (count($batch) < $per_page) {
                break;
            }
            $start += $per_page;
            // A full page on the last allowed iteration means more remain.
            if ($page === 9) {
                $has_more = true;
            }
        }

        wp_send_json_success([
            'categories' => $categories,
            'has_more'   => $has_more,
        ]);
    }

    public function ajax_import_csv(): void
    {
        check_ajax_referer('alegra_connector_nonce');

        // The import creates PUBLISHED products, so it needs a shop-management
        // capability — `upload_files` is held by Authors (AC-33).
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(['message' => __('No tienes permisos.', 'alegra-connector')]);
        }

        if (!isset($_FILES['csv_file'])) {
            wp_send_json_error(['message' => __('No se encontró el archivo CSV.', 'alegra-connector')]);
        }

        $file = $_FILES['csv_file'];

        if ($file['error'] !== UPLOAD_ERR_OK) {
            wp_send_json_error(['message' => __('Error al subir archivo.', 'alegra-connector')]);
        }

        $import_type = sanitize_text_field($_POST['import_type'] ?? 'products');

        $result = $this->process_csv_import($file['tmp_name'], $import_type);

        if (is_wp_error($result)) {
            wp_send_json_error(['message' => sprintf(__('Error de Alegra: %s', 'alegra-connector'), $result->get_error_message())]);
        }

        wp_send_json_success([
            'message' => sprintf(__('Importación completada: %d items', 'alegra-connector'), $result['count']),
            'data' => $result,
        ]);
    }

    public function ajax_clear_logs(): void
    {
        check_ajax_referer('alegra_connector_nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('No tienes permisos.', 'alegra-connector')]);
        }

        if ($this->logger === null) {
            wp_send_json_error(['message' => __('Logger no inicializado.', 'alegra-connector')]);
        }

        $res = $this->logger->clear_all_logs();

        wp_send_json_success([
            'message' => sprintf(
                /* translators: %s: number of deleted log files */
                _n('%s archivo de log eliminado.', '%s archivos de log eliminados.', $res['files'], 'alegra-connector'),
                number_format_i18n($res['files'])
            ),
            'files' => $res['files'],
            'bytes' => $res['bytes'],
        ]);
    }

    public function ajax_download_logs(): void
    {
        check_ajax_referer('alegra_connector_nonce');

        if (!current_user_can('manage_options')) {
            wp_die(esc_html__('No tienes permisos.', 'alegra-connector'));
        }

        $log_file = sanitize_text_field($_GET['log_file'] ?? '');
        $this->logger->download_log($log_file);
    }

    public function ajax_save_mapping(): void
    {
        check_ajax_referer('alegra_connector_nonce');

        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(['message' => __('No tienes permisos.', 'alegra-connector')]);
        }

        $field_mapping = isset($_POST['field_mapping']) ? (array) $_POST['field_mapping'] : [];
        $tax_mapping = isset($_POST['tax_mapping']) ? (array) $_POST['tax_mapping'] : [];

        // AC-81: these arrays can grow with configuration; keep them out of the
        // autoloaded `alloptions` payload (3rd arg = autoload 'no').
        update_option('alegra_connector_field_mapping', map_deep($field_mapping, 'sanitize_text_field'), false);
        update_option('alegra_connector_tax_mapping', map_deep($tax_mapping, 'sanitize_text_field'), false);

        $this->logger->info('Field mapping saved');

        wp_send_json_success(['message' => __('Mapeo guardado.', 'alegra-connector')]);
    }

    /**
     * AJAX: open a draft invoice in Alegra from the order detail page.
     *
     * Used when the merchant configured invoices as `draft` and now wants an
     * existing one to become an open/issued invoice (without recording a
     * payment). No-op when the invoice is already open.
     */
    /**
     * Human message for a write blocked by dry-run or the write gate. Callers
     * use it so the merchant learns WHY nothing reached Alegra.
     *
     * @param array<string, mixed> $result A Client write result.
     */
    private static function blocked_message(array $result): string
    {
        if (($result['reason'] ?? '') === 'kill_switch') {
            return __('El plugin está desconectado (kill switch activo): la operación NO se envió a Alegra.', 'alegra-connector');
        }
        if (API\Client::is_dry_run_response($result)) {
            return __('Modo de prueba activo: la operación NO se envió a Alegra.', 'alegra-connector');
        }
        return __('La configuración actual bloqueó la operación; no se envió a Alegra.', 'alegra-connector');
    }

    public function ajax_open_invoice(): void
    {
        \Alegra\Connector\Write_Gate::run_explicit(fn () => $this->ajax_open_invoice_impl());
    }

    private function ajax_open_invoice_impl(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(['message' => __('No tienes permisos.', 'alegra-connector')]);
        }

        $order_id = (int) ($_POST['order_id'] ?? 0);
        $order = $order_id > 0 ? wc_get_order($order_id) : false;
        if (!$order) {
            wp_send_json_error(['message' => __('Pedido no encontrado.', 'alegra-connector')]);
        }

        $alegra_invoice_id = (string) $order->get_meta('_alegra_invoice_id', true);
        if ($alegra_invoice_id === '') {
            wp_send_json_error(['message' => __('El pedido no tiene una factura de Alegra vinculada.', 'alegra-connector')]);
        }

        $orders_sync = new \Alegra\Connector\Sync\Orders($this->api, $this->logger);
        $result = $orders_sync->ensure_invoice_open($alegra_invoice_id);
        if (is_wp_error($result)) {
            wp_send_json_error(['message' => sprintf(__('Error de Alegra: %s', 'alegra-connector'), $result->get_error_message())]);
        }

        if (API\Client::write_was_blocked($result)) {
            wp_send_json_error([
                'message' => self::blocked_message($result),
                'blocked' => true,
                'reason'  => (string) ($result['reason'] ?? 'dry_run'),
            ]);
        }

        $status = (string) ($result['status'] ?? 'open');
        if ($status === 'draft') {
            // Alegra accepted the call but the invoice is still a draft.
            wp_send_json_error(['message' => __('Alegra no abrió la factura; sigue en borrador.', 'alegra-connector')]);
        }

        $orders_sync->persist_invoice_status($order, $result);

        $order->add_order_note(sprintf(
            /* translators: %s: Alegra invoice number or id */
            __('[Alegra] Factura #%s abierta (ya no es borrador).', 'alegra-connector'),
            (string) $order->get_meta('_alegra_invoice_number', true) ?: $alegra_invoice_id
        ));

        wp_send_json_success([
            'message' => __('Factura abierta en Alegra.', 'alegra-connector'),
            'status'  => $status,
        ]);
    }

    public function ajax_record_payment(): void
    {
        \Alegra\Connector\Write_Gate::run_explicit(fn () => $this->ajax_record_payment_impl());
    }

    private function ajax_record_payment_impl(): void
    {
        check_ajax_referer('alegra_connector_nonce');

        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(['message' => __('No tienes permisos.', 'alegra-connector')]);
        }

        $order_id = (int) ($_POST['order_id'] ?? 0);
        if ($order_id <= 0) {
            wp_send_json_error(['message' => __('ID de pedido inválido.', 'alegra-connector')]);
        }

        $order = wc_get_order($order_id);
        if (!$order) {
            wp_send_json_error(['message' => __('Pedido no encontrado.', 'alegra-connector')]);
        }

        $alegra_invoice_id = (string) $order->get_meta('_alegra_invoice_id', true);
        if ($alegra_invoice_id === '' || $alegra_invoice_id === null) {
            wp_send_json_error(['message' => __('Primero crea la factura en Alegra.', 'alegra-connector')]);
        }

        // Check if payment already recorded
        $existing_payment = (string) $order->get_meta('_alegra_payment_id', true);
        if ($existing_payment !== '' && $existing_payment !== null) {
            wp_send_json_error(['message' => __('El pago ya está registrado en Alegra.', 'alegra-connector')]);
        }

        $account_id = (string) get_option('alegra_connector_payment_account_id', '');
        if ($account_id === '' || $account_id === '0') {
            wp_send_json_error(['message' => __('Configura una cuenta bancaria en Ajustes > Avanzado.', 'alegra-connector')]);
        }

        $orders_sync = new \Alegra\Connector\Sync\Orders($this->api, $this->logger);

        // A payment requires an OPEN invoice. This is an explicit MANUAL action
        // ("Registrar pago"), so opening a draft here is the merchant's own
        // decision — the automatic reconciliation never does it (BUG: the cron
        // used to open drafts). Record the state change on the order so it is
        // never silent.
        $was_draft = (string) $order->get_meta('_alegra_invoice_status', true) === 'draft';
        $opened = $orders_sync->ensure_invoice_open($alegra_invoice_id);
        if (!is_wp_error($opened)) {
            $orders_sync->persist_invoice_status($order, $opened);
            if ($was_draft && (string) ($opened['status'] ?? '') !== 'draft') {
                $order->add_order_note(__(
                    '[Alegra] La factura estaba en borrador y se abrió al registrar el pago (acción manual del administrador).',
                    'alegra-connector'
                ));
            }
        }

        $payment_data = [
            'date' => $order->get_date_paid() ? $order->get_date_paid()->date('Y-m-d') : date('Y-m-d'),
            'bankAccount' => ['id' => $account_id],
            'invoices' => [
                [
                    'id' => $alegra_invoice_id,
                    'amount' => (float) $order->get_total(),
                ],
            ],
            'paymentMethod' => $orders_sync->getPaymentMethodForGateway($order->get_payment_method()),
        ];

        $result = $this->api->create_payment($payment_data);

        if (is_wp_error($result)) {
            $this->logger->error('Payment recording failed', [
                'order_id' => $order_id,
                'error' => sprintf(__('Error de Alegra: %s', 'alegra-connector'), $result->get_error_message()),
            ]);
            wp_send_json_error(['message' => sprintf(__('Error de Alegra: %s', 'alegra-connector'), $result->get_error_message())]);
        }

        // Dry Run: the payment was NOT recorded. Do not save an empty payment id,
        // do not add a success note, and tell the UI explicitly.
        if (API\Client::is_dry_run_response($result)) {
            $this->logger->warning('Payment recording skipped (dry run)', [
                'order_id'   => $order_id,
                'invoice_id' => $alegra_invoice_id,
            ]);
            wp_send_json_success([
                'dry_run' => true,
                'message' => __('Modo de prueba activo: el pago NO se registró en Alegra.', 'alegra-connector'),
            ]);
        }

        // Write Gate (kill switch / entity disabled): the payment was NOT
        // recorded. Report the real reason instead of a fake success.
        if (API\Client::is_gate_blocked_response($result)) {
            $this->logger->warning('Payment recording blocked by write gate', [
                'order_id'   => $order_id,
                'invoice_id' => $alegra_invoice_id,
                'reason'     => $result['reason'] ?? 'unknown',
            ]);
            wp_send_json_error([
                'message' => self::blocked_message($result),
                'blocked' => true,
                'reason'  => (string) ($result['reason'] ?? 'unknown'),
            ]);
        }

        // Alegra payment ids are UUID strings.
        $payment_id = (string) ($result['id'] ?? '');
        $order->update_meta_data('_alegra_payment_id', $payment_id);
        if (!empty($result['number'])) {
            $order->update_meta_data('_alegra_payment_number', $result['number']);
        }
        $order->save();

        $order->add_order_note(sprintf(
            __('Pago Alegra #%s registrado.', 'alegra-connector'),
            $result['number'] ?? $payment_id
        ));

        $this->logger->info('Payment recorded in Alegra', [
            'order_id' => $order_id,
            'payment_id' => $payment_id,
            'invoice_id' => $alegra_invoice_id,
        ]);

        wp_send_json_success([
            'message' => __('Pago registrado en Alegra.', 'alegra-connector'),
            'payment_id' => $payment_id,
        ]);
    }

    /**
     * AJAX: emit a credit note for a refund from the order detail page.
     *
     * Phase 3 made `push_orders_enabled=false` (manual mode) block the
     * AUTOMATIC credit note on `woocommerce_order_refunded`. That is correct,
     * but without this action a merchant in manual mode had no way to emit the
     * credit note at all. This is the explicit path: the merchant asks for it,
     * so it runs inside Write_Gate::run_explicit() and the entity gate lets the
     * write through (the kill switch still blocks it).
     *
     * Idempotent: it reuses State_Sync::handle_refund() and its per-refund
     * `_alegra_credit_note_id_for_<refund>` marker, so a second click does not
     * duplicate the credit note.
     */
    public function ajax_emit_credit_note(): void
    {
        \Alegra\Connector\Write_Gate::run_explicit(fn () => $this->ajax_emit_credit_note_impl());
    }

    private function ajax_emit_credit_note_impl(): void
    {
        check_ajax_referer('alegra_connector_nonce');

        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(['message' => __('No tienes permisos.', 'alegra-connector')]);
        }

        $order_id = (int) ($_POST['order_id'] ?? 0);
        if ($order_id <= 0) {
            wp_send_json_error(['message' => __('ID de pedido inválido.', 'alegra-connector')]);
        }

        $order = wc_get_order($order_id);
        if (!$order instanceof \WC_Order) {
            wp_send_json_error(['message' => __('Pedido no encontrado.', 'alegra-connector')]);
        }

        $invoice_id = (string) $order->get_meta('_alegra_invoice_id', true);
        if ($invoice_id === '') {
            wp_send_json_error(['message' => __('El pedido no tiene una factura de Alegra vinculada. Primero crea la factura.', 'alegra-connector')]);
        }

        // A credit note requires an ISSUED invoice. Alegra rejects (or the
        // credit note is meaningless against) a draft, so tell the merchant to
        // open it first instead of failing with a raw API error.
        if ($this->api) {
            $invoice = $this->api->get_invoice($invoice_id);
            if (!is_wp_error($invoice) && is_array($invoice) && (string) ($invoice['status'] ?? '') === 'draft') {
                wp_send_json_error(['message' => __('La factura está en borrador. Ábrela en Alegra antes de emitir la nota de crédito.', 'alegra-connector')]);
            }
        }

        // Resolve the refund to credit: an explicit id, else the first refund
        // that has not been credited yet (per-refund idempotency marker).
        $refund_id = (int) ($_POST['refund_id'] ?? 0);
        $refunds = $order->get_refunds();
        if ($refund_id <= 0) {
            foreach ($refunds as $refund) {
                if (!$refund instanceof \WC_Order_Refund) {
                    continue;
                }
                $candidate = (int) $refund->get_id();
                if ($candidate > 0 && (string) $order->get_meta(sprintf(\Alegra\Connector\State_Sync::REFUND_META_FMT, $candidate), true) === '') {
                    $refund_id = $candidate;
                    break;
                }
            }
        }

        if ($refund_id <= 0 && $refunds !== []) {
            // Every refund already carries a credit note: idempotent no-op.
            wp_send_json_success([
                'message' => __('Ya se emitió una nota de crédito para este reembolso; no se duplicó.', 'alegra-connector'),
                'already_exists' => true,
            ]);
        }

        if ($refund_id > 0) {
            $result = \Alegra\Connector\State_Sync::handle_refund($order_id, $refund_id);
        } else {
            // No WC refund object (e.g. the amount was credited manually): credit
            // whatever remains uncredited on the order.
            $orders_sync = new \Alegra\Connector\Sync\Orders($this->api, $this->logger);
            $result = $orders_sync->create_credit_note($order);
        }

        if (is_wp_error($result)) {
            $this->logger->error('Credit note emission failed', [
                'order_id'  => $order_id,
                'refund_id' => $refund_id,
                'error'     => $result->get_error_message(),
            ]);
            wp_send_json_error(['message' => sprintf(__('Error de Alegra: %s', 'alegra-connector'), $result->get_error_message())]);
        }

        // Idempotency: handle_refund() short-circuits when the refund was
        // already credited. Report it as a success (nothing was duplicated).
        if (!empty($result['already_exists'])) {
            wp_send_json_success([
                'message' => __('La nota de crédito ya estaba emitida; no se duplicó.', 'alegra-connector'),
                'already_exists' => true,
                'credit_note_id' => (string) ($result['id'] ?? ''),
            ]);
        }

        if (API\Client::is_dry_run_response($result)) {
            $this->logger->warning('Credit note emission skipped (dry run)', [
                'order_id'  => $order_id,
                'refund_id' => $refund_id,
            ]);
            wp_send_json_success([
                'dry_run' => true,
                'message' => __('Modo de prueba activo: la nota de crédito NO se envió a Alegra.', 'alegra-connector'),
            ]);
        }

        if (API\Client::is_gate_blocked_response($result)) {
            $this->logger->warning('Credit note emission blocked by write gate', [
                'order_id'  => $order_id,
                'refund_id' => $refund_id,
                'reason'    => $result['reason'] ?? 'unknown',
            ]);
            wp_send_json_error([
                'message' => self::blocked_message($result),
                'blocked' => true,
                'reason'  => (string) ($result['reason'] ?? 'unknown'),
            ]);
        }

        $credit_note_id = (string) ($result['id'] ?? '');
        wp_send_json_success([
            'message' => __('Nota de crédito emitida en Alegra.', 'alegra-connector'),
            'credit_note_id' => $credit_note_id,
        ]);
    }

    public function ajax_sync_single(): void
    {
        \Alegra\Connector\Write_Gate::run_explicit(fn () => $this->ajax_sync_single_impl());
    }

    private function ajax_sync_single_impl(): void
    {
        check_ajax_referer('alegra_connector_nonce');

        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(['message' => __('No tienes permisos.', 'alegra-connector')]);
        }

        $entity_type = sanitize_text_field($_POST['entity_type'] ?? '');
        $entity_id = (int) ($_POST['entity_id'] ?? 0);

        if ($entity_id <= 0) {
            wp_send_json_error(['message' => __('ID invalido.', 'alegra-connector')]);
        }

        $sync_controller = new \Alegra\Connector\Sync\Controller($this->api, $this->logger);

        switch ($entity_type) {
            case 'product': $result = $sync_controller->sync_entity('product', $entity_id, 'update'); break;
            case 'customer': $result = $sync_controller->sync_entity('customer', $entity_id, 'update'); break;
            // REQ-MAN-1: "Facturar" uses the payment-capable path. Whether a
            // payment is posted is decided by $order->is_paid() inside
            // create_invoice_with_payment(), not by this action.
            case 'order': $result = $sync_controller->sync_entity('order', $entity_id, 'complete'); break;
            default: wp_send_json_error(['message' => __('Tipo de entidad desconocido.', 'alegra-connector')]);
        }

        if (is_wp_error($result)) {
            wp_send_json_error(['message' => sprintf(__('Error de Alegra: %s', 'alegra-connector'), $result->get_error_message())]);
        }

        if (API\Client::write_was_blocked($result)) {
            wp_send_json_error([
                'message' => self::blocked_message($result),
                'blocked' => true,
                'reason'  => (string) ($result['reason'] ?? 'dry_run'),
            ]);
        }

        wp_send_json_success(['message' => __('Sincronización completada.', 'alegra-connector'), 'data' => $result]);
    }

    /**
     * Collect every exportable row for the given type, paginated to completion
     * (AC-64). The previous implementation silently capped at 500 rows.
     *
     * @return array<int, array<int, string>>
     */
    public static function collect_export_rows(string $type): array
    {
        $per_page = 500;
        $rows = [];

        if ($type === 'products') {
            $page = 1;
            while (true) {
                $products = wc_get_products([
                    'limit'  => $per_page,
                    'page'   => $page,
                    'status' => 'publish',
                ]);
                if (empty($products)) {
                    break;
                }
                foreach ($products as $p) {
                    $ai = (string) get_post_meta($p->get_id(), '_alegra_item_id', true);
                    $rows[] = array_map([self::class, 'csv_safe_cell'], [
                        $p->get_name(), $p->get_sku(), $p->get_price(), $p->get_stock_quantity(),
                        // UUID strings are never > 0 — compare to '' instead.
                        $p->get_type(), $ai !== '' ? $ai : '', $ai !== '' ? 'Sincronizado' : 'Pendiente',
                    ]);
                }
                if (count($products) < $per_page) {
                    break;
                }
                $page++;
            }
            return $rows;
        }

        $offset = 0;
        while (true) {
            $customers = get_users([
                'role'   => 'customer',
                'number' => $per_page,
                'offset' => $offset,
            ]);
            if (empty($customers)) {
                break;
            }
            foreach ($customers as $c) {
                $ai = (string) get_user_meta($c->ID, 'alegra_contact_id', true);
                $rows[] = array_map([self::class, 'csv_safe_cell'], [
                    $c->display_name, $c->user_email, get_user_meta($c->ID, 'billing_phone', true),
                    // UUID strings are never > 0 — compare to '' instead.
                    $ai !== '' ? $ai : '', $ai !== '' ? 'Sincronizado' : 'Pendiente',
                ]);
            }
            if (count($customers) < $per_page) {
                break;
            }
            $offset += $per_page;
        }

        return $rows;
    }

    public function ajax_export_csv(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) wp_die();

        $type = sanitize_text_field($_GET['export_type'] ?? 'products');
        $is_products = ($type === 'products');

        header('Content-Type: text/csv; charset=utf-8');
        header(
            'Content-Disposition: attachment; filename="'
            . ($is_products ? 'alegra-productos-' : 'alegra-clientes-') . date('Y-m-d') . '.csv"'
        );

        $out = fopen('php://output', 'w');
        if ($is_products) {
            fputcsv($out, ['name', 'sku', 'price', 'stock', 'type', 'alegra_id', 'sync_status']);
        } else {
            fputcsv($out, ['name', 'email', 'phone', 'alegra_id', 'sync_status']);
        }
        foreach (self::collect_export_rows($type) as $row) {
            fputcsv($out, $row);
        }
        fclose($out);
        exit;
    }

    public function ajax_bulk_sync(): void
    {
        \Alegra\Connector\Write_Gate::run_explicit(fn () => $this->ajax_bulk_sync_impl());
    }

    private function ajax_bulk_sync_impl(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) wp_send_json_error(['message' => __('No tienes permisos.', 'alegra-connector')]);

        $type = sanitize_text_field($_POST['entity_type'] ?? '');
        $ids = array_map('intval', (array) ($_POST['ids'] ?? []));
        if (empty($ids)) wp_send_json_error(['message' => __('Seleccióna al menos un elemento.', 'alegra-connector')]);

        $sync_controller = new \Alegra\Connector\Sync\Controller($this->api, $this->logger);
        $synced = 0; $errors = 0; $blocked = 0;

        foreach ($ids as $id) {
            // REQ-MAN-2: bulk "Facturar seleccionados" must also register the
            // payment of each paid order, so it uses the complete path too.
            $action = $type === 'order' ? 'complete' : 'update';
            $r = $sync_controller->sync_entity($type, $id, $action);
            if (is_wp_error($r)) {
                $errors++;
            } elseif (API\Client::write_was_blocked($r)) {
                $blocked++;
            } else {
                $synced++;
            }
        }

        if ($blocked > 0) {
            wp_send_json_error([
                'message' => __('La configuración bloqueó la sincronización; no se envió nada a Alegra.', 'alegra-connector'),
                'blocked' => $blocked,
                'synced'  => $synced,
                'errors'  => $errors,
            ]);
        }

        wp_send_json_success(['message' => sprintf(__('%d sincronizados, %d errores.', 'alegra-connector'), $synced, $errors)]);
    }

    public function ajax_import_single(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) wp_send_json_error(['message' => __('No tienes permisos.', 'alegra-connector')]);

        $type = sanitize_text_field($_POST['entity_type'] ?? '');
        $wc_id = (int) ($_POST['entity_id'] ?? 0);

        if ($wc_id <= 0) wp_send_json_error(['message' => __('ID invalido.', 'alegra-connector')]);

        if ($type === 'product') {
            $alegra_id = (string) get_post_meta($wc_id, '_alegra_item_id', true);
            if ($alegra_id === '' || $alegra_id === null) wp_send_json_error(['message' => __('Producto no vinculado a Alegra.', 'alegra-connector')]);
            $sync = new Sync\Products($this->api, $this->logger);
            $result = $sync->sync_single_item_by_alegra_id($alegra_id);
        } elseif ($type === 'customer') {
            $alegra_id = (string) get_user_meta($wc_id, 'alegra_contact_id', true);
            if ($alegra_id === '' || $alegra_id === null) wp_send_json_error(['message' => __('Cliente no vinculado a Alegra.', 'alegra-connector')]);
            $sync = new Sync\Customers($this->api, $this->logger);
            $result = $sync->sync_single_contact_by_alegra_id($alegra_id);
        } else {
            wp_send_json_error(['message' => __('Tipo desconocido.', 'alegra-connector')]);
        }

        if ($result === false) {
            wp_send_json_error(['message' => __('No se pudo importar desde Alegra.', 'alegra-connector')]);
        }

        wp_send_json_success(['message' => $result === 'updated' ? __('Actualizado desde Alegra.', 'alegra-connector') : __('Importado desde Alegra.', 'alegra-connector')]);
    }

    public function ajax_bulk_import(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) wp_send_json_error(['message' => __('No tienes permisos.', 'alegra-connector')]);

        $type = sanitize_text_field($_POST['entity_type'] ?? '');
        $ids = array_map('intval', (array) ($_POST['ids'] ?? []));
        if (empty($ids)) wp_send_json_error(['message' => __('Seleccióna al menos un elemento.', 'alegra-connector')]);

        $synced = 0; $errors = 0; $skipped = 0;

        foreach ($ids as $wc_id) {
            if ($type === 'product') {
                $alegra_id = (string) get_post_meta($wc_id, '_alegra_item_id', true);
                if ($alegra_id === '' || $alegra_id === null) { $skipped++; continue; }
                $sync = new Sync\Products($this->api, $this->logger);
                $r = $sync->sync_single_item_by_alegra_id($alegra_id);
            } elseif ($type === 'customer') {
                $alegra_id = (string) get_user_meta($wc_id, 'alegra_contact_id', true);
                if ($alegra_id === '' || $alegra_id === null) { $skipped++; continue; }
                $sync = new Sync\Customers($this->api, $this->logger);
                $r = $sync->sync_single_contact_by_alegra_id($alegra_id);
            } else {
                continue;
            }

            if ($r === false) $errors++;
            elseif ($r === 'skipped') $skipped++;
            else $synced++;
        }

        $msg = sprintf(__('%d actualizados, %d errores.', 'alegra-connector'), $synced, $errors);
        if ($skipped > 0) $msg .= ' ' . sprintf(__('%d omitidos (sin vincular).', 'alegra-connector'), $skipped);

        wp_send_json_success(['message' => $msg]);
    }

    /**
     * Delete users created with placeholder emails from a previous buggy version.
     * These users have @placeholder.local emails and no real Alegra contact.
     */
    public function ajax_cleanup_placeholders(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        // Calls wp_delete_user(): requires the capability to delete users (AC-33).
        if (!current_user_can('delete_users')) wp_send_json_error(['message' => __('No tienes permisos.', 'alegra-connector')]);

        global $wpdb;

        $user_ids = $wpdb->get_col(
            "SELECT ID FROM {$wpdb->users} WHERE user_email LIKE '%@placeholder.local'"
        );

        if (empty($user_ids)) {
            wp_send_json_success(['message' => __('No se encontraron usuarios con email placeholder para limpiar.', 'alegra-connector'), 'count' => 0]);
        }

        $count = 0;
        foreach ($user_ids as $uid) {
            $deleted = wp_delete_user((int) $uid);
            if ($deleted) $count++;
        }

        $this->log('info', 'Cleaned up placeholder customers', ['count' => $count]);

        wp_send_json_success([
            'message' => sprintf(__('%d usuarios placeholder eliminados.', 'alegra-connector'), $count),
            'count' => $count,
        ]);
    }

    /**
     * Cancel a running chunked sync by deleting the batch state transient.
     */
    public function ajax_cancel_sync(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) wp_send_json_error();

        // D1: leer el run_id ANTES de borrar el estado y cerrar la fila
        // `cancelled`. El JS aborta el request en vuelo, así que "la próxima
        // página lo cierra" NO alcanza: este handler es el dueño del cierre.
        $state  = get_transient('alegra_batch_state');
        $run_id = is_array($state) ? (int) ($state['run_id'] ?? 0) : 0;
        if ($run_id > 0) {
            \Alegra\Connector\Run_Context::finish($run_id, 'cancelled', 'Cancelado por el usuario');
        }

        set_transient('alegra_sync_cancelled', 1, 120);
        delete_transient('alegra_sync_progress');
        delete_transient('alegra_batch_state');
        wp_send_json_success(['message' => __('Sincronización cancelada', 'alegra-connector')]);
    }

    public function ajax_register_webhooks(): void
    {
        \Alegra\Connector\Write_Gate::run_explicit(fn () => $this->ajax_register_webhooks_impl());
    }

    private function ajax_register_webhooks_impl(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(['message' => __('No tienes permisos.', 'alegra-connector')]);
        }

        $secret = sanitize_text_field($_POST['webhook_secret'] ?? '');
        // The field is masked, so an empty value means "use the stored secret".
        if ($secret === '') {
            $secret = (string) get_option('alegra_connector_webhook_secret', '');
        }
        if (empty($secret)) {
            wp_send_json_error(['message' => __('Webhook Secret es requerido.', 'alegra-connector')]);
        }

        update_option('alegra_connector_webhook_secret', $secret);

        // Embed the shared secret in the URL: Alegra cannot sign deliveries, so
        // this is the only credential that can authenticate a delivery. The
        // Receiver enforces it with hash_equals().
        $webhook_url = \Alegra\Connector\Webhooks\Receiver::registration_url();

        // Register ONLY the events the merchant selected.
        //
        // The JS sends the live checkbox state in $_POST['webhook_selected_events']
        // so the merchant does not need to click "Guardar Cambios" first; that
        // state is allowlisted through the same sanitizer the settings form
        // uses, persisted to the option (so subsequent loads render the same
        // checkboxes), and then used as the registration set.
        //
        // When no live state is posted — e.g. an external caller / CLI
        // inspector — fall back to the stored option. An absent option still
        // means "all events", so an install that never opened the selector
        // keeps subscribing to every documented event (no behaviour change).
        $posted_selection = $_POST['webhook_selected_events'] ?? null;
        if (is_array($posted_selection)) {
            $selected = self::sanitize_webhook_selected_events($posted_selection);
            update_option(
                \Alegra\Connector\Webhooks\Receiver::EVENTS_OPTION,
                $selected,
                false
            );
        } else {
            $selected = \Alegra\Connector\Webhooks\Receiver::selected_events();
        }
        $deselected = array_values(array_diff(API\Client::get_webhook_events(), $selected));

        $created = [];
        $already = [];
        $errors = [];
        $deleted = [];
        $blocked = 0;

        foreach ($selected as $event) {
            $result = $this->api->create_webhook_subscription($event, $webhook_url);
            if (API\Client::write_was_blocked($result)) {
                // Kill switch / dry-run: nothing reached Alegra.
                $blocked++;
                continue;
            }
            if (is_wp_error($result)) {
                if (self::is_webhook_already_registered($result)) {
                    // Alegra answers 400 "Ya existe una suscripción con el
                    // mismo evento y URL" when the subscription is already
                    // there. Re-registering right after an update is the
                    // expected action, so this is success — not an error.
                    $already[] = $event;
                    continue;
                }
                $errors[] = $event . ': ' . $result->get_error_message();
                continue;
            }

            // Documented 200 shape (post_webhooks-subscriptions): the id is
            // nested at {message, subscription:{id,event,url}}. The old code
            // read $result['id'], so every success was counted as a failure.
            // Tolerate the flat shape too in case the API ever inlines it.
            $subscription = is_array($result) ? ($result['subscription'] ?? null) : null;
            $id = '';
            if (is_array($subscription) && !empty($subscription['id'])) {
                $id = (string) $subscription['id'];
            } elseif (is_array($result) && !empty($result['id'])) {
                $id = (string) $result['id'];
            }

            if ($id !== '') {
                $created[] = [
                    'id' => $id,
                    'event' => (string) ($subscription['event'] ?? $event),
                ];
            } else {
                $errors[] = $event . ': ' . __('respuesta sin id de suscripción', 'alegra-connector');
            }
        }

        // Unsubscribe the events the merchant deselected. Alegra has no
        // "delete by event", so resolve the id from GET /webhooks/subscriptions
        // and DELETE it. Only subscriptions pointing at OUR URL are touched, so
        // another integration's events are never removed. Best-effort: a failed
        // delete keeps its local entry so a later run can retry.
        $remote = !empty($deselected) ? $this->remote_webhook_subscriptions_by_event() : [];
        foreach ($deselected as $event) {
            $sub = $remote[$event] ?? null;
            if (!is_array($sub) || empty($sub['id'])) {
                // Not subscribed remotely (or the listing failed): nothing to
                // delete.
                continue;
            }
            if (!empty($sub['url']) && $sub['url'] !== $webhook_url) {
                // A different integration owns this event; leave it alone.
                continue;
            }
            $result = $this->api->delete_webhook_subscription((string) $sub['id']);
            if (API\Client::write_was_blocked($result)) {
                // Kill switch / dry-run: nothing reached Alegra.
                $blocked++;
                continue;
            }
            if (is_wp_error($result)) {
                $errors[] = $event . ': ' . $result->get_error_message();
                continue;
            }
            $deleted[] = $event;
        }

        // Persist every subscription we know about, not only the newly created
        // ones. The DELETE flow deletes by id, and a 400 "already exists"
        // carries no id, so dropping the previously stored entry would orphan
        // the remote subscription and make it impossible to remove. Then drop
        // the deselected events that are actually gone (deleted, or absent
        // remotely); a failed delete keeps its entry so a later run retries.
        $subscriptions = $this->merge_webhook_subscriptions($created, $already);
        $drop = $deleted;
        foreach ($deselected as $event) {
            if (!in_array($event, $deleted, true) && empty($remote[$event]['id'])) {
                $drop[] = $event;
            }
        }
        if (!empty($drop)) {
            $subscriptions = array_values(array_filter(
                $subscriptions,
                static fn($sub) => !in_array((string) ($sub['event'] ?? ''), $drop, true)
            ));
        }
        if (!empty($subscriptions) || !empty($drop) || !empty($created) || !empty($already)) {
            // AC-81: the subscription list grows with configuration; do not
            // autoload it on every request.
            update_option('alegra_connector_webhook_subscriptions', $subscriptions, false);
        }

        if ($blocked > 0 && count($created) === 0) {
            wp_send_json_error([
                'message' => __('La configuración bloqueó el registro de webhooks; no se envió nada a Alegra.', 'alegra-connector'),
                'blocked' => $blocked,
                'errores' => count($errors),
            ]);
        }

        $message = sprintf(
            __('%d webhooks registrados, %d ya existían, %d errores.', 'alegra-connector'),
            count($created),
            count($already),
            count($errors)
        );
        if (!empty($deleted)) {
            $message .= ' ' . sprintf(
                __('%d webhooks eliminados.', 'alegra-connector'),
                count($deleted)
            );
        }
        if (!empty($errors)) {
            $message .= ' ' . sprintf(__('Errores: %s', 'alegra-connector'), implode(', ', $errors));
        }

        wp_send_json_success([
            'message' => $message,
            'creados' => count($created),
            'ya_existian' => count($already),
            'eliminados' => count($deleted),
            'errores' => count($errors),
            'blocked' => $blocked,
        ]);
    }

    /**
     * Whether a create_webhook_subscription() failure is the documented
     * "already exists" response.
     *
     * Matched NARROWLY against the documented Spanish message
     * (post_webhooks-subscriptions, 400 existingSubscription) so a genuine
     * failure — invalid URL, auth, 5xx — is never swallowed. The check is
     * accent-safe by matching only the unaccented prefix of the phrase.
     */
    private static function is_webhook_already_registered(\WP_Error $error): bool
    {
        if (stripos($error->get_error_message(), 'ya existe una suscripci') === false) {
            return false;
        }

        $data = $error->get_error_data();
        $code = is_array($data) ? (int) ($data['code'] ?? 0) : 0;
        return $code === 0 || $code === 400;
    }

    /**
     * Build the local subscription list from this run's registrations plus the
     * ones already stored, keyed by event so a partial re-register never drops
     * an id the DELETE flow needs.
     *
     * The id of an "already exists" subscription is recovered from the API
     * listing (GET /webhooks/subscriptions) when it is unknown locally.
     *
     * @param array<int, array{id:string, event:string}> $created
     * @param array<int, string>                          $already
     * @return array<int, array{id:string, event:string}>
     */
    private function merge_webhook_subscriptions(array $created, array $already): array
    {
        $by_event = [];
        foreach ((array) get_option('alegra_connector_webhook_subscriptions', []) as $sub) {
            if (is_array($sub) && !empty($sub['event'])) {
                $by_event[(string) $sub['event']] = $sub;
            }
        }
        foreach ($created as $sub) {
            $by_event[(string) $sub['event']] = $sub;
        }

        $unknown = array_filter($already, static fn($event) => empty($by_event[$event]['id']));
        if (!empty($unknown)) {
            $remote = $this->remote_webhook_ids_by_event();
            foreach ($unknown as $event) {
                if (!empty($remote[$event])) {
                    $by_event[$event] = ['id' => $remote[$event], 'event' => $event];
                }
            }
        }

        return array_values($by_event);
    }

    /**
     * Remote subscription ids keyed by event. Best-effort: any failure (or an
     * unexpected shape) yields an empty map rather than aborting registration.
     *
     * @return array<string, string>
     */
    private function remote_webhook_ids_by_event(): array
    {
        $map = [];
        foreach ($this->remote_webhook_subscriptions_by_event() as $event => $sub) {
            $map[$event] = $sub['id'];
        }
        return $map;
    }

    /**
     * Remote subscriptions keyed by event, each with id, event and url.
     * Best-effort: any failure (or an unexpected shape) yields an empty map
     * rather than aborting registration. The url lets the caller avoid
     * deleting a subscription that belongs to another integration.
     *
     * @return array<string, array{id:string, event:string, url:string}>
     */
    private function remote_webhook_subscriptions_by_event(): array
    {
        $result = $this->api->get_webhook_subscriptions();
        if (is_wp_error($result) || !is_array($result)) {
            return [];
        }

        $list = $result['subscriptions'] ?? (isset($result[0]) && is_array($result[0]) ? $result : []);
        $map = [];
        foreach ((array) $list as $sub) {
            if (is_array($sub) && !empty($sub['id']) && !empty($sub['event'])) {
                $map[(string) $sub['event']] = [
                    'id' => (string) $sub['id'],
                    'event' => (string) $sub['event'],
                    'url' => (string) ($sub['url'] ?? ''),
                ];
            }
        }
        return $map;
    }

    public function ajax_delete_webhooks(): void
    {
        \Alegra\Connector\Write_Gate::run_explicit(fn () => $this->ajax_delete_webhooks_impl());
    }

    private function ajax_delete_webhooks_impl(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(['message' => __('No tienes permisos.', 'alegra-connector')]);
        }

        $subscriptions = (array) get_option('alegra_connector_webhook_subscriptions', []);
        $deleted = 0;
        $errors = [];
        $remaining = [];
        $dry_run_skipped = 0;
        $gate_blocked = 0;

        foreach ($subscriptions as $sub) {
            $id = $sub['id'] ?? '';
            if (empty($id)) {
                $remaining[] = $sub;
                continue;
            }
            $result = $this->api->delete_webhook_subscription((string) $id);
            if (is_wp_error($result)) {
                $errors[] = $sub['event'] . ': ' . $result->get_error_message();
                $remaining[] = $sub;
            } elseif (API\Client::is_gate_blocked_response($result)) {
                // Write Gate: nothing was deleted in Alegra; keep it locally.
                $gate_blocked++;
                $remaining[] = $sub;
            } elseif (API\Client::is_dry_run_response($result)) {
                // Dry Run: nothing was deleted in Alegra; keep it locally.
                $dry_run_skipped++;
                $remaining[] = $sub;
            } else {
                $deleted++;
            }
        }

        if ($gate_blocked > 0 && $deleted === 0) {
            wp_send_json_error([
                'message' => __('La configuración bloqueó la eliminación de webhooks; no se envió nada a Alegra.', 'alegra-connector'),
                'blocked' => true,
                'reason'  => 'kill_switch',
                'deleted' => $deleted,
            ]);
        }

        // Only drop the subscriptions that were ACTUALLY deleted.
        if (!empty($remaining)) {
            update_option('alegra_connector_webhook_subscriptions', $remaining, false);
        } else {
            delete_option('alegra_connector_webhook_subscriptions');
        }

        if ($dry_run_skipped > 0) {
            wp_send_json_success([
                'dry_run' => true,
                'message' => __('Modo de prueba activo: no se eliminó ningún webhook en Alegra.', 'alegra-connector'),
                'deleted' => $deleted,
            ]);
        }

        $message = sprintf(__('%d webhooks eliminados.', 'alegra-connector'), $deleted);
        if (!empty($errors)) {
            $message .= ' ' . sprintf(__('Errores: %s', 'alegra-connector'), implode(', ', $errors));
        }

        wp_send_json_success(['message' => $message, 'deleted' => $deleted]);
    }

    public function ajax_sync_pending_orders(): void
    {
        \Alegra\Connector\Write_Gate::run_explicit(fn () => $this->ajax_sync_pending_orders_impl());
    }

    private function ajax_sync_pending_orders_impl(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) wp_send_json_error(['message' => __('No tienes permisos.', 'alegra-connector')]);

        @set_time_limit(120);
        wp_raise_memory_limit();

        $orders_sync = new Sync\Orders($this->api, $this->logger);
        $result = $orders_sync->sync_recent(30);

        if (is_wp_error($result)) {
            wp_send_json_error(['message' => $result->get_error_message()]);
        }

        $synced = (int) ($result['synced'] ?? 0);
        $errors = (int) ($result['errors'] ?? 0);

        wp_send_json_success([
            'message' => sprintf(__('%d facturas creadas, %d errores.', 'alegra-connector'), $synced, $errors),
            'synced' => $synced, 'errors' => $errors,
        ]);
    }

    public function ajax_sync_pending_start(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) wp_send_json_error();

        $orders = wc_get_orders([
            'limit' => 100,
            'status' => ['processing', 'completed', 'on-hold'],
            'return' => 'ids',
        ]);

        $pending = [];
        foreach ($orders as $oid) {
            // AC-34: read order meta through the CRUD API. get_post_meta() is
            // empty under HPOS, so every order was classified "pending".
            $order = wc_get_order($oid);
            if (!$order instanceof \WC_Order) {
                continue;
            }
            if ((string) $order->get_meta('_alegra_invoice_id', true) === '') {
                $pending[] = (int) $oid;
            }
        }

        $state = [
            'order_ids' => $pending,
            'total' => count($pending),
            'processed' => 0,
            'synced' => 0,
            'errors' => 0,
        ];
        set_transient('alegra_pending_invoice_batch', $state, 600);

        wp_send_json_success(['total' => count($pending)]);
    }

    public function ajax_sync_pending_page(): void
    {
        \Alegra\Connector\Write_Gate::run_explicit(fn () => $this->ajax_sync_pending_page_impl());
    }

    private function ajax_sync_pending_page_impl(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) wp_send_json_error();

        @set_time_limit(60);
        wp_raise_memory_limit();

        $state = get_transient('alegra_pending_invoice_batch');
        if (!$state || empty($state['order_ids'])) {
            delete_transient('alegra_pending_invoice_batch');
            wp_send_json_error(['message' => __('No hay pedidos pendientes', 'alegra-connector')]);
        }

        // REQ-RB-2: stop the chunked invoicing in the next batch when the
        // merchant cancelled. `ajax_cancel_sync` does not clear this state, so
        // the flag is the only signal here.
        if (get_transient('alegra_sync_cancelled')) {
            delete_transient('alegra_sync_progress');
            delete_transient('alegra_pending_invoice_batch');
            wp_send_json_success([
                'done'      => true,
                'cancelled' => true,
                'message'   => __('Sincronización cancelada.', 'alegra-connector'),
            ]);
        }

        $orders_sync = new Sync\Orders($this->api, $this->logger);
        $batch = array_splice($state['order_ids'], 0, 10);

        $blocked = 0;
        foreach ($batch as $oid) {
            $order = wc_get_order($oid);
            if (!$order) { $state['errors']++; continue; }
            $result = $orders_sync->create_invoice_with_payment($order);
            if (is_wp_error($result)) {
                $state['errors']++;
            } elseif (API\Client::write_was_blocked($result)) {
                $blocked++;
            } else {
                $state['synced']++;
            }
            $state['processed']++;
        }

        if ($blocked > 0 && $state['synced'] === 0) {
            delete_transient('alegra_pending_invoice_batch');
            wp_send_json_error([
                'message' => __('La configuración bloqueó la facturación; no se envió nada a Alegra.', 'alegra-connector'),
                'blocked' => true,
                'reason'  => 'kill_switch',
            ]);
        }

        $done = empty($state['order_ids']);
        if ($done) {
            delete_transient('alegra_pending_invoice_batch');
        } else {
            set_transient('alegra_pending_invoice_batch', $state, 600);
        }

        $pct = $state['total'] > 0 ? min(100, round(($state['processed'] / $state['total']) * 100)) : 0;
        wp_send_json_success([
            'processed' => $state['processed'],
            'total' => $state['total'],
            'synced' => $state['synced'],
            'errors' => $state['errors'],
            'percent' => $pct,
            'done' => $done,
            'message' => sprintf(__('%d/%d facturas — %d ok, %d errores', 'alegra-connector'), $state['processed'], $state['total'], $state['synced'], $state['errors']),
        ]);
    }

    public function ajax_get_invoice_pdf(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) wp_die();

        $order_id = (int) ($_GET['order_id'] ?? 0);
        if ($order_id <= 0) wp_die(__('Pedido invalido.', 'alegra-connector'));

        $order = wc_get_order($order_id);
        if (!$order) wp_die(__('Pedido invalido.', 'alegra-connector'));

        $alegra_invoice_id = (string) $order->get_meta('_alegra_invoice_id', true);
        if ($alegra_invoice_id === '' || $alegra_invoice_id === null) wp_die(__('Este pedido no tiene factura en Alegra.', 'alegra-connector'));

        $result = $this->api->get_invoice_pdf($alegra_invoice_id);
        if (is_wp_error($result)) wp_die(esc_html($result->get_error_message()));

        $pdf_url = $result['pdf'] ?? '';
        if (empty($pdf_url)) wp_die(__('No se pudo obtener el PDF de Alegra.', 'alegra-connector'));

        wp_redirect($pdf_url);
        exit;
    }

    public function ajax_disconnect(): void
    {
        \Alegra\Connector\Write_Gate::run_explicit(fn () => $this->ajax_disconnect_impl());
    }

    private function ajax_disconnect_impl(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        // Clears the whole integration config: admin-level (AC-33).
        if (!current_user_can('manage_options')) wp_send_json_error(['message' => __('No tienes permisos.', 'alegra-connector')]);

        // 1. Delete the webhook subscriptions in Alegra FIRST (REQ-RB-3). The old
        //    order activated the kill switch first, so the write gate blocked
        //    these DELETEs and the remote subscriptions were orphaned.
        $subscriptions = (array) get_option('alegra_connector_webhook_subscriptions', []);
        $deleted = 0;
        $blocked = 0;
        $simulated = 0;
        if ($this->api) {
            foreach ($subscriptions as $sub) {
                $id = (string) ($sub['id'] ?? '');
                if ($id === '') {
                    continue;
                }
                try {
                    $result = $this->api->delete_webhook_subscription($id);
                } catch (\Throwable $e) {
                    $this->log('warning', 'Failed to delete webhook subscription', [
                        'subscription_id' => $id,
                        'error' => $e->getMessage(),
                    ]);
                    continue;
                }

                // Count only what the API actually deleted. A dry-run or a
                // gate-blocked response means nothing reached Alegra.
                if (API\Client::is_gate_blocked_response($result)) {
                    $blocked++;
                } elseif (API\Client::is_dry_run_response($result)) {
                    $simulated++;
                } elseif (is_wp_error($result)) {
                    $this->log('warning', 'Failed to delete webhook subscription', [
                        'subscription_id' => $id,
                        'error' => $result->get_error_message(),
                    ]);
                } else {
                    $deleted++;
                }
            }
        }

        // 2. NOW activate the kill switch, after the cleanup reached Alegra.
        \Alegra\Connector\Kill_Switch::activate('user_disconnected');
        delete_option('alegra_connector_webhook_subscriptions');

        // 3. Clear ALL alegra_* transients (1 query, efficient)
        global $wpdb;
        $wpdb->query(
            "DELETE FROM {$wpdb->options}
             WHERE option_name LIKE '_transient_alegra\\_%'
             OR option_name LIKE '_transient_timeout_alegra\\_%'
             ESCAPE '\\\\'"
        );

        // 4. Clear ALL cron events with alegra prefix
        $cron_hooks = ['alegra_connector_cron_sync'];
        foreach ($cron_hooks as $hook) {
            wp_clear_scheduled_hook($hook);
        }

        // 5. Update visible options (PRESERVE credentials, mappings, config)
        update_option('alegra_connector_connection_tested', false);
        update_option('alegra_connector_company_name', '');
        update_option('alegra_connector_company_country', '');
        update_option('alegra_connector_company_email', '');
        // REQ-HYG-1: `alegra_connector_disconnected_at` was written here and
        // never read; the disconnection state is carried by Kill_Switch::reason()
        // / `alegra_connector_disconnected_reason`. Removed.

        $this->log('info', 'Disconnected from Alegra (kill switch active, all resources cleaned)', [
            'webhooks_deleted'   => $deleted,
            'webhooks_blocked'   => $blocked,
            'webhooks_simulated' => $simulated,
        ]);

        $cleaned = [
            'transients_cleared' => true,
            'cron_cleared'       => count($cron_hooks),
            'webhooks_deleted'   => $deleted,
            'webhooks_blocked'   => $blocked,
            'webhooks_simulated' => $simulated,
        ];

        // Already disconnected: the gate blocked every DELETE. Report the block
        // honestly instead of claiming the webhooks were removed (REQ-RB-3).
        if ($blocked > 0 && $deleted === 0 && $simulated === 0) {
            wp_send_json_error([
                'message'            => __('La configuración bloqueó la eliminación de webhooks; no se envió nada a Alegra.', 'alegra-connector'),
                'blocked'            => true,
                'reason'             => 'kill_switch',
                'webhooks_deleted'   => $deleted,
                'webhooks_simulated' => $simulated,
                'cleaned'            => $cleaned,
            ]);
        }

        // Dry-run: nothing reached Alegra; do not report the local count as deleted.
        if ($simulated > 0) {
            wp_send_json_success([
                'dry_run'            => true,
                'message'            => __('Modo de prueba activo: no se eliminó ningún webhook en Alegra.', 'alegra-connector'),
                'webhooks_deleted'   => $deleted,
                'webhooks_simulated' => $simulated,
                'cleaned'            => $cleaned,
            ]);
        }

        wp_send_json_success([
            'message'            => __('Desconectado de Alegra. Procesos detenidos, configuracion preservada.', 'alegra-connector'),
            'webhooks_deleted'   => $deleted,
            'webhooks_simulated' => $simulated,
            'cleaned'            => $cleaned,
        ]);
    }

    public function ajax_sync_progress(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) wp_send_json_error(['message' => __('No tienes permisos.', 'alegra-connector')]);
        $progress = get_transient('alegra_sync_progress');
        if ($progress === false) {
            wp_send_json_success(['done' => true, 'message' => '']);
        }
        wp_send_json_success($progress);
    }

    /**
     * AJAX: Get current monitor status (running processes, cron, history).
     */
    public function ajax_monitor_status(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) wp_send_json_error();

        $running = \Alegra\Connector\Runs::currently_running();
        // D10: pull a wider window and partition webhooks out, otherwise a busy
        // webhook stream evicts cron/manual runs from the history.
        $recent_all = \Alegra\Connector\Runs::recent(25);
        $cron_events = \Alegra\Connector\Runs::get_cron_events();
        $heartbeats = \Alegra\Connector\Heartbeat::get_batch(array_column((array) $running, 'id'));

        $running_data = [];
        foreach ($running as $run) {
            $hb = $heartbeats[(int) $run->id] ?? [];
            $running_data[] = [
                'id' => (int) $run->id,
                'type' => $run->run_type,
                'started_at' => $run->started_at,
                'started_by' => $run->started_by,
                'items_done' => (int) $run->items_done,
                'total_items' => (int) $run->total_items,
                'step' => $hb['step'] ?? '',
                'message' => $hb['message'] ?? '',
                'memory_mb' => isset($hb['memory_mb']) ? (float) $hb['memory_mb'] : null,
                'cpu_load' => isset($hb['cpu_load']) ? (float) $hb['cpu_load'] : null,
            ];
        }

        $recent = [];
        $recent_wh = [];
        foreach ($recent_all as $r) {
            if (strpos((string) $r->run_type, 'webhook') === 0) {
                if (count($recent_wh) < 5) { $recent_wh[] = $r; }
            } elseif (count($recent) < 15) {
                $recent[] = $r;
            }
        }

        $recent_data = [];
        foreach ($recent as $run) {
            $recent_data[] = [
                'id' => (int) $run->id,
                'type' => $run->run_type,
                'status' => $run->status,
                'started_at' => $run->started_at,
                'finished_at' => $run->finished_at,
                'items_done' => (int) $run->items_done,
                'total_items' => (int) $run->total_items,
                'items_failed' => (int) $run->items_failed,
                'memory_mb' => $run->memory_peak_mb ? (float) $run->memory_peak_mb : null,
                'error' => $run->error_summary,
            ];
        }

        $recent_wh_data = [];
        foreach ($recent_wh as $run) {
            $recent_wh_data[] = [
                'id' => (int) $run->id,
                'type' => $run->run_type,
                'status' => $run->status,
                'started_at' => $run->started_at,
                'finished_at' => $run->finished_at,
                'items_done' => (int) $run->items_done,
                'total_items' => (int) $run->total_items,
                'items_failed' => (int) $run->items_failed,
                'memory_mb' => $run->memory_peak_mb ? (float) $run->memory_peak_mb : null,
                'error' => $run->error_summary,
            ];
        }

        $cron_data = [];
        foreach ($cron_events as $ev) {
            $cron_data[] = [
                'hook' => $ev['hook'],
                'next_run' => $ev['next_run'],
                'next_run_human' => $ev['next_run_human'],
                'schedule' => $ev['schedule'],
            ];
        }

        wp_send_json_success([
            'running' => $running_data,
            'cron' => $cron_data,
            'recent' => $recent_data,
            'recent_webhooks' => $recent_wh_data,
            'sync_method' => (string) get_option('alegra_connector_sync_method', 'cron'),
            'kill_switch_active' => \Alegra\Connector\Kill_Switch::is_active(),
            'kill_switch_reason' => \Alegra\Connector\Kill_Switch::reason(),
        ]);
    }

    /**
     * AJAX: Request a running process to stop.
     */
    public function ajax_kill_run(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) wp_send_json_error();

        $run_id = (int) ($_POST['run_id'] ?? 0);
        if ($run_id <= 0) wp_send_json_error(['message' => __('ID invalido.', 'alegra-connector')]);

        \Alegra\Connector\Runs::request_stop($run_id);

        // Do NOT clear the heartbeat: the run is still alive until the running flow
        // observes Runs::should_stop() and calls Run_Context::finish(). Clearing the
        // display here would make the live run disappear from the Monitor.
        $this->log('info', 'Run stop requested by user', ['run_id' => $run_id]);
        wp_send_json_success(['message' => __('El proceso se detendra en su siguiente verificacion.', 'alegra-connector')]);
    }

    /**
     * AJAX: Emergency stop - activate kill switch + clear all.
     */
    public function ajax_kill_all(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) wp_send_json_error();

        // Activate kill switch
        \Alegra\Connector\Kill_Switch::activate('emergency_stop');

        // Clear all batch transients
        global $wpdb;
        $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_alegra\\_%' OR option_name LIKE '_transient_timeout_alegra\\_%' ESCAPE '\\\\'");

        // Clear cron
        $cron_hooks = ['alegra_connector_cron_sync'];
        foreach ($cron_hooks as $hook) {
            wp_clear_scheduled_hook($hook);
        }

        // Mark all running as killed
        $wpdb->query("UPDATE {$wpdb->prefix}alegra_runs SET status = 'killed', finished_at = NOW() WHERE status = 'running'");

        $this->log('warning', 'Emergency stop activated by user');
        wp_send_json_success(['message' => __('Todos los procesos han sido detenidos. El plugin quedara desconectado.', 'alegra-connector')]);
    }

    /**
     * AJAX: Clear the kill switch (re-enable the plugin).
     *
     * Clears the kill switch transient and resets the per-request cache so
     * the dashboard immediately reflects the active state.
     */
    public function ajax_clear_kill_switch(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) wp_send_json_error();

        \Alegra\Connector\Kill_Switch::deactivate();
        \Alegra\Connector\Kill_Switch::reset_cache();

        $this->log('info', 'Kill switch cleared by user from dashboard');

        wp_send_json_success([
            'message' => __('Plugin reactivado. Las operaciones volveran a funcionar.', 'alegra-connector'),
        ]);
    }

    /**
     * AJAX: Wizard - advance to next step.
     */
    public function ajax_wizard_advance(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) wp_send_json_error();

        $step = (int) ($_POST['step'] ?? 1);
        $step = max(1, min(5, $step));
        update_user_meta(get_current_user_id(), 'alegra_wizard_step', $step);
        if ($step >= 5) {
            update_user_meta(get_current_user_id(), 'alegra_wizard_done', true);
        }
        wp_send_json_success();
    }

    /**
     * AJAX: Wizard - skip completely.
     */
    public function ajax_wizard_skip(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) wp_send_json_error();
        update_user_meta(get_current_user_id(), 'alegra_wizard_done', true);
        wp_send_json_success();
    }

    /**
     * AJAX: Run a cron hook immediately.
     *
     * Schedules a single event for the hook at the current timestamp and triggers
     * WP's cron spawn so the next request will execute it.
     */
    public function ajax_run_cron_now(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) wp_send_json_error();

        // AC-61: no unbounded execution-time override here. The hook is
        // scheduled as a one-off event, so this request only enqueues it — it
        // does not run the sync inline. The sync itself is bounded by the
        // import time budget and resumes from a cursor.
        $hook = sanitize_text_field($_POST['hook'] ?? '');
        if (empty($hook) || !preg_match('/^[a-zA-Z0-9_]+$/', $hook)) {
            wp_send_json_error(['message' => __('Hook invalido.', 'alegra-connector')]);
        }

        // AC-52: an explicit allowlist of this plugin's own cron hooks. A
        // `strpos($hook, 'alegra') === 0` prefix check is too loose ("alegrax"
        // matches), and the old manual-run recurrence was never registered.
        $allowed_hooks = ['alegra_connector_cron_sync'];
        if (!in_array($hook, $allowed_hooks, true)) {
            wp_send_json_error(['message' => __('Solo se permiten hooks de Alegra.', 'alegra-connector')]);
        }

        // REQ-CFG-5: do not queue a no-op. If the method is not periodic or the
        // kill switch is active, explain why the run cannot happen.
        $blocked = $this->sync_now_blocked_payload();
        if ($blocked !== null) {
            wp_send_json_error($blocked);
        }

        // Queue a ONE-OFF under a DEDICATED hook, then trigger WP's cron spawn
        // so the next request executes it. This never touches the recurring
        // event (the old wp_clear_scheduled_hook() removed it permanently), and
        // it dodges WP's 10-minute duplicate suppression that would otherwise
        // swallow a single event scheduled under the recurring hook itself.
        wp_schedule_single_event(time(), 'alegra_connector_cron_sync_now');
        spawn_cron();

        $this->log('info', 'Cron hook triggered manually', ['hook' => $hook]);

        wp_send_json_success([
            'message' => sprintf(
                __('Hook "%s" ejecutado. Revisa el Monitor en unos segundos para ver el progreso.', 'alegra-connector'),
                $hook
            ),
        ]);
    }

    /**
     * AJAX: Skip the next scheduled execution of a cron hook.
     *
     * Removes the next pending event(s) for the hook. If there are more events
     * scheduled in the future, those will remain. The plugin will reschedule
     * itself on the next run, so this effectively pushes the next run forward.
     */
    public function ajax_skip_cron_next(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) wp_send_json_error();

        $hook = sanitize_text_field($_POST['hook'] ?? '');
        if (empty($hook) || !preg_match('/^[a-zA-Z0-9_]+$/', $hook)) {
            wp_send_json_error(['message' => __('Hook invalido.', 'alegra-connector')]);
        }

        // "Skip" only makes sense for the periodic sync, whose interval we know.
        // Restricting the allowlist also stops a stray hook from being
        // rescheduled on the wrong cadence.
        if ($hook !== 'alegra_connector_cron_sync') {
            wp_send_json_error(['message' => __('Solo se puede saltar la sincronización periódica.', 'alegra-connector')]);
        }

        $timestamp = (int) ($_POST['timestamp'] ?? 0);
        if ($timestamp <= 0) {
            wp_send_json_error(['message' => __('Timestamp invalido.', 'alegra-connector')]);
        }

        // Move the next run forward — never delete the recurrence. WP only
        // regenerates a recurring event when it fires, so wp_unschedule_event()
        // on a future occurrence silently killed the periodic sync. Re-register
        // a fresh recurring event one interval from now instead.
        $frequency = (int) get_option('alegra_connector_sync_frequency', 15);
        if (!in_array($frequency, [5, 15, 30, 60], true)) {
            $frequency = 15;
        }
        $schedule_name = 'alegra_connector_' . $frequency . 'min';
        $next_run = time() + ($frequency * MINUTE_IN_SECONDS);

        wp_clear_scheduled_hook($hook);
        wp_schedule_event($next_run, $schedule_name, $hook);

        $this->log('info', 'Cron event skipped by user', ['hook' => $hook, 'timestamp' => $timestamp, 'next_run' => $next_run]);

        wp_send_json_success([
            'message' => sprintf(
                __('Proxima ejecucion de "%s" movida al siguiente ciclo.', 'alegra-connector'),
                $hook
            ),
        ]);
    }

    /**
     * AJAX: Remove ALL scheduled executions of a cron hook.
     *
     * This stops the cron entirely. Useful when the user wants to disable a
     * scheduled task permanently (the plugin will not auto-reschedule it
     * unless it re-registers the schedule elsewhere).
     */
    public function ajax_unschedule_cron(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) wp_send_json_error();

        $hook = sanitize_text_field($_POST['hook'] ?? '');
        if (empty($hook) || !preg_match('/^[a-zA-Z0-9_]+$/', $hook)) {
            wp_send_json_error(['message' => __('Hook invalido.', 'alegra-connector')]);
        }

        if (strpos($hook, 'alegra') !== 0) {
            wp_send_json_error(['message' => __('Solo se permiten hooks de Alegra.', 'alegra-connector')]);
        }

        $cleared = wp_clear_scheduled_hook($hook);
        if (function_exists('as_unschedule_all_actions')) {
            as_unschedule_all_actions($hook, [], 'alegra');
        }

        // Record the user's intent so the init self-heal does not resurrect a
        // schedule the merchant explicitly removed. schedule_cron() clears it.
        if ($hook === 'alegra_connector_cron_sync') {
            update_option('alegra_connector_cron_disabled', 1, false);
        }

        $this->log('info', 'Cron hook unscheduled by user', ['hook' => $hook, 'cleared' => $cleared]);

        wp_send_json_success([
            'message' => sprintf(
                __('Todas las programaciones de "%s" eliminadas.', 'alegra-connector'),
                $hook
            ),
        ]);
    }

    /**
     * AJAX: Change cron frequency (re-schedules with new interval).
     */
    public function ajax_change_cron_frequency(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) wp_send_json_error();

        $hook = sanitize_text_field($_POST['hook'] ?? '');
        $frequency = (int) ($_POST['frequency'] ?? 0);
        $allowed = [5, 15, 30, 60];

        if (empty($hook) || !preg_match('/^[a-zA-Z0-9_]+$/', $hook)) {
            wp_send_json_error(['message' => __('Hook invalido.', 'alegra-connector')]);
        }

        if (strpos($hook, 'alegra') !== 0) {
            wp_send_json_error(['message' => __('Solo se permiten hooks de Alegra.', 'alegra-connector')]);
        }

        if (!in_array($frequency, $allowed, true)) {
            wp_send_json_error(['message' => __('Frecuencia invalida. Use 5, 15, 30 o 60.', 'alegra-connector')]);
        }

        // Clear all existing schedules for this hook
        wp_clear_scheduled_hook($hook);

        // Schedule with new frequency
        $schedule_name = 'alegra_connector_' . $frequency . 'min';
        if (!wp_next_scheduled($hook)) {
            wp_schedule_event(time() + 60, $schedule_name, $hook);
        }

        // Update the option that drives schedule_cron(). update_option() itself
        // fires `update_option_alegra_connector_sync_frequency`, which
        // schedule_cron() is hooked to, so an explicit do_action() here
        // scheduled the cron a second time (AC-78).
        update_option('alegra_connector_sync_frequency', $frequency);

        $this->log('info', 'Cron frequency changed', ['hook' => $hook, 'frequency' => $frequency]);

        wp_send_json_success([
            'message' => sprintf(
                __('Frecuencia de "%s" cambiada a %d minutos.', 'alegra-connector'),
                $hook,
                $frequency
            ),
        ]);
    }

    public function ajax_check_endpoints(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) wp_send_json_error(['message' => __('No tienes permisos.', 'alegra-connector')]);

        // Force reload credentials from DB
        $this->api->reload_credentials();

        $endpoints = [];

        $items = $this->api->get_items(['limit' => 5]);
        $endpoints['items'] = is_wp_error($items) ? $items->get_error_message() : (is_array($items) && count($items) > 0 ? 'OK: ' . count($items) . ' items' : 'vacio');

        $contacts = $this->api->get_contacts(['limit' => 5]);
        $endpoints['contacts'] = is_wp_error($contacts) ? $contacts->get_error_message() : (is_array($contacts) && count($contacts) > 0 ? 'OK: ' . count($contacts) . ' contacts' : 'vacio');

        $invoices = $this->api->get_invoices(['limit' => 5]);
        $endpoints['invoices'] = is_wp_error($invoices) ? $invoices->get_error_message() : (is_array($invoices) && count($invoices) > 0 ? 'OK: ' . count($invoices) . ' invoices' : 'vacio');

        $taxes = $this->api->get_taxes();
        $endpoints['taxes'] = is_wp_error($taxes) ? $taxes->get_error_message() : (is_array($taxes) && count($taxes) > 0 ? 'OK: ' . count($taxes) . ' taxes' : 'vacio');

        $this->log('info', 'Endpoint check completed', $endpoints);

        wp_send_json_success(['endpoints' => $endpoints]);
    }

    public function ajax_import_from_api(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) wp_send_json_error(['message' => __('No tienes permisos.', 'alegra-connector')]);

        @set_time_limit(300);
        wp_raise_memory_limit();

        // REQ-LOG-01: salida temprana con rastro (sin fila: el run no existe aún).
        // K1: el run_type es el canónico `manual_import`, no el alias corto `manual`.
        if (!get_option('alegra_connector_connection_tested')) {
            \Alegra\Connector\Run_Context::fail_early('manual_import', 'connection_not_tested');
            wp_send_json_error(['message' => __('Conecta primero con Alegra.', 'alegra-connector')]);
        }

        $import_type = sanitize_text_field($_POST['import_type'] ?? '');
        if (!in_array($import_type, ['products', 'customers', 'categories'], true)) {
            \Alegra\Connector\Run_Context::fail_early('manual_import', 'invalid_type', ['import_type' => $import_type]);
            wp_send_json_error(['message' => __('Tipo de importacion invalido.', 'alegra-connector')]);
        }

        // D1 §2.2: el run se abre ANTES del lock para que el lock ocupado cierre
        // la fila con causa (REQ-MON-01 escenario borde).
        $run_id = \Alegra\Connector\Run_Context::begin('manual_import');

        // Lock the per-type sync so cron + this AJAX import can't both pull.
        // Customers::import_from_alegra has its own internal lock too; this
        // outer lock protects the Products and Categories code paths and
        // gives consistent UX (single error message) across all types.
        $lock = \Alegra\Connector\Sync\Controller::acquire_sync_lock_public($import_type);
        if ($lock === false) {
            \Alegra\Connector\Run_Context::finish($run_id, 'failed', 'Ya hay una sincronización en curso');
            wp_send_json_error(['message' => __('Another sync is in progress. Please wait.', 'alegra-connector')]);
        }
        try {
            $sync_controller = new \Alegra\Connector\Sync\Controller($this->api, $this->logger);
            $result = $sync_controller->import_from_alegra($import_type, $run_id);

            if (is_wp_error($result)) {
                $msg = sprintf(__('Error de Alegra: %s', 'alegra-connector'), $result->get_error_message());
                \Alegra\Connector\Run_Context::finish($run_id, 'failed', $result->get_error_message());
                \Alegra\Connector\Sync\Controller::release_sync_lock_public($import_type, $lock);
                wp_send_json_error(['message' => $msg]);
            }

            // K3 (Oracle D6 + H1): DOS señales distintas, no una.
            //  - stop del usuario (Monitor): Products.php:1298-1301 (por página)
            //    y :1353-1356 (por ítem) hacen `break`/`break 2` SIN tocar `paused`.
            //  - pausa por presupuesto de 240 s: Products.php:1304-1309 setea
            //    `$result['paused']=true`.
            if (\Alegra\Connector\Runs::should_stop($run_id)) {
                \Alegra\Connector\Run_Context::finish($run_id, 'cancelled', 'Detenido por el usuario');
                \Alegra\Connector\Sync\Controller::release_sync_lock_public($import_type, $lock);
                wp_send_json_success([
                    'message' => __('Importación detenida por el usuario.', 'alegra-connector'),
                    'data' => $result,
                    'images' => $result['images'] ?? [],
                ]);
            }

            // REQ-RES-04 (H1): la pausa por presupuesto se reporta como pausa
            // HONESTA (el cursor ya quedó persistido), NO como cancelación ni
            // como "Completado".
            if (!empty($result['paused'])) {
                \Alegra\Connector\Run_Context::finish($run_id, 'paused', 'Pausado por presupuesto; reanudable');
                \Alegra\Connector\Sync\Controller::release_sync_lock_public($import_type, $lock);
                wp_send_json_success([
                    'message' => sprintf(
                        __('Importación pausada por presupuesto: %1$d nuevos, %2$d actualizados. Reanudá para continuar.', 'alegra-connector'),
                        (int) ($result['imported'] ?? 0),
                        (int) ($result['updated'] ?? 0)
                    ),
                    'paused' => true,
                    'data' => $result,
                    'images' => $result['images'] ?? [],
                ]);
            }

            $imported = (int) ($result['imported'] ?? 0);
            $updated = (int) ($result['updated'] ?? 0);

            // D1 §2.3: cierre + release ANTES del send (die() no corre finally).
            \Alegra\Connector\Run_Context::finish($run_id, 'completed');
            \Alegra\Connector\Sync\Controller::release_sync_lock_public($import_type, $lock);

            wp_send_json_success([
                'message' => sprintf(__('Importación completada: %d nuevos, %d actualizados.', 'alegra-connector'), $imported, $updated),
                'data' => $result,
                'images' => $result['images'] ?? [],   // T5.2 (payload), placeholder tolerante
            ]);
        } catch (\Throwable $e) {
            // Solo excepciones reales: el run se cierra failed y el finally libera.
            \Alegra\Connector\Run_Context::finish($run_id, 'failed', $e->getMessage());
            throw $e;
        } finally {
            \Alegra\Connector\Sync\Controller::release_sync_lock_public($import_type, $lock);
        }
    }

    private function get_sync_stats(): array
    {
        global $wpdb;

        $product_count = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type='product' AND post_status='publish'"
        );

        $orders_table = HPOS::get_orders_table();
        if (HPOS::is_enabled()) {
            $order_count = (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$orders_table} WHERE type='shop_order' AND status IN ('wc-processing','wc-completed','wc-pending','wc-on-hold')"
            );
        } else {
            $order_count = (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type='shop_order' AND post_status IN ('wc-processing','wc-completed','wc-pending','wc-on-hold')"
            );
        }

        $user_count = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->users} u INNER JOIN {$wpdb->usermeta} um ON u.ID=um.user_id AND um.meta_key='{$wpdb->prefix}capabilities' WHERE um.meta_value LIKE '%customer%'"
        );

        $cat_count = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->term_taxonomy} WHERE taxonomy='product_cat'"
        );

        return [
            'products' => $product_count,
            'customers' => $user_count,
            'orders' => $order_count,
            'categories' => $cat_count,
        ];
    }

    private function process_csv_import(string $file_path, string $type): array|\WP_Error
    {
        if (!file_exists($file_path)) {
            return new \WP_Error('file_not_found', __('Archivo CSV no encontrado.', 'alegra-connector'));
        }

        $handle = fopen($file_path, 'r');
        if ($handle === false) {
            return new \WP_Error('cannot_open', __('No se pudo abrir el archivo.', 'alegra-connector'));
        }

        $count = 0;
        $errors = [];
        $headers = fgetcsv($handle);

        if ($headers === false) {
            fclose($handle);
            return new \WP_Error('invalid_csv', __('Archivo CSV inválido.', 'alegra-connector'));
        }

        $headers = array_map('trim', $headers);
        $line = 1;

        while (($row = fgetcsv($handle)) !== false) {
            $line++;

            if (count($row) !== count($headers)) {
                $errors[] = sprintf(
                    /* translators: %d: line number */
                    __('Línea %d: número de columnas no coincide con el encabezado.', 'alegra-connector'),
                    $line
                );
                continue;
            }

            $data = array_combine($headers, $row);
            if ($data === false) {
                $errors[] = sprintf(
                    /* translators: %d: line number */
                    __('Línea %d: error al procesar la fila.', 'alegra-connector'),
                    $line
                );
                continue;
            }

            if ($type === 'products') {
                $imported = $this->import_product_from_csv($data);
                if ($imported) {
                    $count++;
                } else {
                    $errors[] = sprintf(
                        /* translators: %d: line number */
                        __('Línea %d: no se pudo importar el producto.', 'alegra-connector'),
                        $line
                    );
                }
            }
        }

        fclose($handle);

        $this->logger->info('CSV import completed', [
            'type' => $type,
            'count' => $count,
            'errors' => count($errors),
        ]);

        return ['count' => $count, 'errors' => $errors];
    }

    private function import_product_from_csv(array $data): bool
    {
        $name = sanitize_text_field($data['name'] ?? '');
        if (empty($name)) {
            return false;
        }

        $product_id = wp_insert_post([
            'post_title' => $name,
            'post_content' => sanitize_text_field($data['description'] ?? ''),
            'post_type' => 'product',
            'post_status' => 'publish',
        ]);

        if (is_wp_error($product_id) || !$product_id) {
            return false;
        }

        $sku = sanitize_text_field($data['reference'] ?? '');
        $price = sanitize_text_field($data['price'] ?? '');

        if (!empty($sku)) {
            update_post_meta($product_id, '_sku', $sku);
        }
        if (!empty($price)) {
            update_post_meta($product_id, '_regular_price', $price);
            update_post_meta($product_id, '_price', $price);
        }

        return true;
    }

    /**
     * Clean up duplicate product images that were created before
     * the URL normalization fix was applied.
     */
    public function ajax_cleanup_duplicate_images(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        // Calls wp_delete_attachment(): requires the capability to delete posts (AC-33).
        if (!current_user_can('delete_posts')) {
            wp_send_json_error(['message' => __('No tienes permisos.', 'alegra-connector')]);
        }

        @set_time_limit(120);
        wp_raise_memory_limit();

        global $wpdb;

        // Find all attachments with _alegra_image_url meta
        $attachments = $wpdb->get_results(
            "SELECT pm.post_id, pm.meta_value, p.post_parent
             FROM {$wpdb->postmeta} pm
             INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id AND p.post_type = 'attachment'
             WHERE pm.meta_key = '_alegra_image_url'"
        );

        if (empty($attachments)) {
            wp_send_json_success([
                'message' => __('No hay imagenes de Alegra para limpiar.', 'alegra-connector'),
                'removed' => 0,
            ]);
        }

        // Group by normalized URL + parent to find duplicates
        $by_normalized = [];
        foreach ($attachments as $att) {
            $parsed = wp_parse_url($att->meta_value);
            if ($parsed === false || empty($parsed['host'])) {
                continue;
            }
            $scheme = isset($parsed['scheme']) ? $parsed['scheme'] : 'https';
            $host = $parsed['host'];
            $port = isset($parsed['port']) ? ':' . $parsed['port'] : '';
            $path = isset($parsed['path']) ? $parsed['path'] : '';
            $normalized = $scheme . '://' . $host . $port . $path;

            $key = $att->post_parent . '|' . $normalized;
            if (!isset($by_normalized[$key])) {
                $by_normalized[$key] = [];
            }
            $by_normalized[$key][] = $att->post_id;
        }

        $removed = 0;
        $updated_galleries = 0;
        foreach ($by_normalized as $key => $ids) {
            if (count($ids) <= 1) {
                continue;
            }
            // Keep the first ID, delete the rest
            $keep_id = (int) $ids[0];
            $remove_ids = array_map('intval', array_slice($ids, 1));
            $remove_ids = array_filter($remove_ids, function($id) use ($keep_id) {
                return $id !== $keep_id;
            });

            // Verify the kept attachment is actually attached to the product
            $parent_id = (int) explode('|', $key)[0];
            $keep_parent = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT post_parent FROM {$wpdb->posts} WHERE ID = %d",
                $keep_id
            ));
            if ($keep_parent !== $parent_id) {
                wp_update_post(['ID' => $keep_id, 'post_parent' => $parent_id]);
            }

            // Update gallery meta to remove duplicates
            $gallery = get_post_meta($parent_id, '_product_image_gallery', true);
            if (!empty($gallery)) {
                $gallery_ids = array_filter(
                    explode(',', $gallery),
                    function($id) use ($remove_ids) {
                        return !in_array((int) $id, $remove_ids, true);
                    }
                );
                update_post_meta($parent_id, '_product_image_gallery', implode(',', $gallery_ids));
                $updated_galleries++;
            }

            // Update featured image if it points to a duplicate
            $featured = (int) get_post_meta($parent_id, '_thumbnail_id', true);
            if (in_array($featured, $remove_ids, true)) {
                update_post_meta($parent_id, '_thumbnail_id', $keep_id);
            }

            // Delete the duplicates
            foreach ($remove_ids as $remove_id) {
                wp_delete_attachment($remove_id, true);
                $removed++;
            }
        }

        $this->log('info', 'Duplicate images cleaned up', [
            'removed' => $removed,
            'galleries_updated' => $updated_galleries,
        ]);

        wp_send_json_success([
            'message' => sprintf(
                _n(
                    'Se elimino %d imagen duplicada.',
                    'Se eliminaron %d imagenes duplicadas.',
                    $removed,
                    'alegra-connector'
                ),
                $removed
            ),
            'removed' => $removed,
            'galleries_updated' => $updated_galleries,
        ]);
    }

    /**
     * AJAX: Rebuild image dedup index for existing attachments.
     * Backfills _alegra_image_url_hash for attachments that have _alegra_image_url.
     */
    public function ajax_rebuild_image_index(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error(['message' => __('No tienes permisos.', 'alegra-connector')]);
        }

        @set_time_limit(120);
        wp_raise_memory_limit();

        global $wpdb;

        // Find attachments with _alegra_image_url but missing _alegra_image_url_hash
        $results = $wpdb->get_results(
            "SELECT pm.post_id, pm.meta_value
             FROM {$wpdb->postmeta} pm
             INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id AND p.post_type = 'attachment'
             WHERE pm.meta_key = '_alegra_image_url'
             AND NOT EXISTS (
                 SELECT 1 FROM {$wpdb->postmeta} pm2
                 WHERE pm2.post_id = pm.post_id AND pm2.meta_key = '_alegra_image_url_hash'
             )"
        );

        $backfilled = 0;
        foreach ($results as $row) {
            $url = $row->meta_value;
            // Normalize URL before hashing (strip query params)
            $parts = wp_parse_url($url);
            if ($parts === false || empty($parts['host'])) {
                continue;
            }
            $scheme = isset($parts['scheme']) ? $parts['scheme'] : 'https';
            $host = $parts['host'];
            $port = isset($parts['port']) ? ':' . $parts['port'] : '';
            $path = isset($parts['path']) ? $parts['path'] : '';
            $normalized = $scheme . '://' . $host . $port . $path;
            $hash = md5($normalized);

            update_post_meta((int) $row->post_id, '_alegra_image_url_hash', $hash);
            // Also update the URL meta to the normalized version if needed
            if ($normalized !== $url) {
                update_post_meta((int) $row->post_id, '_alegra_image_url', $normalized);
            }
            $backfilled++;
        }

        $this->log('info', 'Image index rebuilt', ['backfilled' => $backfilled]);

        wp_send_json_success([
            'message' => sprintf(
                _n(
                    'Se reindexo %d imagen. Las imagenes duplicadas seran detectadas automaticamente.',
                    'Se reindexaron %d imagenes. Las imagenes duplicadas seran detectadas automaticamente.',
                    $backfilled,
                    'alegra-connector'
                ),
                $backfilled
            ),
            'backfilled' => $backfilled,
        ]);
    }

    /**
     * AJAX: Get image index statistics (for the dashboard card).
     */
    public function ajax_image_index_stats(): void
    {
        check_ajax_referer('alegra_connector_nonce');
        if (!current_user_can('manage_woocommerce')) {
            wp_send_json_error();
        }

        global $wpdb;
        $total_attachments = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'attachment'"
        );
        $indexed = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_alegra_image_url_hash'"
        );
        $without_hash = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_alegra_image_url'"
        ) - $indexed;

        wp_send_json_success([
            'total_attachments' => $total_attachments,
            'indexed_with_hash' => max(0, $indexed),
            'missing_hash' => max(0, $without_hash),
            'coverage_pct' => $total_attachments > 0 ? round(($indexed / $total_attachments) * 100, 1) : 100,
        ]);
    }
}
